# -*- coding: utf-8 -*-
"""لوحة التحكم: مؤشرات قابلة للنقر + رسوم بيانية."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QGridLayout, QGroupBox, QHBoxLayout, QLabel,
                               QScrollArea, QVBoxLayout, QWidget)

from ..core.finance import format_money
from ..core.workflow import STATUS_NAMES
from .widgets import BarChart, StatCard


class DashboardPage(QWidget):
    def __init__(self, ctx, on_navigate, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.on_navigate = on_navigate  # دالة (page_key, filters)
        self.cards = {}

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        inner = QWidget()
        self.layout = QVBoxLayout(inner)
        self.layout.setSpacing(14)
        scroll.setWidget(inner)

        outer = QVBoxLayout(self)
        outer.addWidget(scroll)

        # -- بطاقات المؤشرات -------------------------------------------------
        grid = QGridLayout()
        grid.setSpacing(12)
        self.card_defs = [
            ("total", "إجمالي الملفات المسجلة", "#1F3A5F", {}),
            ("new", "ملفات جديدة", "#5A6B85", {"status_code": "new"}),
            ("in_review", "قيد المراجعة", "#B7791F", {"in_review": True}),
            ("missing", "توجد نواقص", "#C0392B", {"status_code": "missing_docs"}),
            ("tech_done", "مكتملة فنيًا", "#1E7E34", {"status_code": "tech_done"}),
            ("approved", "معتمدة ماليًا", "#1565C0", {"status_code": "approved"}),
            ("rejected", "مرفوضة / معادة", "#7B1FA2", {"rejected_or_returned": True}),
            ("overdue", "متأخرة عن مدة المراجعة", "#C0392B", {"overdue": True}),
        ]
        for i, (key, title, accent, _) in enumerate(self.card_defs):
            card = StatCard(key, title)
            card.clicked.connect(self._card_clicked)
            card.setStyleSheet(f"#statCard {{ border-top: 4px solid {accent}; }}")
            self.cards[key] = (card, accent)
            grid.addWidget(card, i // 4, i % 4)
        self.layout.addLayout(grid)

        # -- البطاقات المالية --------------------------------------------------
        fin_grid = QGridLayout()
        fin_grid.setSpacing(12)
        self.fin_cards = {}
        for i, (key, title) in enumerate([("claimed", "إجمالي المبالغ المطالب بها"),
                                         ("approved_sum", "إجمالي المبالغ المعتمدة"),
                                         ("diff", "إجمالي الفروقات (مطالب−معتمد)")]):
            card = StatCard("fin_" + key, title)
            self.fin_cards[key] = card
            fin_grid.addWidget(card, 0, i)
        self.layout.addLayout(fin_grid)

        # -- الرسوم البيانية ----------------------------------------------------
        charts = QHBoxLayout()
        charts.setSpacing(12)

        box1 = QGroupBox("الملفات حسب الفرع")
        l1 = QVBoxLayout(box1)
        self.chart_branch = BarChart()
        l1.addWidget(self.chart_branch)
        charts.addWidget(box1, 1)

        box2 = QGroupBox("الملفات حسب المجال التدريبي")
        l2 = QVBoxLayout(box2)
        self.chart_field = BarChart(bar_color="#2E7D6F")
        l2.addWidget(self.chart_field)
        charts.addWidget(box2, 1)

        box3 = QGroupBox("الملفات حسب الشهر (آخر 12 شهرًا)")
        l3 = QVBoxLayout(box3)
        self.chart_month = BarChart(bar_color="#B7791F")
        l3.addWidget(self.chart_month)
        charts.addWidget(box3, 1)

        self.layout.addLayout(charts)
        self.layout.addStretch(1)

    def _card_clicked(self, key):
        for k, _t, _a, filters in self.card_defs:
            if k == key and filters:
                self.on_navigate("files", filters)
                return

    def refresh(self):
        stats = self.ctx.files.dashboard_stats(
            deadline_days=int(self.ctx.settings().get("review_deadline_days", 30)))
        by = stats["by_status"]
        in_review = sum(by.get(c, 0) for c in ("tech_review", "finance_review", "ready_approve"))
        rejected = sum(by.get(c, 0) for c in ("rejected", "returned"))

        values = {
            "total": (f"{stats['total']:,}", ""),
            "new": (f"{by.get('new', 0):,}", ""),
            "in_review": (f"{in_review:,}", "فنية + مالية"),
            "missing": (f"{by.get('missing_docs', 0):,}", ""),
            "tech_done": (f"{by.get('tech_done', 0):,}", ""),
            "approved": (f"{by.get('approved', 0):,}", ""),
            "rejected": (f"{rejected:,}", ""),
            "overdue": (f"{stats['overdue']:,}", "تجاوزت مدة المراجعة"),
        }
        for key, (card, accent) in self.cards.items():
            v, s = values[key]
            card.set_value(v, s, accent)

        sums = stats["sums"]
        self.fin_cards["claimed"].set_value(format_money(sums["claimed"]), "", "#1F3A5F")
        self.fin_cards["approved_sum"].set_value(format_money(sums["approved"]), "", "#1E7E34")
        diff = sums["claimed"] - sums["approved"]
        self.fin_cards["diff"].set_value(
            format_money(diff), "سالب = المعتمد أعلى" if diff < 0 else "", "#C0392B")

        self.chart_branch.set_data([(r["name"] or "غير محدد", r["c"]) for r in stats["by_branch"]][:8])
        self.chart_field.set_data([(r["name"] or "غير محدد", r["c"]) for r in stats["by_field"]][:8])
        self.chart_month.set_data([(r["m"] or "—", r["c"]) for r in stats["by_month"]])
