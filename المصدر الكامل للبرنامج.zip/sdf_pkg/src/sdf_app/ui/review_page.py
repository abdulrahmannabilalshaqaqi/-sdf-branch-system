# -*- coding: utf-8 -*-
"""شاشة المراجعة الفنية: قائمة التحقق + مقارنة الأعداد + مطابقة الأسماء + الملخص المالي."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QFileDialog, QGridLayout, QGroupBox,
                               QHBoxLayout, QLabel, QListWidget, QMessageBox,
                               QPushButton, QSplitter, QTableWidget,
                               QTableWidgetItem, QTextEdit, QVBoxLayout,
                               QWidget, QLineEdit)

from ..core import finance
from ..core.finance import format_money
from ..core.review_logic import (REVIEW_RESULTS, match_names, review_summary,
                                 suggest_approved_count)
from ..services.auth_service import has_permission


class ReviewPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.file_id = None
        self.record = {}
        self.on_print_form = None  # تُضبط من main

        layout = QVBoxLayout(self)

        # -- اختيار الملف ---------------------------------------------------------
        top = QHBoxLayout()
        self.file_search = QLineEdit()
        self.file_search.setPlaceholderText("رقم الملف ثم Enter للتحميل")
        self.file_search.returnPressed.connect(self._load_by_number)
        self.file_title = QLabel("اختر ملفًا للمراجعة")
        self.file_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #1F3A5F;")
        top.addWidget(self.file_title, 1)
        top.addWidget(self.file_search, 0)
        layout.addLayout(top)

        splitter = QSplitter(Qt.Vertical)

        # -- قائمة التحقق -----------------------------------------------------------
        self.check_group = QGroupBox("قائمة التحقق من الوثائق")
        cg = QVBoxLayout(self.check_group)
        self.check_table = QTableWidget()
        self.check_table.setColumnCount(3)
        self.check_table.setHorizontalHeaderLabels(["الوثيقة", "الحالة", "ملاحظات"])
        self.check_table.verticalHeader().setVisible(False)
        cg.addWidget(self.check_table)
        splitter.addWidget(self.check_group)

        mid = QWidget()
        mid_l = QHBoxLayout(mid)
        mid_l.setContentsMargins(0, 0, 0, 0)

        # -- مقارنة الأعداد ------------------------------------------------------------
        self.counts_group = QGroupBox("مقارنة أعداد المتدربين")
        cl = QVBoxLayout(self.counts_group)
        self.counts_table = QTableWidget()
        self.counts_table.setColumnCount(2)
        self.counts_table.setHorizontalHeaderLabels(["البيان", "العدد"])
        self.counts_table.verticalHeader().setVisible(False)
        cl.addWidget(self.counts_table)
        self.suggest_lbl = QLabel("")
        self.suggest_lbl.setWordWrap(True)
        cl.addWidget(self.suggest_lbl)
        btn_row = QHBoxLayout()
        self.btn_suggest = QPushButton("احسب العدد المقترح")
        self.btn_suggest.clicked.connect(self._calc_suggested)
        self.btn_apply = QPushButton("اعتماد العدد المقترح")
        self.btn_apply.setProperty("ok", True)
        self.btn_apply.clicked.connect(self._apply_suggested)
        btn_row.addWidget(self.btn_suggest)
        btn_row.addWidget(self.btn_apply)
        cl.addLayout(btn_row)
        mid_l.addWidget(self.counts_group, 1)

        # -- مطابقة الأسماء ---------------------------------------------------------------
        self.names_group = QGroupBox("مطابقة أسماء المتدربين (ترشيحات × حضور)")
        nl = QVBoxLayout(self.names_group)
        imp_row = QHBoxLayout()
        self.btn_imp_nom = QPushButton("استيراد كشف الترشيحات")
        self.btn_imp_att = QPushButton("استيراد كشف الحضور")
        self.btn_match = QPushButton("تنفيذ المطابقة")
        self.btn_match.setProperty("primary", True)
        self.btn_imp_nom.clicked.connect(lambda: self._import_names("nomination"))
        self.btn_imp_att.clicked.connect(lambda: self._import_names("attendance"))
        self.btn_match.clicked.connect(self._run_match)
        imp_row.addWidget(self.btn_imp_nom)
        imp_row.addWidget(self.btn_imp_att)
        imp_row.addWidget(self.btn_match)
        nl.addLayout(imp_row)
        self.match_result = QTextEdit()
        self.match_result.setReadOnly(True)
        self.match_result.setMaximumHeight(150)
        nl.addWidget(self.match_result)
        mid_l.addWidget(self.names_group, 1)
        splitter.addWidget(mid)

        # -- الملخص -------------------------------------------------------------------------
        bottom = QWidget()
        bl = QHBoxLayout(bottom)
        bl.setContentsMargins(0, 0, 0, 0)
        self.summary_group = QGroupBox("الملخص المالي")
        sl = QVBoxLayout(self.summary_group)
        self.fin_lbl = QLabel("")
        self.fin_lbl.setWordWrap(True)
        sl.addWidget(self.fin_lbl)
        bl.addWidget(self.summary_group, 1)

        self.review_group = QGroupBox("ملخص المراجعة")
        rl = QVBoxLayout(self.review_group)
        self.rev_lbl = QLabel("")
        self.rev_lbl.setWordWrap(True)
        rl.addWidget(self.rev_lbl)
        bl.addWidget(self.review_group, 1)

        btns = QVBoxLayout()
        self.btn_save = QPushButton("حفظ المراجعة")
        self.btn_save.setProperty("primary", True)
        self.btn_save.clicked.connect(self._save_review)
        self.btn_print = QPushButton("معاينة وطباعة الاستمارة")
        self.btn_print.setProperty("ok", True)
        self.btn_print.clicked.connect(self._print_form)
        btns.addWidget(self.btn_save)
        btns.addWidget(self.btn_print)
        btns.addStretch(1)
        bl.addLayout(btns)
        splitter.addWidget(bottom)

        splitter.setSizes([260, 220, 200])
        layout.addWidget(splitter, 1)

    # -- التحميل -----------------------------------------------------------------------
    def open_file(self, file_id: int):
        self.file_id = file_id
        self.refresh()

    def _load_by_number(self):
        try:
            num = int(self.file_search.text().strip())
        except ValueError:
            QMessageBox.warning(self, "تنبيه", "أدخل رقم ملف صحيحًا.")
            return
        rec = self.ctx.files.get_by_number(num)
        if not rec:
            QMessageBox.warning(self, "تنبيه", f"لا يوجد ملف بالرقم {num}.")
            return
        self.open_file(rec["id"])

    def refresh(self):
        if not self.file_id:
            return
        self.record = self.ctx.files.get(self.file_id) or {}
        r = self.record
        self.file_title.setText(f"مراجعة الملف رقم {r.get('file_number')} — {r.get('program_name') or ''}")
        self._build_checklist()
        self._build_counts()
        self._build_finance()
        self._update_review_summary()

    def _build_checklist(self):
        conn = self.ctx.conn
        # تهيئة البنود إن لم توجد
        existing = {x["document_type_id"] for x in self.ctx.files.review_items(self.file_id)}
        for dt in conn.execute("SELECT id FROM document_types WHERE active=1"):
            if dt["id"] not in existing:
                conn.execute("INSERT INTO review_items (file_id, document_type_id) VALUES (?,?)",
                             (self.file_id, dt["id"]))
        conn.commit()
        items = self.ctx.files.review_items(self.file_id)
        self._items = items
        self.check_table.setRowCount(len(items))
        self._combos = []
        for i, it in enumerate(items):
            self.check_table.setItem(i, 0, QTableWidgetItem(it["document_name"]))
            cb = QComboBox()
            cb.addItems(REVIEW_RESULTS)
            if it["result"] in REVIEW_RESULTS:
                cb.setCurrentText(it["result"])
            cb.currentTextChanged.connect(self._update_review_summary)
            self.check_table.setCellWidget(i, 1, cb)
            self._combos.append(cb)
            notes = QLineEdit(it["notes"] or "")
            notes.setPlaceholderText("ملاحظة…")
            notes.textChanged.connect(self._update_review_summary)
            self.check_table.setCellWidget(i, 2, notes)
        self.check_table.resizeColumnsToContents()

    def _build_counts(self):
        r = self.record
        rows = [("عدد المتدربين حسب العقد", r.get("contract_trainees")),
                ("عدد المرشحين", r.get("nominees_count")),
                ("عدد الحاضرين حسب كشف الحضور", r.get("attendance_trainees")),
                ("عدد الشهادات المرفقة", r.get("certificates_count")),
                ("العدد المعتمد حاليًا", r.get("approved_trainees"))]
        self.counts_table.setRowCount(len(rows))
        for i, (label, val) in enumerate(rows):
            self.counts_table.setItem(i, 0, QTableWidgetItem(label))
            it = QTableWidgetItem(str(val) if val is not None else "—")
            it.setTextAlignment(Qt.AlignCenter)
            self.counts_table.setItem(i, 1, it)
        self.counts_table.resizeColumnsToContents()

    def _build_finance(self):
        r = self.record
        s = finance.summarize(r)
        lines = [
            f"المبلغ المطالب به: {format_money(r.get('claimed_amount'))}",
            f"التكلفة الإجمالية المعتمدة: {format_money(s['approved_total'])}",
            f"مبلغ التمويل: {format_money(r.get('funding_amount'))}",
            f"الفارق (التمويل − المطالب به): {format_money(s['diff_funding_claimed'])}",
            f"الفارق (المطالب به − المعتمد): {format_money(s['diff_claimed_approved'])}",
        ]
        self.fin_lbl.setText("\n".join(lines))

    def _current_items(self):
        out = []
        for i, it in enumerate(self._items):
            notes_w = self.check_table.cellWidget(i, 2)
            out.append({"document_name": it["document_name"],
                        "result": self._combos[i].currentText(),
                        "notes": notes_w.text().strip(),
                        "required_default": it["required_default"]})
        return out

    def _update_review_summary(self):
        if not hasattr(self, "_items"):
            return
        s = review_summary(self._current_items())
        self.rev_lbl.setText(
            f"مكتملة: {s['complete']} | غير منطبقة: {s['not_applicable']} | "
            f"تحتاج معالجة: {s['missing']} | لم تُراجع: {s['pending']}\n"
            + ("المراجعة الفنية مكتملة ✓" if s["is_technically_complete"]
               else "المراجعة الفنية غير مكتملة بعد."))

    # -- العدد المقترح ----------------------------------------------------------------------
    def _calc_suggested(self):
        r = self.record
        res = suggest_approved_count(
            contract=r.get("contract_trainees"), nominees=r.get("nominees_count"),
            attendance=r.get("attendance_trainees"), certificates=r.get("certificates_count"))
        self._suggested = res.get("value")
        lines = []
        if res["value"] is not None:
            lines.append(f"العدد المقترح: {res['value']}")
            if res.get("differences"):
                for label, d in res["differences"].items():
                    lines.append(f"فرق {label}: {d}")
        lines += res["warnings"]
        self.suggest_lbl.setText("\n".join(lines))

    def _apply_suggested(self):
        if not getattr(self, "_suggested", None):
            QMessageBox.information(self, "تنبيه", "احسب العدد المقترح أولًا.")
            return
        if not has_permission(self.ctx.user, "review.technical"):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية الاعتماد.")
            return
        self.ctx.files.update(self.file_id, {
            "approved_trainees": self._suggested,
            "suggested_trainees": self._suggested,
        }, user_id=self.ctx.user["id"] if self.ctx.user else None)
        self.refresh()
        QMessageBox.information(self, "تم", f"تم اعتماد العدد {self._suggested}.")

    # -- مطابقة الأسماء -------------------------------------------------------------------------
    def _import_names(self, kind):
        path, _ = QFileDialog.getOpenFileName(self, "اختر ملف Excel لكشف الأسماء",
                                              "", "Excel (*.xlsx *.xlsm *.xls)")
        if not path:
            return
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        names = [str(r[0]).strip() for r in ws.iter_rows(min_row=2, max_col=1, values_only=True)
                 if r[0] and str(r[0]).strip()]
        wb.close()
        if not names:
            QMessageBox.warning(self, "تنبيه", "لم يُعثر على أسماء في العمود الأول.")
            return
        table = "trainees_nomination" if kind == "nomination" else "trainees_attendance"
        conn = self.ctx.conn
        conn.execute(f"DELETE FROM {table} WHERE file_id=?", (self.file_id,))
        for i, n in enumerate(names, 1):
            conn.execute(f"INSERT INTO {table} (file_id, seq, full_name) VALUES (?,?,?)",
                         (self.file_id, i, n))
        conn.commit()
        QMessageBox.information(self, "تم", f"تم استيراد {len(names)} اسمًا.")

    def _run_match(self):
        conn = self.ctx.conn
        nom = [r[0] for r in conn.execute(
            "SELECT full_name FROM trainees_nomination WHERE file_id=? ORDER BY seq", (self.file_id,))]
        att = [r[0] for r in conn.execute(
            "SELECT full_name FROM trainees_attendance WHERE file_id=? ORDER BY seq", (self.file_id,))]
        if not nom or not att:
            QMessageBox.warning(self, "تنبيه", "استورد كشفي الترشيحات والحضور أولًا.")
            return
        res = match_names(nom, att)
        c = res["counts"]
        lines = [f"الترشيحات: {c['nomination']} | الحضور: {c['attendance']} | متطابقة: {c['matched']}"]
        if res["only_nomination"]:
            lines.append(f"مرشحة غير حاضرة ({len(res['only_nomination'])}): " + "، ".join(res["only_nomination"][:10]))
        if res["only_attendance"]:
            lines.append(f"حاضرة غير مرشحة ({len(res['only_attendance'])}): " + "، ".join(res["only_attendance"][:10]))
        if res["similar_needs_review"]:
            lines.append("متشابهة تحتاج مراجعة بشرية:")
            for a, b, s in res["similar_needs_review"][:10]:
                lines.append(f"  • {a} ≈ {b} ({s})")
        if res["duplicates_nomination"] or res["duplicates_attendance"]:
            lines.append("تنبيه: توجد أسماء مكررة داخل الكشوف.")
        self.match_result.setPlainText("\n".join(lines))

    # -- الحفظ والطباعة ------------------------------------------------------------------------------
    def _save_review(self):
        if not self.file_id:
            return
        if not has_permission(self.ctx.user, "review.technical"):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية المراجعة الفنية.")
            return
        conn = self.ctx.conn
        uid = self.ctx.user["id"] if self.ctx.user else None
        for i, it in enumerate(self._items):
            notes_w = self.check_table.cellWidget(i, 2)
            conn.execute("""UPDATE review_items SET result=?, notes=?, reviewed_by=?, reviewed_at=datetime('now')
                            WHERE id=?""",
                         (self._combos[i].currentText(), notes_w.text().strip(), uid, it["id"]))
        conn.commit()
        self._update_review_summary()
        QMessageBox.information(self, "تم", "تم حفظ نتائج المراجعة.")

    def _print_form(self):
        if not self.file_id:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا أولًا.")
            return
        if self.on_print_form:
            self.on_print_form(self.file_id)
