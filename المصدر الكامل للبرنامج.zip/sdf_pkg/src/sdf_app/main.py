# -*- coding: utf-8 -*-
"""نقطة الدخول الرئيسية للبرنامج."""
import sys
import traceback

from PySide6.QtWidgets import QMessageBox

from sdf_app import config
from sdf_app.ui.app import create_app
from sdf_app.ui.context import AppContext
from sdf_app.ui.login_dialog import LoginDialog
from sdf_app.ui.main_window import MainWindow


def _wire_pages(window: MainWindow, ctx: AppContext):
    from .ui.dashboard_page import DashboardPage
    from .ui.files_page import FilesPage
    from .ui.import_wizard import ImportWizard
    from .ui.reports_page import ReportsPage
    from .ui.review_page import ReviewPage
    from .ui.settings_page import SettingsPage

    def navigate(page_key: str, filters: dict = None):
        window.show_page(page_key)
        if page_key == "files" and filters and "files" in window.pages:
            window.pages["files"].set_filters(filters)

    dashboard = DashboardPage(ctx, on_navigate=navigate)
    files_page = FilesPage(ctx)
    review_page = ReviewPage(ctx)
    reports_page = ReportsPage(ctx)
    settings_page = SettingsPage(ctx)

    def open_import():
        wiz = ImportWizard(ctx, window)
        if wiz.exec():
            files_page.refresh()
            dashboard.refresh()

    # صفحة الاستيراد تُفتح كمعالج
    import_page = None

    def open_file(file_id: int, open_review: bool = False):
        if open_review:
            review_page.open_file(file_id)
            window.show_page("review")
        else:
            from .ui.file_dialog import FileDialog
            dlg = FileDialog(ctx, file_id=file_id, parent=window)
            if dlg.exec():
                files_page.refresh()

    files_page.on_open_file = open_file
    review_page.on_print_form = lambda fid: reports_page.open_form_for_file(fid)

    window.register_page("dashboard", "لوحة التحكم", dashboard)
    window.register_page("files", "إدارة الملفات", files_page)
    window.register_page("review", "المراجعة الفنية", review_page)
    window.register_page("reports", "التقارير والطباعة", reports_page)
    window.register_page("settings", "الإعدادات", settings_page)
    window.register_page("users", "المستخدمون", settings_page)
    window.register_page("backup", "النسخ الاحتياطي", settings_page)

    # زر الاستيراد في القائمة يفتح المعالج مباشرة
    for btn in window.nav_group.buttons():
        if btn.property("page_key") == "import":
            btn.clicked.disconnect()
            btn.clicked.connect(open_import)

    window.show_page("dashboard")
    return {"dashboard": dashboard, "files": files_page}


def main(argv=None) -> int:
    argv = sys.argv if argv is None else argv
    try:
        config.ensure_data_dirs()
        ctx = AppContext()
    except Exception as exc:
        print(f"فشل تهيئة قاعدة البيانات: {exc}", file=sys.stderr)
        return 1

    app = create_app(argv)
    login = LoginDialog(ctx)
    if login.exec() != login.Accepted:
        return 0

    window = MainWindow(ctx)
    try:
        _wire_pages(window, ctx)
    except Exception:
        QMessageBox.critical(None, "خطأ", f"فشل تحميل الواجهة:\n{traceback.format_exc()}")
        return 1
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
