# -*- coding: utf-8 -*-
"""إدارة الاتصال بقاعدة SQLite وتطبيق المخطط/الترحيلات."""
import sqlite3
from pathlib import Path
from typing import Optional

from .. import config

SCHEMA_VERSION = 1


def _schema_sql() -> str:
    from .. import config
    return config.resource_path("database", "schema.sql").read_text(encoding="utf-8")


class Database:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else config.db_path()
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> sqlite3.Connection:
        if self._conn is None:
            config.ensure_data_dirs()
            self._conn = sqlite3.connect(str(self.path))
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA foreign_keys = ON")
            self._conn.execute("PRAGMA journal_mode = WAL")
            self._migrate(self._conn)
        return self._conn

    def close(self):
        if self._conn is not None:
            self._conn.commit()
            self._conn.close()
            self._conn = None

    # -- الترحيلات ------------------------------------------------------
    def _current_version(self, conn: sqlite3.Connection) -> int:
        try:
            row = conn.execute("SELECT MAX(version) AS v FROM schema_migrations").fetchone()
            return int(row["v"]) if row and row["v"] is not None else 0
        except sqlite3.OperationalError:
            return 0

    def _migrate(self, conn: sqlite3.Connection):
        version = self._current_version(conn)
        if version < 1:
            conn.executescript(_schema_sql())
            conn.execute("INSERT INTO schema_migrations (version) VALUES (1)")
            conn.commit()
        if version < 2:
            cols = {c[1] for c in conn.execute("PRAGMA table_info(training_files)")}
            if "contract_number" not in cols:
                conn.execute("ALTER TABLE training_files ADD COLUMN contract_number TEXT")
            conn.execute("INSERT INTO schema_migrations (version) VALUES (2)")
            conn.commit()


_db_instance: Optional[Database] = None


def get_database(path: Optional[Path] = None) -> Database:
    global _db_instance
    if _db_instance is None or (path is not None and _db_instance.path != Path(path)):
        _db_instance = Database(path)
    return _db_instance


def reset_database_singleton():
    global _db_instance
    if _db_instance is not None:
        _db_instance.close()
    _db_instance = None
