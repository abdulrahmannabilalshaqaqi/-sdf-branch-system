# -*- coding: utf-8 -*-
"""اختبارات منطق المراجعة: العدد المعتمد المقترح ومطابقة الأسماء."""
from sdf_app.core.review_logic import (
    match_names,
    normalize_arabic_name,
    review_summary,
    suggest_approved_count,
)


def test_suggest_takes_minimum_of_available():
    r = suggest_approved_count(contract=31, nominees=30, attendance=29, certificates=29)
    assert r["value"] == 29
    assert r["missing"] == []


def test_suggest_ignores_missing_instead_of_zero():
    # الغائب لا يُعامل كصفر — الاقتراح من المتوفر فقط مع تحذير
    r = suggest_approved_count(contract=10, nominees=None, attendance=8, certificates=None)
    assert r["value"] == 8
    assert len(r["missing"]) == 2
    assert r["warnings"]


def test_suggest_nothing_available():
    r = suggest_approved_count()
    assert r["value"] is None
    assert r["warnings"]


def test_suggest_differences_reported():
    r = suggest_approved_count(contract=10, nominees=9, attendance=9, certificates=9)
    assert r["value"] == 9
    assert r["differences"]  # فرق العقد عن المعتمد


def test_normalize_arabic_name():
    assert normalize_arabic_name("أحمد") == normalize_arabic_name("احمد")
    assert normalize_arabic_name("فاطمة") == normalize_arabic_name("فاطمه")
    assert normalize_arabic_name("مُحَمَّد") == "محمد"


def test_match_names_exact():
    nom = ["أحمد محمد", "خالد سعيد"]
    att = ["احمد محمد", "خالد سعيد", "سالم علي"]
    r = match_names(nom, att)
    assert r["counts"]["matched"] == 2
    assert r["only_nomination"] == []
    assert r["only_attendance"] == ["سالم علي"]


def test_match_names_missing_and_duplicates():
    nom = ["أحمد محمد", "أحمد محمد", "خالد سعيد"]
    att = ["احمد محمد"]
    r = match_names(nom, att)
    assert len(r["matched"]) == 1
    assert "خالد سعيد" in r["only_nomination"]
    assert r["duplicates_nomination"]  # التكرار مكتشف


def test_similar_names_need_human_review_not_auto_matched():
    nom = ["عبدالله محمد الحميري"]
    att = ["عبد الله محمد الحميري"]  # مسافة زائدة — متشابه جدًا
    r = match_names(nom, att)
    # إما تطابق بعد التوحيد أو إحالة للمراجعة البشرية — المهم ألا يُفقد
    total_accounted = (len(r["matched"]) + len(r["similar_needs_review"])
                 + len(r["only_nomination"]))
    assert total_accounted == 1


def test_review_summary_distinguishes_not_applicable():
    items = [
        {"document_name": "العقد", "result": "مطابق"},
        {"document_name": "الترخيص", "result": "غير منطبق"},
        {"document_name": "الشهادات", "result": "غير مكتمل", "notes": "ناقص شهادتان"},
        {"document_name": "المطالبة", "result": "لم يراجع"},
    ]
    s = review_summary(items)
    assert s["complete"] == 1
    assert s["not_applicable"] == 1
    assert s["missing"] == 1  # غير المنطبق ليس ناقصًا
    assert s["pending"] == 1
    assert not s["is_technically_complete"]
