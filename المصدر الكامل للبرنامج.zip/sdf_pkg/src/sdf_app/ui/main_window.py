# -*- coding: utf-8 -*-
"""النافذة الرئيسية: قائمة جانبية + صفحات."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QButtonGroup, QHBoxLayout, QLabel, QMainWindow,
                               QPushButton, QStackedWidget, QStatusBar,
                               QVBoxLayout, QWidget)

from .. import config
from ..services.auth_service import ROLES, has_permission


class MainWindow(QMainWindow):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setWindowTitle(f"{config.APP_NAME_AR} — {config.ORG_NAME_AR}")
        self.resize(1280, 800)

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # -- القائمة الجانبية ------------------------------------------------
        sidebar = QWidget()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(240)
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(0, 0, 0, 0)
        side_layout.setSpacing(2)

        title = QLabel(f"{config.APP_NAME_AR}\n{config.ORG_NAME_AR}")
        title.setObjectName("sidebarTitle")
        title.setWordWrap(True)
        side_layout.addWidget(title)

        self.stack = QStackedWidget()
        self.pages = {}
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)

        # (المفتاح، العنوان، الصلاحية)
        self.nav_items = [
            ("dashboard", "لوحة التحكم", "file.view"),
            ("files", "إدارة الملفات", "file.view"),
            ("review", "المراجعة الفنية", "review.technical"),
            ("import", "استيراد من Excel", "import"),
            ("reports", "التقارير والطباعة", "report.view"),
            ("settings", "الإعدادات", "settings.manage"),
            ("users", "المستخدمون", "user.manage"),
            ("backup", "النسخ الاحتياطي", "backup"),
        ]
        for key, label, perm in self.nav_items:
            if not has_permission(ctx.user, perm):
                continue
            btn = QPushButton(label)
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, k=key: self.show_page(k))
            self.nav_group.addButton(btn)
            side_layout.addWidget(btn)
            btn.setProperty("page_key", key)

        side_layout.addStretch(1)
        user_lbl = QLabel(f"المستخدم: {ctx.user['full_name']}\nالدور: {ROLES.get(ctx.user['role'], '')}")
        user_lbl.setStyleSheet("color: #9FB2CC; padding: 12px; font-size: 12px;")
        side_layout.addWidget(user_lbl)

        main_layout.addWidget(sidebar)

        # -- منطقة المحتوى ----------------------------------------------------
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(20, 16, 20, 16)
        self.page_title = QLabel("")
        self.page_title.setObjectName("pageTitle")
        content_layout.addWidget(self.page_title)
        content_layout.addWidget(self.stack, 1)
        main_layout.addWidget(content, 1)

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage(f"متصل بقاعدة البيانات — {ctx.user['full_name']}")

    def register_page(self, key: str, title: str, widget: QWidget):
        self.pages[key] = widget
        self.stack.addWidget(widget)
        widget.setProperty("page_title", title)

    def show_page(self, key: str):
        if key not in self.pages:
            return
        # تفعيل زر القائمة
        for btn in self.nav_group.buttons():
            if btn.property("page_key") == key:
                btn.setChecked(True)
        page = self.pages[key]
        self.stack.setCurrentWidget(page)
        self.page_title.setText(page.property("page_title") or "")
        if hasattr(page, "refresh"):
            page.refresh()
