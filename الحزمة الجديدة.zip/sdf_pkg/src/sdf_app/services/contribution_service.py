# -*- coding: utf-8 -*-
"""خدمة المساهمات الشهرية للجهات المستفيدة وحساب رصيد التدريب.

القواعد (حسب ملاحظات المستخدم):
- رصيد التدريب = نسبة (افتراضيًا 50%) من المساهمات المدخلة.
- النسبة قابلة للتعديل من مدير النظام مع تحديد تاريخ سريان التعديل (سجل نسب).
- تُقبل مبالغ «فترة سابقة» بشكل منفصل عن المساهمة الشهرية أمام أي شهر.
- استثناء لبعض الجهات/السنوات: الاستفادة من رصيد العام السابق.
- رصيد الجهة مربوط بملفاتها بمبلغ التمويل فقط (مجموع funding_amount).
- الرصيد المتبقي يُعرض للعلم فقط عند المراجعة المالية (غير ملزم).
"""
import sqlite3
from typing import Dict, List, Optional

KINDS = {"monthly": "شهرية", "previous_period": "فترة سابقة"}


def _audit(conn, user_id, action, entity, entity_id, details=""):
    username = None
    if user_id:
        r = conn.execute("SELECT username FROM users WHERE id=?", (user_id,)).fetchone()
        username = r["username"] if r else None
    conn.execute(
        "INSERT INTO audit_log (user_id, username, action, entity, entity_id, details)"
        " VALUES (?,?,?,?,?,?)", (user_id, username, action, entity, entity_id, details))


# -- نسب رصيد التدريب -----------------------------------------------------------
def current_rate(conn: sqlite3.Connection, on_date: Optional[str] = None) -> float:
    """النسبة السارية في تاريخ معين (أو الأحدث)."""
    if on_date:
        row = conn.execute(
            "SELECT rate FROM contribution_rates WHERE effective_from <= ?"
            " ORDER BY effective_from DESC LIMIT 1", (on_date,)).fetchone()
    else:
        row = conn.execute(
            "SELECT rate FROM contribution_rates ORDER BY effective_from DESC LIMIT 1").fetchone()
    return float(row["rate"]) if row else 0.5


def list_rates(conn: sqlite3.Connection) -> List[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM contribution_rates ORDER BY effective_from DESC")]


def set_rate(conn: sqlite3.Connection, rate: float, effective_from: str,
             user_id: Optional[int] = None):
    if not (0 < rate <= 1):
        raise ValueError("النسبة يجب أن تكون بين أكبر من 0 وأقل من أو تساوي 1 (مثال: 0.5).")
    conn.execute("INSERT INTO contribution_rates (rate, effective_from, created_by)"
                 " VALUES (?,?,?)", (rate, effective_from, user_id))
    _audit(conn, user_id, "contrib.rate_change", "contribution_rates", None,
           f"تغيير نسبة رصيد التدريب إلى {rate * 100:.0f}% اعتبارًا من {effective_from}")
    conn.commit()


# -- المساهمات -------------------------------------------------------------------
def upsert_contribution(conn: sqlite3.Connection, entity_id: int, year: int, month: int,
                        amount: Optional[float], kind: str = "monthly",
                        notes: str = "", user_id: Optional[int] = None):
    if kind not in KINDS:
        raise ValueError("نوع القيد غير معروف.")
    if amount in (None, ""):
        conn.execute("DELETE FROM contributions WHERE entity_id=? AND year=? AND month=? AND kind=?",
                     (entity_id, year, month, kind))
    else:
        conn.execute(
            """INSERT INTO contributions (entity_id, year, month, amount, kind, notes, created_by)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(entity_id, year, month, kind)
               DO UPDATE SET amount=excluded.amount, notes=excluded.notes""",
            (entity_id, year, month, float(amount), kind, notes or None, user_id))
    conn.commit()


def list_contributions(conn: sqlite3.Connection, entity_id: int, year: int) -> Dict[tuple, dict]:
    rows = conn.execute(
        "SELECT * FROM contributions WHERE entity_id=? AND year=?", (entity_id, year)).fetchall()
    return {(r["month"], r["kind"]): dict(r) for r in rows}


def contributions_total(conn: sqlite3.Connection, entity_id: int, year: int) -> float:
    row = conn.execute(
        "SELECT COALESCE(SUM(amount),0) t FROM contributions WHERE entity_id=? AND year=?",
        (entity_id, year)).fetchone()
    return float(row["t"])


# -- الاستثناءات ------------------------------------------------------------------
def set_exception(conn: sqlite3.Connection, entity_id: int, year: int, allow: bool,
                  notes: str = "", user_id: Optional[int] = None):
    conn.execute(
        """INSERT INTO entity_year_exceptions (entity_id, year, allow_previous_year, notes)
           VALUES (?,?,?,?)
           ON CONFLICT(entity_id, year)
           DO UPDATE SET allow_previous_year=excluded.allow_previous_year, notes=excluded.notes""",
        (entity_id, year, 1 if allow else 0, notes or None))
    _audit(conn, user_id, "contrib.exception", "entity_year_exceptions", None,
           f"استثناء رصيد العام السابق للجهة {entity_id} سنة {year}: {'نعم' if allow else 'لا'}")
    conn.commit()


def get_exception(conn: sqlite3.Connection, entity_id: int, year: int) -> bool:
    row = conn.execute(
        "SELECT allow_previous_year FROM entity_year_exceptions WHERE entity_id=? AND year=?",
        (entity_id, year)).fetchone()
    return bool(row and row["allow_previous_year"])


# -- الأرصدة -----------------------------------------------------------------------
def _file_year_expr() -> str:
    return "substr(COALESCE(NULLIF(exec_start,''), NULLIF(received_date,'')),1,4)"


def funding_used(conn: sqlite3.Connection, entity_id: int, year: int) -> float:
    """مجموع مبالغ التمويل لملفات الجهة في سنة معينة (مبلغ التمويل فقط)."""
    row = conn.execute(
        f"SELECT COALESCE(SUM(funding_amount),0) t FROM training_files"
        f" WHERE beneficiary_id=? AND {_file_year_expr()}=?",
        (entity_id, str(year))).fetchone()
    return float(row["t"])


def entity_balance(conn: sqlite3.Connection, entity_id: int, year: int,
                   _depth: int = 0) -> dict:
    """رصيد الجهة لسنة: المساهمات × النسبة (+ المرحّل باستثناء) − التمويل المستخدم."""
    contrib = contributions_total(conn, entity_id, year)
    rate = current_rate(conn, f"{year}-12-31")
    training_balance = contrib * rate
    carried = 0.0
    if get_exception(conn, entity_id, year) and _depth < 3:
        prev = entity_balance(conn, entity_id, year - 1, _depth + 1)
        if prev["remaining"] > 0:
            carried = prev["remaining"]
    used = funding_used(conn, entity_id, year)
    remaining = training_balance + carried - used
    return {
        "year": year,
        "contributions": contrib,
        "rate": rate,
        "training_balance": training_balance,
        "carried_from_previous": carried,
        "funding_used": used,
        "remaining": remaining,
    }


def balance_before_file(conn: sqlite3.Connection, entity_id: int, year: int,
                        file_number: int) -> dict:
    """المتبقي من الرصيد حتى الملف السابق للجهة (لاستمارة التسميح)."""
    bal = entity_balance(conn, entity_id, year)
    row = conn.execute(
        f"""SELECT COALESCE(SUM(funding_amount),0) t FROM training_files
            WHERE beneficiary_id=? AND {_file_year_expr()}=? AND file_number < ?""",
        (entity_id, str(year), file_number)).fetchone()
    used_before = float(row["t"])
    serial = conn.execute(
        f"""SELECT COUNT(*)+1 s FROM training_files
            WHERE beneficiary_id=? AND {_file_year_expr()}=? AND file_number < ?""",
        (entity_id, str(year), file_number)).fetchone()["s"]
    return {
        **bal,
        "used_before_file": used_before,
        "remaining_before_file": bal["training_balance"] + bal["carried_from_previous"] - used_before,
        "entity_year_serial": serial,
    }
