# -*- coding: utf-8 -*-
"""المصادقة والصلاحيات: أدوار، تحقق PBKDF2-SHA256، ومصفوفة صلاحيات."""
import hashlib
import hmac
import os
import sqlite3
from datetime import datetime
from typing import Optional

ROLES = {
    "admin": "مدير النظام",
    "data_entry": "موظف إدخال البيانات",
    "tech_reviewer": "مراجع فني",
    "finance_reviewer": "مراجع مالي",
    "viewer": "مستخدم للعرض والتقارير",
}

# الصلاحيات لكل دور
PERMISSIONS = {
    "admin": {"*"},
    "data_entry": {"file.create", "file.update", "file.view", "attachment.manage",
                   "import", "export", "report.view", "backup"},
    "tech_reviewer": {"file.view", "file.update", "review.technical", "attachment.manage",
                      "export", "report.view"},
    "finance_reviewer": {"file.view", "file.update", "review.financial", "finance.approve",
                         "export", "report.view"},
    "viewer": {"file.view", "export", "report.view"},
}


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return f"pbkdf2_sha256$200000${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _algo, iters, salt_hex, hash_hex = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                 bytes.fromhex(salt_hex), int(iters))
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


def authenticate(conn: sqlite3.Connection, username: str, password: str) -> Optional[dict]:
    row = conn.execute("SELECT * FROM users WHERE username=? AND active=1",
                       (username.strip(),)).fetchone()
    if not row or not verify_password(password, row["password_hash"]):
        return None
    conn.execute("UPDATE users SET last_login=? WHERE id=?",
                 (datetime.now().isoformat(timespec="seconds"), row["id"]))
    conn.commit()
    user = dict(row)
    user.pop("password_hash", None)
    return user


def has_permission(user: Optional[dict], permission: str) -> bool:
    if not user:
        return False
    perms = PERMISSIONS.get(user.get("role"), set())
    return "*" in perms or permission in perms


def create_user(conn: sqlite3.Connection, username: str, full_name: str,
                password: str, role: str, actor_id: Optional[int] = None) -> int:
    if role not in ROLES:
        raise ValueError("الدور غير معروف.")
    if len(password) < 6:
        raise ValueError("كلمة المرور يجب ألا تقل عن 6 أحرف.")
    cur = conn.execute(
        "INSERT INTO users (username, full_name, password_hash, role) VALUES (?,?,?,?)",
        (username.strip(), full_name.strip(), hash_password(password), role))
    conn.execute("INSERT INTO audit_log (user_id, action, entity, entity_id, details)"
                 " VALUES (?,?,?,?,?)",
                 (actor_id, "user.create", "users", cur.lastrowid, f"إنشاء مستخدم {username} بدور {ROLES[role]}"))
    conn.commit()
    return cur.lastrowid


def change_password(conn: sqlite3.Connection, user_id: int, new_password: str):
    if len(new_password) < 6:
        raise ValueError("كلمة المرور يجب ألا تقل عن 6 أحرف.")
    conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                 (hash_password(new_password), user_id))
    conn.commit()
