# -*- coding: utf-8 -*-
"""معاينة طباعة استمارة المراجعة: عرض صفحات PDF + طباعة + حفظ."""
from pathlib import Path

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QImage, QPainter, QPixmap
from PySide6.QtPrintSupport import QPrinter, QPrintPreviewDialog
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QMessageBox,
                               QPushButton, QScrollArea, QVBoxLayout, QWidget,
                               QFileDialog)


class PrintPreviewDialog(QDialog):
    """معاينة صفحات PDF (عبر QPdfDocument) مع أزرار طباعة وحفظ."""

    def __init__(self, pdf_path: Path, parent=None, title="معاينة قبل الطباعة"):
        super().__init__(parent)
        self.pdf_path = Path(pdf_path)
        self.setWindowTitle(title)
        self.resize(900, 750)

        layout = QVBoxLayout(self)
        self.warn_lbl = QLabel("")
        self.warn_lbl.setWordWrap(True)
        self.warn_lbl.setStyleSheet("color: #B7791F; font-weight: bold;")
        layout.addWidget(self.warn_lbl)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.pages_widget = QWidget()
        self.pages_layout = QVBoxLayout(self.pages_widget)
        self.pages_layout.setAlignment(Qt.AlignHCenter)
        self.scroll.setWidget(self.pages_widget)
        layout.addWidget(self.scroll, 1)

        row = QHBoxLayout()
        self.btn_print = QPushButton("طباعة")
        self.btn_print.setProperty("primary", True)
        self.btn_print.clicked.connect(self._print)
        self.btn_save = QPushButton("حفظ PDF")
        self.btn_save.clicked.connect(self._save)
        self.btn_close = QPushButton("إغلاق")
        self.btn_close.clicked.connect(self.reject)
        row.addWidget(self.btn_print)
        row.addWidget(self.btn_save)
        row.addStretch(1)
        row.addWidget(self.btn_close)
        layout.addLayout(row)

        self._load()

    def set_warning(self, text: str):
        self.warn_lbl.setText(text)

    def _load(self):
        try:
            from PySide6.QtPdf import QPdfDocument
        except ImportError:
            QMessageBox.warning(self, "تنبيه", "معاينة PDF غير متاحة — سيُفتح الملف في العارض الخارجي.")
            self._open_external()
            return
        self.doc = QPdfDocument(self)
        if self.doc.load(str(self.pdf_path)) != QPdfDocument.Error.None_:
            QMessageBox.critical(self, "خطأ", "تعذر فتح ملف PDF.")
            return
        for i in range(self.doc.pageCount()):
            pix = self.doc.render(i, QSize(794, 1123))  # A4 تقريبًا
            lbl = QLabel()
            lbl.setPixmap(QPixmap.fromImage(pix))
            lbl.setStyleSheet("border: 1px solid #9AA3B2; background: white;")
            self.pages_layout.addWidget(lbl)

    def _print(self):
        printer = QPrinter(QPrinter.HighResolution)
        dlg = QPrintPreviewDialog(printer, self)
        dlg.setWindowTitle("معاينة الطباعة")
        dlg.paintRequested.connect(lambda p: self._paint_printer(p, printer))
        dlg.exec()

    def _paint_printer(self, printer: QPrinter):
        try:
            from PySide6.QtPdf import QPdfDocument
        except ImportError:
            return
        doc = QPdfDocument(self)
        if doc.load(str(self.pdf_path)) != QPdfDocument.Error.None_:
            return
        painter = QPainter(printer)
        for i in range(doc.pageCount()):
            if i > 0:
                printer.newPage()
            img = doc.render(i, printer.pageRect(QPrinter.DevicePixel).size().toSize())
            rect = painter.viewport()
            scaled = img.scaled(rect.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            x = (rect.width() - scaled.width()) // 2
            painter.drawImage(x, 0, scaled)
        painter.end()

    def _save(self):
        dest, _ = QFileDialog.getSaveFileName(self, "حفظ الاستمارة PDF",
                                              self.pdf_path.name, "PDF (*.pdf)")
        if dest:
            import shutil
            shutil.copy2(self.pdf_path, dest)
            QMessageBox.information(self, "تم", "تم حفظ نسخة PDF.")

    def _open_external(self):
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.pdf_path)))
        self.accept()
