# -*- coding: utf-8 -*-
"""سير عمل الملف: الحالات، الانتقالات المسموحة، وشروط الاعتماد."""

# (الرمز، الاسم، نهائية؟)
STATUSES = [
    ("new", "ملف جديد", 0),
    ("received", "مستلم من الفرع", 0),
    ("tech_review", "قيد المراجعة الفنية", 0),
    ("missing_docs", "توجد نواقص", 0),
    ("returned", "معاد للاستكمال", 0),
    ("tech_done", "مكتمل فنيًا", 0),
    ("finance_review", "قيد المراجعة المالية", 0),
    ("ready_approve", "جاهز للاعتماد", 0),
    ("approved", "معتمد", 1),
    ("rejected", "مرفوض", 1),
    ("archived", "مغلق ومؤرشف", 1),
]

STATUS_NAMES = {code: name for code, name, _ in STATUSES}
TERMINAL = {code for code, _, t in STATUSES if t}

# الانتقالات المنطقية المسموحة
TRANSITIONS = [
    ("new", "received"),
    ("new", "rejected"),
    ("received", "tech_review"),
    ("received", "returned"),
    ("received", "rejected"),
    ("tech_review", "missing_docs"),
    ("tech_review", "tech_done"),
    ("tech_review", "returned"),
    ("tech_review", "rejected"),
    ("missing_docs", "tech_review"),
    ("missing_docs", "returned"),
    ("returned", "received"),
    ("returned", "tech_review"),
    ("tech_done", "finance_review"),
    ("tech_done", "returned"),
    ("finance_review", "ready_approve"),
    ("finance_review", "returned"),
    ("finance_review", "tech_review"),
    ("ready_approve", "approved"),
    ("ready_approve", "rejected"),
    ("ready_approve", "finance_review"),
    ("approved", "archived"),
    ("rejected", "archived"),
    ("rejected", "received"),
]

_ALLOWED = set(TRANSITIONS)


def can_transition(from_code: str, to_code: str) -> bool:
    """هل الانتقال بين الحالتين منطقي ومسموح؟"""
    if from_code == to_code:
        return False
    return (from_code, to_code) in _ALLOWED


def next_statuses(from_code: str):
    """الحالات المسموح الانتقال إليها من حالة معينة."""
    return [to_code for fc, to_code in TRANSITIONS if fc == from_code]


# ----------------------------------------------------------------------
# شروط الاعتماد — لا يُسمح بالانتقال إلى «معتمد» إلا باستيفائها أو استثناء موثق
# ----------------------------------------------------------------------

REQUIRED_FINANCIAL_FIELDS = [
    ("approved_trainees", "العدد المعتمد للمتدربين"),
    ("approved_cost_per_trainee", "تكلفة المتدرب المعتمدة"),
    ("approved_hours", "عدد الساعات المعتمدة"),
    ("funding_amount", "مبلغ التمويل"),
]


def approval_blockers(file_rec: dict, review_items: list) -> list:
    """
    قائمة موانع الاعتماد. فارغة = جاهز للاعتماد.
    file_rec: قاموس حقول الملف. review_items: قائمة قواميس بنتيجة كل وثيقة.
    """
    blockers = []
    for field, label in REQUIRED_FINANCIAL_FIELDS:
        if file_rec.get(field) in (None, ""):
            blockers.append(f"الحقل المالي الإلزامي غير مكتمل: {label}")
    for item in review_items:
        result = item.get("result")
        name = item.get("document_name", "")
        if result in ("غير مطابق", "غير مكتمل"):
            blockers.append(f"وثيقة تحتاج معالجة: {name} ({result})")
        elif result in ("لم يراجع", None):
            # الوثائق غير المطلوبة أصلًا (غير منطبق) ليست مانعًا
            if item.get("required_default", 1):
                blockers.append(f"وثيقة لم تُراجع بعد: {name}")
    return blockers
