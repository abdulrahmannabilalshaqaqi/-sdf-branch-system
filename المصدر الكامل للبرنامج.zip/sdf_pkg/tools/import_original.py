# -*- coding: utf-8 -*-
"""اختبار قبول: استيراد الملف الأصلي الحقيقي (ورقة2) إلى قاعدة اختبار."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services import import_service as imp

SRC = Path("/home/hatch/workspace/user/files/______________________________________________________0_0qvq.xlsm")

def main():
    db_path = Path("/tmp/sdf_import_test.db")
    if db_path.exists():
        db_path.unlink()
    database = Database(db_path)
    conn = database.connect()
    seed_all(conn)

    print("الأوراق:", imp.list_sheets(SRC))
    prev = imp.preview_sheet(SRC, "ورقة2", n_rows=3)
    print("عدد الأعمدة:", len(prev["headers"]), "| عدد الصفوف:", prev["total_rows"])
    mapping = imp.auto_map_columns(prev["headers"])
    print("أعمدة مطابقة تلقائيًا:", len(mapping), "من", len([h for h in prev['headers'] if h]))

    results = imp.analyze_rows(SRC, "ورقة2", mapping, conn)
    summary = imp.summarize_analysis(results)
    print("ملخص التحليل:", summary)

    # عينة من الصفوف ذات الأخطاء
    shown = 0
    for r in results:
        if r.status == "error" and shown < 5:
            print(f"  صف {r.excel_row}: {r.errors[0][:100]}")
            shown += 1

    report = imp.execute_import(conn, results, duplicate_policy="skip",
                                source_file=str(SRC), sheet_name="ورقة2")
    print("تقرير الاستيراد:", {k: v for k, v in report.items() if k != "report"})

    n = conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"]
    print("السجلات في قاعدة البيانات:", n)

    # تحقق: إعادة حساب معادلة لعينة ومقارنتها بالمخزنة في Excel
    from sdf_app.core.finance import summarize
    row = conn.execute("SELECT * FROM training_files WHERE file_number=7").fetchone()
    rec = dict(row)
    s = summarize(rec)
    print(f"ملف 7: إجمالي العقد المحسوب={s['contract_total']} | التمويل={rec['funding_amount']}")

    n_branches = conn.execute("SELECT COUNT(*) c FROM branches").fetchone()["c"]
    n_entities = conn.execute("SELECT COUNT(*) c FROM entities").fetchone()["c"]
    n_trainers = conn.execute("SELECT COUNT(*) c FROM trainers").fetchone()["c"]
    print(f"فروع: {n_branches} | جهات: {n_entities} | مدربون: {n_trainers}")
    database.close()

if __name__ == "__main__":
    main()
