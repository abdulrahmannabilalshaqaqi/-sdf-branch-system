# -*- coding: utf-8 -*-
"""المصادقة والصلاحيات: أدوار، تحقق PBKDF2-SHA256، ومصفوفة صلاحيات."""
import hashlib
import hmac
import os
import sqlite3
from datetime import datetime
from typing import Dict, Optional

ROLES = {
    "admin": "مدير النظام",
    "data_entry": "موظف إدخال البيانات",
    "tech_reviewer": "مراجع فني",
    "finance_reviewer": "مراجع مالي",
    "viewer": "مستخدم للعرض والتقارير",
}

# الصلاحيات لكل دور
PERMISSIONS = {
    "admin": {"*"},
    "data_entry": {"file.create", "file.update", "file.view", "attachment.manage",
                   "import", "export", "report.view", "backup"},
    "tech_reviewer": {"file.view", "file.update", "review.technical", "attachment.manage",
                      "export", "report.view"},
    "finance_reviewer": {"file.view", "file.update", "review.financial", "finance.approve",
                         "export", "report.view"},
    "viewer": {"file.view", "export", "report.view"},
}

# كتالوج الصلاحيات لشاشة مصفوفة الصلاحيات (الرمز، التسمية)
PERMISSION_CATALOG = [
    ("file.view", "عرض الملفات"),
    ("file.create", "إنشاء ملف"),
    ("file.update", "تعديل الملفات"),
    ("attachment.manage", "إدارة المرفقات"),
    ("review.technical", "المراجعة الفنية"),
    ("review.financial", "المراجعة المالية"),
    ("finance.approve", "الاعتماد المالي"),
    ("disburse.manage", "إدارة الصرف"),
    ("contrib.manage", "إدارة المساهمات"),
    ("import", "الاستيراد من Excel"),
    ("export", "التصدير"),
    ("report.view", "التقارير والطباعة"),
    ("settings.manage", "الإعدادات"),
    ("user.manage", "إدارة المستخدمين"),
    ("backup", "النسخ الاحتياطي"),
]


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return f"pbkdf2_sha256$200000${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _algo, iters, salt_hex, hash_hex = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                                 bytes.fromhex(salt_hex), int(iters))
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


def authenticate(conn: sqlite3.Connection, username: str, password: str) -> Optional[dict]:
    row = conn.execute("SELECT * FROM users WHERE username=? AND active=1",
                       (username.strip(),)).fetchone()
    if not row or not verify_password(password, row["password_hash"]):
        return None
    conn.execute("UPDATE users SET last_login=? WHERE id=?",
                 (datetime.now().isoformat(timespec="seconds"), row["id"]))
    conn.commit()
    user = dict(row)
    user.pop("password_hash", None)
    return user


def has_permission(user: Optional[dict], permission: str, conn=None) -> bool:
    """فحص الصلاحية: تجاوز المستخدم ← تجاوز الدور ← الافتراضي.
    conn اختياري؛ بدونه يُستخدم الافتراضي فقط (مفيد للاختبارات)."""
    if not user:
        return False
    role = user.get("role")
    if conn is not None:
        try:
            uid = user.get("id")
            if uid:
                r = conn.execute(
                    "SELECT allowed FROM user_permissions WHERE user_id=? AND permission=?",
                    (uid, permission)).fetchone()
                if r is not None:
                    return bool(r["allowed"])
            r = conn.execute(
                "SELECT allowed FROM role_permissions WHERE role=? AND permission=?",
                (role, permission)).fetchone()
            if r is not None:
                return bool(r["allowed"])
        except Exception:
            pass  # الجداول قد لا توجد في قواعد قديمة جدًا — نرجع للافتراضي
    perms = PERMISSIONS.get(role, set())
    return "*" in perms or permission in perms


def set_role_permission(conn: sqlite3.Connection, role: str, permission: str,
                        allowed: bool, actor_id: Optional[int] = None):
    """تحديد صلاحية لدور كامل (تجاوز على الافتراضي)."""
    if role not in ROLES:
        raise ValueError("الدور غير معروف.")
    conn.execute(
        """INSERT INTO role_permissions (role, permission, allowed) VALUES (?,?,?)
           ON CONFLICT(role, permission) DO UPDATE SET allowed=excluded.allowed""",
        (role, permission, 1 if allowed else 0))
    conn.execute("INSERT INTO audit_log (user_id, action, entity, details) VALUES (?,?,?,?)",
                 (actor_id, "permission.role_change", "role_permissions",
                  f"الدور {role} — الصلاحية {permission}: {'ممنوحة' if allowed else 'محظورة'}"))
    conn.commit()


def set_user_permission(conn: sqlite3.Connection, user_id: int, permission: str,
                        allowed: bool, actor_id: Optional[int] = None):
    """تجاوز صلاحية لمستخدم معين (فوق صلاحيات دوره)."""
    conn.execute(
        """INSERT INTO user_permissions (user_id, permission, allowed) VALUES (?,?,?)
           ON CONFLICT(user_id, permission) DO UPDATE SET allowed=excluded.allowed""",
        (user_id, permission, 1 if allowed else 0))
    conn.execute("INSERT INTO audit_log (user_id, action, entity, entity_id, details)"
                 " VALUES (?,?,?,?,?)",
                 (actor_id, "permission.user_change", "user_permissions", user_id,
                  f"الصلاحية {permission}: {'ممنوحة' if allowed else 'محظورة'}"))
    conn.commit()


def clear_user_permission(conn: sqlite3.Connection, user_id: int, permission: str):
    conn.execute("DELETE FROM user_permissions WHERE user_id=? AND permission=?",
                 (user_id, permission))
    conn.commit()


def clear_role_permission(conn: sqlite3.Connection, role: str, permission: str):
    conn.execute("DELETE FROM role_permissions WHERE role=? AND permission=?",
                 (role, permission))
    conn.commit()


def effective_permissions(user: dict, conn=None) -> Dict[str, bool]:
    """الصلاحيات الفعلية لمستخدم (للعرض في المصفوفة)."""
    return {code: has_permission(user, code, conn) for code, _ in PERMISSION_CATALOG}


def create_user(conn: sqlite3.Connection, username: str, full_name: str,
                password: str, role: str, actor_id: Optional[int] = None) -> int:
    if role not in ROLES:
        raise ValueError("الدور غير معروف.")
    if len(password) < 6:
        raise ValueError("كلمة المرور يجب ألا تقل عن 6 أحرف.")
    cur = conn.execute(
        "INSERT INTO users (username, full_name, password_hash, role) VALUES (?,?,?,?)",
        (username.strip(), full_name.strip(), hash_password(password), role))
    conn.execute("INSERT INTO audit_log (user_id, action, entity, entity_id, details)"
                 " VALUES (?,?,?,?,?)",
                 (actor_id, "user.create", "users", cur.lastrowid, f"إنشاء مستخدم {username} بدور {ROLES[role]}"))
    conn.commit()
    return cur.lastrowid


def change_password(conn: sqlite3.Connection, user_id: int, new_password: str):
    if len(new_password) < 6:
        raise ValueError("كلمة المرور يجب ألا تقل عن 6 أحرف.")
    conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                 (hash_password(new_password), user_id))
    conn.commit()
