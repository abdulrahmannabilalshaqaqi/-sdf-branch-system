# -*- coding: utf-8 -*-
"""اختبارات المزايا المضافة: الترحيل v2، رقم العقد، استيراد xls، حذف المرفقات، فلاتر البحث."""
import sqlite3
from pathlib import Path

import pytest

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services import import_service as imp


@pytest.fixture()
def conn(tmp_path):
    db = Database(tmp_path / "t.db")
    c = db.connect()
    seed_all(c)
    yield c
    db.close()


def _make_file(conn, num=1, **kw):
    from sdf_app.services.file_service import FileService
    fs = FileService(conn)
    data = {"file_number": num, "program_name": "برنامج", "received_date": "2024-01-05"}
    data.update(kw)
    return fs.create(data, user_id=1)


def test_migration_v2_adds_contract_number(tmp_path):
    # قاعدة قديمة: v1 بدون العمود
    p = tmp_path / "old.db"
    c = Database(p).connect()
    c.execute("ALTER TABLE training_files DROP COLUMN contract_number")
    c.execute("DELETE FROM schema_migrations WHERE version=2")
    c.commit()
    c.close()
    c2 = Database(p).connect()
    assert c2.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0] == 2
    assert "contract_number" in {r[1] for r in c2.execute("PRAGMA table_info(training_files)")}
    c2.close()


def test_contract_number_roundtrip(conn):
    fid = _make_file(conn, 101, contract_number="ع/2024/77")
    r = conn.execute("SELECT contract_number FROM training_files WHERE id=?", (fid,)).fetchone()
    assert r["contract_number"] == "ع/2024/77"


def test_xls_import(tmp_path, conn):
    xlwt = pytest.importorskip("xlwt")
    from datetime import datetime
    p = tmp_path / "t.xls"
    wb = xlwt.Workbook()
    ws = wb.add_sheet("ورقة2")
    for c, h in enumerate(["رقم الملف", "التكلفة المطالب بها من الجهة", "أسم البرنامج"]):
        ws.write(0, c, h)
    ws.write(1, 0, 5001)
    ws.write(1, 1, 120000)
    ws.write(1, 2, "برنامج xls")
    wb.save(str(p))
    assert imp.list_sheets(p) == ["ورقة2"]
    mapping = imp.auto_map_columns(imp.preview_sheet(p, "ورقة2")["headers"])
    results = imp.analyze_rows(p, "ورقة2", mapping, conn)
    rep = imp.execute_import(conn, results, source_file=str(p), sheet_name="ورقة2")
    assert rep["imported"] == 1 and rep["errored"] == 0
    r = conn.execute("SELECT claimed_amount FROM training_files WHERE file_number=5001").fetchone()
    assert r["claimed_amount"] == 120000


def test_delete_attachment_removes_file_and_audits(conn, tmp_path):
    from sdf_app import config
    fid = _make_file(conn, 102)
    d = tmp_path / "att" / str(fid)
    d.mkdir(parents=True)
    (d / "a.txt").write_text("x")
    conn.execute("INSERT INTO attachments (file_id, original_name, stored_name) VALUES (?,?,?)",
                 (fid, "a.txt", "a.txt"))
    conn.commit()
    # توجيه مجلد المرفقات مؤقتًا
    orig = config.attachments_dir
    config.attachments_dir = lambda: tmp_path / "att"
    try:
        from sdf_app.services.file_service import FileService
        ok = FileService(conn).delete_attachment(fid, 1, user_id=1)
    finally:
        config.attachments_dir = orig
    assert ok
    assert not (d / "a.txt").exists()
    assert conn.execute("SELECT COUNT(*) c FROM attachments").fetchone()["c"] == 0
    assert conn.execute(
        "SELECT COUNT(*) c FROM audit_log WHERE action='attachment.delete'").fetchone()["c"] == 1


def test_search_status_codes_and_overdue(conn):
    from sdf_app.services.file_service import FileService
    fs = FileService(conn)
    _make_file(conn, 201, received_date="2020-01-01")  # متأخر
    _make_file(conn, 202, received_date="2026-10-01")  # حديث
    rows, total = fs.search({"status_codes": ["new"]})
    assert total == 2
    rows, total = fs.search({"overdue_days": 30})
    assert total == 1 and rows[0]["file_number"] == 201
    rows, total = fs.search({"status_codes": ["new"], "overdue_days": 30})
    assert total == 1
