# -*- coding: utf-8 -*-
"""فحص شامل لملف Excel الأصلي: الأوراق، العناوين، البيانات، المعادلات، القوائم، الدمج."""
import sys
from openpyxl import load_workbook

SRC = "/home/hatch/workspace/user/files/______________________________________________________0_0qvq.xlsm"

def main():
    wb = load_workbook(SRC, data_only=False, read_only=False)
    print("=" * 80)
    print("أسماء الأوراق:", wb.sheetnames)
    print("الأسماء المعرفة (Defined names):")
    try:
        dns = list(wb.defined_names.values())
    except Exception:
        dns = []
    for dn in dns:
        print(f"  - {dn.name} -> {dn.value}")
    print("=" * 80)
    for ws in wb.worksheets:
        print(f"\n### الورقة: {ws.title}")
        print(f"الأبعاد: {ws.dimensions} | max_row={ws.max_row} max_col={ws.max_column}")
        print(f"اتجاه RTL: {ws.sheet_view.rightToLeft}")
        print(f"الخلايا المدمجة: {len(list(ws.merged_cells.ranges))}")
        for mr in list(ws.merged_cells.ranges)[:20]:
            print(f"    مدمجة: {mr}")
        # أول 25 صفًا غير فارغ
        print("--- أول الصفوف ذات المحتوى (حتى 25 صفًا) ---")
        shown = 0
        for row in ws.iter_rows(values_only=False):
            vals = [(c.coordinate, c.value) for c in row if c.value is not None]
            if not vals:
                continue
            shown += 1
            if shown > 25:
                print(f"    ... (توقف العرض عند 25 صفًا، إجمالي الصفوف {ws.max_row})")
                break
            cells = []
            for coord, v in vals:
                if isinstance(v, str) and v.startswith("="):
                    cells.append(f"{coord}=[معادلة: {v[:90]}]")
                else:
                    s = str(v)
                    cells.append(f"{coord}={s[:60]}")
            print(f"  صف {row[0].row}: " + " | ".join(cells))
        # المعادلات في كامل الورقة
        print("--- المعادلات المكتشفة ---")
        formulas = []
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str) and c.value.startswith("="):
                    formulas.append((c.coordinate, c.value))
        print(f"  عدد المعادلات: {len(formulas)}")
        for coord, f in formulas[:40]:
            print(f"    {coord}: {f}")
        # التحقق من صحة البيانات
        print("--- قوائم التحقق (Data Validation) ---")
        for dv in ws.data_validations.dataValidation:
            print(f"  النوع={dv.type} الصيغة={dv.formula1} النطاق={dv.sqref}")
        # التنسيق الشرطي
        print(f"--- التنسيق الشرطي: {len(list(ws.conditional_formatting))} قاعدة ---")

if __name__ == "__main__":
    main()
