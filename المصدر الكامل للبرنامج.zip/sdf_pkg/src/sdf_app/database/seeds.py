# -*- coding: utf-8 -*-
"""البذرة الأولية: الحالات، أنواع الوثائق، الإعدادات، المستخدم الإداري، وقوائم ورقة3."""
import hashlib
import os
import sqlite3

from ..core.workflow import STATUSES, TRANSITIONS

# أنواع الوثائق (من استمارة ورقة1 + المواصفات)
DOCUMENT_TYPES = [
    ("العقد", 1, 1),
    ("كشف الترشيحات", 1, 2),
    ("كشوفات الحضور والانصراف", 1, 3),
    ("بيانات المدرب ومؤهلاته", 1, 4),
    ("الترخيص (عند اشتراطه)", 0, 5),
    ("الشهادات", 1, 6),
    ("المادة العلمية", 1, 7),
    ("تقرير الإشراف", 1, 8),
    ("المطالبة المالية", 1, 9),
    ("مستندات أخرى", 0, 10),
]

DEFAULT_SETTINGS = [
    ("review_deadline_days", "30", "المدة المحددة للمراجعة بالأيام (للتنبيه بالملفات المتأخرة)"),
    ("funding_default_rule", "approved_total", "القاعدة الافتراضية لاقتراح مبلغ التمويل: approved_total | branch_approved | empty"),
    ("money_decimals", "2", "عدد الكسور العشرية عند عرض المبالغ"),
    ("currency", "ر.ي", "العملة المعروضة"),
    ("org_name", "صندوق تنمية المهارات", "اسم الجهة في التقارير"),
    ("office_name", "مكتب النائب لشؤون الفروع", "اسم المكتب في التقارير"),
    ("form_title", "استمارة مراجعة ملف برنامج تدريبي والمصادقة على التمويل", "عنوان الاستمارة المطبوعة"),
]

# بذرة ورقة3 (مختصرة — القيم الفعلية تُستورد من الملف الأصلي عند الاستيراد)
SEED_BRANCHES = ["تعز", "الحديدة", "عدن", "صنعاء", "إب", "حضرموت", "ذمار", "البيضاء", "مأرب", "الجوف"]
SEED_FIELDS = ["إداري", "مالي", "تسويق", "فني", "مهني", "حاسوب", "لغات"]


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return f"pbkdf2_sha256$200000${salt.hex()}${dk.hex()}"


def seed_all(conn: sqlite3.Connection, create_admin: bool = True):
    cur = conn.cursor()

    # الحالات
    for code, name, terminal in STATUSES:
        cur.execute(
            "INSERT OR IGNORE INTO file_statuses (code, name, sort_order, is_terminal) VALUES (?,?,?,?)",
            (code, name, STATUSES.index((code, name, terminal)), terminal),
        )
    conn.commit()
    status_ids = {r["code"]: r["id"] for r in conn.execute("SELECT id, code FROM file_statuses")}
    for from_code, to_code in TRANSITIONS:
        cur.execute(
            "INSERT OR IGNORE INTO status_transitions (from_status_id, to_status_id) VALUES (?,?)",
            (status_ids[from_code], status_ids[to_code]),
        )

    # أنواع الوثائق
    for name, required, order in DOCUMENT_TYPES:
        cur.execute(
            "INSERT OR IGNORE INTO document_types (name, required_default, sort_order) VALUES (?,?,?)",
            (name, required, order),
        )

    # الإعدادات
    for key, value, desc in DEFAULT_SETTINGS:
        cur.execute(
            "INSERT OR IGNORE INTO settings (key, value, description) VALUES (?,?,?)",
            (key, value, desc),
        )

    # الفروع والمجالات
    for name in SEED_BRANCHES:
        cur.execute("INSERT OR IGNORE INTO branches (name) VALUES (?)", (name,))
    for name in SEED_FIELDS:
        cur.execute("INSERT OR IGNORE INTO program_fields (name) VALUES (?)", (name,))

    # المستخدم الإداري الافتراضي
    if create_admin:
        cur.execute("SELECT COUNT(*) AS c FROM users")
        if cur.fetchone()["c"] == 0:
            cur.execute(
                "INSERT INTO users (username, full_name, password_hash, role) VALUES (?,?,?,?)",
                ("admin", "مدير النظام", hash_password("admin123"), "admin"),
            )
    conn.commit()
