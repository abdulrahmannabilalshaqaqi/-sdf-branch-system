# -*- coding: utf-8 -*-
"""صفحة الإعدادات: القوائم المرجعية، إعدادات النظام، المستخدمون، النسخ الاحتياطي."""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QFileDialog, QFormLayout, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QMessageBox,
                               QPushButton, QTabWidget, QVBoxLayout, QWidget,
                               QDialog, QDialogButtonBox, QSpinBox)

from .. import config
from ..services import backup_service
from ..services.auth_service import (ROLES, change_password, create_user,
                                     has_permission)


class SettingsPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)
        self.tabs.addTab(self._tab_lookups(), "القوائم المرجعية")
        self.tabs.addTab(self._tab_system(), "إعدادات النظام")
        if has_permission(ctx.user, "user.manage"):
            self.tabs.addTab(self._tab_users(), "المستخدمون")
        if has_permission(ctx.user, "backup"):
            self.tabs.addTab(self._tab_backup(), "النسخ الاحتياطي")

    # -- القوائم ------------------------------------------------------------------
    def _tab_lookups(self):
        w = QWidget()
        l = QVBoxLayout(w)
        row = QHBoxLayout()
        self.lookup_cb = QComboBox()
        self.lookup_cb.addItem("الفروع", ("branches", None))
        self.lookup_cb.addItem("مجالات البرامج", ("program_fields", None))
        self.lookup_cb.addItem("الجهات المستفيدة", ("entities", "beneficiary"))
        self.lookup_cb.addItem("الجهات المنفذة", ("entities", "implementing"))
        self.lookup_cb.addItem("أنواع الوثائق", ("document_types", None))
        self.lookup_cb.currentIndexChanged.connect(self._load_lookup)
        row.addWidget(QLabel("القائمة:"))
        row.addWidget(self.lookup_cb, 1)
        l.addLayout(row)
        self.lookup_list = QListWidget()
        l.addWidget(self.lookup_list, 1)
        btn_row = QHBoxLayout()
        self.new_name = QLineEdit()
        self.new_name.setPlaceholderText("اسم جديد")
        btn_add = QPushButton("إضافة")
        btn_add.clicked.connect(self._lookup_add)
        btn_del = QPushButton("حذف")
        btn_del.clicked.connect(self._lookup_del)
        btn_row.addWidget(self.new_name, 1)
        btn_row.addWidget(btn_add)
        btn_row.addWidget(btn_del)
        l.addLayout(btn_row)
        self._load_lookup()
        return w

    def _lookup_info(self):
        return self.lookup_cb.currentData()

    def _load_lookup(self):
        table, kind = self._lookup_info()
        self.lookup_list.clear()
        if table == "entities":
            rows = self.ctx.conn.execute(
                "SELECT id, name FROM entities WHERE kind=? AND active=1 ORDER BY name", (kind,))
        elif table == "document_types":
            rows = self.ctx.conn.execute("SELECT id, name FROM document_types ORDER BY sort_order")
        else:
            rows = self.ctx.conn.execute(f"SELECT id, name FROM {table} WHERE active=1 ORDER BY name")
        for r in rows:
            self.lookup_list.addItem(f"{r['name']}")
            self.lookup_list.item(self.lookup_list.count() - 1).setData(Qt.UserRole, r["id"])

    def _lookup_add(self):
        name = self.new_name.text().strip()
        if not name:
            return
        table, kind = self._lookup_info()
        try:
            if table == "entities":
                self.ctx.conn.execute("INSERT INTO entities (name, kind) VALUES (?,?)", (name, kind))
            elif table == "document_types":
                self.ctx.conn.execute("INSERT INTO document_types (name) VALUES (?)", (name,))
            else:
                self.ctx.conn.execute(f"INSERT INTO {table} (name) VALUES (?)", (name,))
            self.ctx.conn.commit()
        except Exception as exc:
            QMessageBox.warning(self, "تنبيه", f"تعذر الإضافة (ربما مكرر): {exc}")
            return
        self.new_name.clear()
        self._load_lookup()

    def _lookup_del(self):
        item = self.lookup_list.currentItem()
        if not item:
            return
        if QMessageBox.question(self, "تأكيد", f"حذف «{item.text()}»؟\n(لن تُحذف السجلات التاريخية المرتبطة)") != QMessageBox.Yes:
            return
        table, kind = self._lookup_info()
        _id = item.data(Qt.UserRole)
        if table in ("branches", "program_fields"):
            self.ctx.conn.execute(f"UPDATE {table} SET active=0 WHERE id=?", (_id,))
        elif table == "entities":
            self.ctx.conn.execute("UPDATE entities SET active=0 WHERE id=?", (_id,))
        else:
            self.ctx.conn.execute("UPDATE document_types SET active=0 WHERE id=?", (_id,))
        self.ctx.conn.commit()
        self._load_lookup()

    # -- إعدادات النظام ---------------------------------------------------------------
    def _tab_system(self):
        w = QWidget()
        form = QFormLayout(w)
        form.setLabelAlignment(Qt.AlignRight)
        s = self.ctx.settings()
        self.set_deadline = QSpinBox()
        self.set_deadline.setRange(1, 365)
        self.set_deadline.setValue(int(s.get("review_deadline_days", 30)))
        form.addRow("مدة المراجعة (يوم) للتنبيه بالتأخير:", self.set_deadline)

        self.set_funding = QComboBox()
        self.set_funding.addItem("التكلفة الإجمالية المعتمدة", "approved_total")
        self.set_funding.addItem("التكلفة المعتمدة من الفرع", "branch_approved")
        self.set_funding.addItem("بدون اقتراح (إدخال يدوي)", "empty")
        self.set_funding.setCurrentIndex(
            self.set_funding.findData(s.get("funding_default_rule", "approved_total")))
        form.addRow("القاعدة الافتراضية لاقتراح مبلغ التمويل:", self.set_funding)

        self.set_org = QLineEdit(s.get("org_name", ""))
        self.set_work = QLineEdit(s.get("office_name", ""))
        self.set_title = QLineEdit(s.get("form_title", ""))
        form.addRow("اسم الجهة في التقارير:", self.set_org)
        form.addWidget(self.set_work)
        form.addRow("اسم المكتب:", self.set_work)
        form.addRow("عنوان الاستمارة:", self.set_title)

        btn = QPushButton("حفظ الإعدادات")
        btn.setProperty("primary", True)
        btn.clicked.connect(self._save_system)
        form.addRow(btn)
        wrap = QVBoxLayout()
        wrap.addWidget(w)
        wrap.addStretch(1)
        page = QWidget()
        page.setLayout(wrap)
        return page

    def _save_system(self):
        self.ctx.set_setting("review_deadline_days", str(self.set_deadline.value()))
        self.ctx.set_setting("funding_default_rule", self.set_funding.currentData())
        self.ctx.set_setting("org_name", self.set_org.text().strip())
        self.ctx.set_setting("office_name", self.set_work.text().strip())
        self.ctx.set_setting("form_title", self.set_title.text().strip())
        QMessageBox.information(self, "تم", "تم حفظ الإعدادات.")

    # -- المستخدمون ----------------------------------------------------------------------
    def _tab_users(self):
        w = QWidget()
        l = QVBoxLayout(w)
        self.users_list = QListWidget()
        l.addWidget(self.users_list, 1)
        row = QHBoxLayout()
        btn_add = QPushButton("مستخدم جديد")
        btn_add.clicked.connect(self._user_add)
        btn_pass = QPushButton("تعيين كلمة مرور")
        btn_pass.clicked.connect(self._user_pass)
        btn_toggle = QPushButton("تفعيل/تعطيل")
        btn_toggle.clicked.connect(self._user_toggle)
        row.addWidget(btn_add)
        row.addWidget(btn_pass)
        row.addWidget(btn_toggle)
        row.addStretch(1)
        l.addLayout(row)
        self._load_users()
        return w

    def _load_users(self):
        self.users_list.clear()
        for r in self.ctx.conn.execute("SELECT id, username, full_name, role, active FROM users ORDER BY username"):
            status = "نشط" if r["active"] else "معطّل"
            self.users_list.addItem(f"{r['full_name']} ({r['username']}) — {ROLES.get(r['role'], '')} — {status}")
            self.users_list.item(self.users_list.count() - 1).setData(Qt.UserRole, r["id"])

    def _selected_user_id(self):
        item = self.users_list.currentItem()
        return item.data(Qt.UserRole) if item else None

    def _user_add(self):
        dlg = UserDialog(self)
        if dlg.exec():
            try:
                create_user(self.ctx.conn, dlg.username.text().strip(), dlg.fullname.text().strip(),
                            dlg.password.text(), dlg.role.currentData(),
                            actor_id=self.ctx.user["id"])
                self._load_users()
            except ValueError as exc:
                QMessageBox.warning(self, "تنبيه", str(exc))

    def _user_pass(self):
        uid = self._selected_user_id()
        if not uid:
            return
        dlg = PasswordDialog(self)
        if dlg.exec():
            try:
                change_password(self.ctx.conn, uid, dlg.password.text())
                QMessageBox.information(self, "تم", "تم تغيير كلمة المرور.")
            except ValueError as exc:
                QMessageBox.warning(self, "تنبيه", str(exc))

    def _user_toggle(self):
        uid = self._selected_user_id()
        if not uid:
            return
        if uid == self.ctx.user["id"]:
            QMessageBox.warning(self, "تنبيه", "لا يمكنك تعطيل حسابك الحالي.")
            return
        self.ctx.conn.execute("UPDATE users SET active = 1 - active WHERE id=?", (uid,))
        self.ctx.conn.commit()
        self._load_users()

    # -- النسخ الاحتياطي -----------------------------------------------------------------------
    def _tab_backup(self):
        w = QWidget()
        l = QVBoxLayout(w)
        row = QHBoxLayout()
        btn_now = QPushButton("إنشاء نسخة احتياطية الآن")
        btn_now.setProperty("primary", True)
        btn_now.clicked.connect(self._backup_now)
        btn_restore = QPushButton("استعادة من نسخة...")
        btn_restore.clicked.connect(self._backup_restore)
        row.addWidget(btn_now)
        row.addWidget(btn_restore)
        row.addStretch(1)
        l.addLayout(row)
        self.backup_list = QListWidget()
        l.addWidget(self.backup_list, 1)
        self._load_backups()
        return w

    def _load_backups(self):
        self.backup_list.clear()
        for r in self.ctx.conn.execute("SELECT path, created_at, size_bytes, verified FROM backup_history ORDER BY created_at DESC"):
            kb = (r["size_bytes"] or 0) / 1024
            v = "✓ تم التحقق" if r["verified"] else ""
            self.backup_list.addItem(f"{r['created_at'][:16]} — {Path(r['path']).name} ({kb:.0f} KB) {v}")

    def _backup_now(self):
        try:
            path = backup_service.create_backup(self.ctx.conn, include_attachments=True)
            backup_service.cleanup_old_backups(self.ctx.conn, keep=10)
            self._load_backups()
            QMessageBox.information(self, "تم", f"تم إنشاء النسخة الاحتياطية:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "فشل النسخ الاحتياطي", f"تنبيه: فشل إنشاء النسخة!\n{exc}")

    def _backup_restore(self):
        path, _ = QFileDialog.getOpenFileName(self, "اختر ملف النسخة الاحتياطية", "", "ZIP (*.zip)")
        if not path:
            return
        if QMessageBox.question(
                self, "تأكيد الاستعادة",
                "سيتم استبدال قاعدة البيانات الحالية بالنسخة المحددة.\n"
                "تأكد من وجود نسخة احتياطية حديثة قبل المتابعة.\n\nمتابعة؟") != QMessageBox.Yes:
            return
        try:
            # نسخة أمان تلقائية قبل الاستعادة
            backup_service.create_backup(self.ctx.conn, notes="تلقائية قبل الاستعادة")
            backup_service.restore_backup(Path(path), confirm=True)
            QMessageBox.information(self, "تم", "تمت الاستعادة. أعد تشغيل البرنامج.")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشلت الاستعادة: {exc}")

    def refresh(self):
        pass


class UserDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("مستخدم جديد")
        l = QFormLayout(self)
        l.setLabelAlignment(Qt.AlignRight)
        self.username = QLineEdit()
        self.fullname = QLineEdit()
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.role = QComboBox()
        for code, name in ROLES.items():
            self.role.addItem(name, code)
        l.addRow("اسم المستخدم:", self.username)
        l.addRow("الاسم الكامل:", self.fullname)
        l.addRow("كلمة المرور:", self.password)
        l.addRow("الدور:", self.role)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("إضافة")
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        l.addRow(btns)


class PasswordDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("تعيين كلمة مرور")
        l = QFormLayout(self)
        l.setLabelAlignment(Qt.AlignRight)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        l.addRow("كلمة المرور الجديدة:", self.password)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("تعيين")
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        l.addRow(btns)
