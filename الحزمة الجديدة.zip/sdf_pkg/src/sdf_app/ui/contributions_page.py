# -*- coding: utf-8 -*-
"""صفحة المساهمات الشهرية: الجهة × الشهر + رصيد التدريب + النسب والاستثناءات."""
from datetime import date

from PySide6.QtCore import Qt, QDate
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDateEdit, QDoubleSpinBox,
                               QGroupBox, QHBoxLayout, QLabel, QMessageBox,
                               QPushButton, QSpinBox, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget,
                               QDialog, QDialogButtonBox, QFormLayout)

from ..core.finance import format_money
from ..services import contribution_service as contrib
from ..services.auth_service import has_permission
from .widgets import rtl_align

MONTHS_AR = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
             "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


class ContributionsPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        layout = QVBoxLayout(self)

        # -- اختيار الجهة والسنة ---------------------------------------------------
        top = QHBoxLayout()
        top.addWidget(QLabel("الجهة المستفيدة:"))
        self.entity_cb = QComboBox()
        self.entity_cb.setMinimumWidth(280)
        self.entity_cb.currentIndexChanged.connect(self.refresh)
        top.addWidget(self.entity_cb)
        top.addWidget(QLabel("السنة:"))
        self.year_spin = QSpinBox()
        self.year_spin.setRange(2000, 2100)
        self.year_spin.setValue(date.today().year)
        self.year_spin.valueChanged.connect(self.refresh)
        top.addWidget(self.year_spin)
        self.exc_chk = QCheckBox("استثناء: الاستفادة من رصيد العام السابق")
        self.exc_chk.stateChanged.connect(self._toggle_exception)
        top.addWidget(self.exc_chk)
        top.addStretch(1)
        layout.addLayout(top)

        mid = QHBoxLayout()

        # -- جدول الشهور -------------------------------------------------------------
        g = QGroupBox("المساهمات الشهرية")
        gl = QVBoxLayout(g)
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(
            ["الشهر", "مساهمة شهرية", "فترة سابقة", "ملاحظات"])
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        gl.addWidget(self.table)
        btn_save = QPushButton("حفظ المساهمات")
        btn_save.setProperty("primary", True)
        btn_save.clicked.connect(self._save)
        gl.addWidget(btn_save)
        mid.addWidget(g, 3)

        # -- الرصيد والنسب --------------------------------------------------------------
        side = QVBoxLayout()
        gb = QGroupBox("رصيد التدريب")
        bl = QVBoxLayout(gb)
        self.balance_lbl = QLabel("—")
        self.balance_lbl.setWordWrap(True)
        bl.addWidget(self.balance_lbl)
        side.addWidget(gb)

        gr = QGroupBox("نسب رصيد التدريب (مدير النظام)")
        rl = QVBoxLayout(gr)
        self.rates_lbl = QLabel("")
        self.rates_lbl.setWordWrap(True)
        rl.addWidget(self.rates_lbl)
        self.btn_rate = QPushButton("تعديل النسبة")
        self.btn_rate.clicked.connect(self._edit_rate)
        rl.addWidget(self.btn_rate)
        side.addWidget(gr)
        side.addStretch(1)
        side_w = QWidget()
        side_w.setLayout(side)
        mid.addWidget(side_w, 2)

        layout.addLayout(mid, 1)
        self._load_entities()
        rtl_align(self)

    def _can_manage(self):
        return has_permission(self.ctx.user, "contrib.manage", self.ctx.conn)

    def _is_admin(self):
        return has_permission(self.ctx.user, "settings.manage", self.ctx.conn)

    def _load_entities(self):
        self.entity_cb.clear()
        for r in self.ctx.conn.execute(
                "SELECT id, name FROM entities WHERE kind='beneficiary' AND active=1 ORDER BY name"):
            self.entity_cb.addItem(r["name"], r["id"])
        self.entity_cb.setCurrentIndex(-1)

    def _entity_id(self):
        return self.entity_cb.currentData()

    def refresh(self):
        eid = self._entity_id()
        year = self.year_spin.value()
        # النسب
        rates = contrib.list_rates(self.ctx.conn)
        self.rates_lbl.setText("\n".join(
            f"{r['rate'] * 100:.0f}% اعتبارًا من {r['effective_from']}" for r in rates) or "—")
        self.btn_rate.setEnabled(self._is_admin())
        if not eid:
            self.table.setRowCount(0)
            self.balance_lbl.setText("اختر الجهة المستفيدة.")
            return
        # الاستثناء
        self.exc_chk.blockSignals(True)
        self.exc_chk.setChecked(contrib.get_exception(self.ctx.conn, eid, year))
        self.exc_chk.blockSignals(False)
        self.exc_chk.setEnabled(self._is_admin())
        # الجدول
        data = contrib.list_contributions(self.ctx.conn, eid, year)
        self.table.setRowCount(12)
        for m in range(1, 13):
            self.table.setItem(m - 1, 0, QTableWidgetItem(MONTHS_AR[m - 1]))
            self.table.item(m - 1, 0).setFlags(Qt.ItemIsEnabled)
            for col, kind in ((1, "monthly"), (2, "previous_period")):
                rec = data.get((m, kind))
                item = QTableWidgetItem(
                    str(rec["amount"]) if rec and rec["amount"] else "")
                item.setTextAlignment(Qt.AlignRight)
                item.setData(Qt.UserRole, kind)
                self.table.setItem(m - 1, col, item)
            rec_any = data.get((m, "monthly")) or data.get((m, "previous_period"))
            self.table.setItem(m - 1, 3, QTableWidgetItem(rec_any["notes"] if rec_any and rec_any["notes"] else ""))
        self.table.resizeColumnsToContents()
        # الرصيد
        try:
            bal = contrib.entity_balance(self.ctx.conn, eid, year)
            self.balance_lbl.setText(
                f"سنة {year} — النسبة السارية: {bal['rate'] * 100:.0f}%\n"
                f"إجمالي المساهمات: {format_money(bal['contributions'])}\n"
                f"رصيد التدريب: {format_money(bal['training_balance'])}\n"
                f"مرحّل من العام السابق: {format_money(bal['carried_from_previous'])}\n"
                f"المستخدم (مبالغ التمويل): {format_money(bal['funding_used'])}\n"
                f"المتبقي: {format_money(bal['remaining'])}")
        except Exception as exc:
            self.balance_lbl.setText(f"تعذر الحساب: {exc}")

    def _toggle_exception(self, state):
        eid = self._entity_id()
        if not eid or not self._is_admin():
            return
        contrib.set_exception(self.ctx.conn, eid, self.year_spin.value(),
                              bool(state),
                              user_id=self.ctx.user["id"] if self.ctx.user else None)
        self.refresh()

    def _save(self):
        eid = self._entity_id()
        if not eid:
            QMessageBox.information(self, "تنبيه", "اختر الجهة أولًا.")
            return
        if not self._can_manage():
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة المساهمات.")
            return
        year = self.year_spin.value()
        uid = self.ctx.user["id"] if self.ctx.user else None
        for m in range(1, 13):
            notes = (self.table.item(m - 1, 3).text().strip()
                     if self.table.item(m - 1, 3) else "")
            for col, kind in ((1, "monthly"), (2, "previous_period")):
                item = self.table.item(m - 1, col)
                text = (item.text().strip() if item else "").replace(",", "")
                amount = None
                if text:
                    try:
                        amount = float(text)
                    except ValueError:
                        QMessageBox.warning(self, "تنبيه",
                                            f"قيمة غير صالحة في {MONTHS_AR[m-1]}.")
                        return
                contrib.upsert_contribution(self.ctx.conn, eid, year, m, amount,
                                            kind=kind, notes=notes, user_id=uid)
        QMessageBox.information(self, "تم", "تم حفظ المساهمات.")
        self.refresh()

    def _edit_rate(self):
        dlg = RateDialog(self.ctx, parent=self)
        if dlg.exec():
            self.refresh()


class RateDialog(QDialog):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.setWindowTitle("تعديل نسبة رصيد التدريب")
        form = QFormLayout(self)
        form.setLabelAlignment(Qt.AlignRight)
        self.rate_spin = QDoubleSpinBox()
        self.rate_spin.setRange(1, 100)
        self.rate_spin.setDecimals(1)
        self.rate_spin.setSuffix(" %")
        self.rate_spin.setValue(contrib.current_rate(ctx.conn) * 100)
        self.date_edit = QDateEdit(QDate.currentDate())
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("yyyy-MM-dd")
        form.addRow("النسبة الجديدة:", self.rate_spin)
        form.addRow("تاريخ السريان:", self.date_edit)
        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Save).setText("حفظ")
        btns.button(QDialogButtonBox.Save).setProperty("primary", True)
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(self.save)
        btns.rejected.connect(self.reject)
        form.addRow(btns)
        rtl_align(self)

    def save(self):
        try:
            contrib.set_rate(self.ctx.conn, self.rate_spin.value() / 100,
                             self.date_edit.date().toString("yyyy-MM-dd"),
                             user_id=self.ctx.user["id"] if self.ctx.user else None)
            self.accept()
        except ValueError as exc:
            QMessageBox.warning(self, "تنبيه", str(exc))
