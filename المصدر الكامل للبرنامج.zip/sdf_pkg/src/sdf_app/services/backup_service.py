# -*- coding: utf-8 -*-
"""النسخ الاحتياطي والاستعادة: نسخ آمن عبر SQLite backup API + أرشفة المرفقات."""
import shutil
import sqlite3
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

from .. import config


def create_backup(conn: sqlite3.Connection, include_attachments: bool = True,
                  dest_dir: Optional[Path] = None,
                  notes: str = "") -> Path:
    """إنشاء نسخة احتياطية. يعيد مسار ملف الـ zip."""
    dest_dir = Path(dest_dir) if dest_dir else config.backups_dir()
    dest_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    tmp_db = dest_dir / f"sdf_{stamp}.db"
    try:
        # نسخ آمن أثناء العمل عبر backup API
        target = sqlite3.connect(str(tmp_db))
        with target:
            conn.backup(target)
        target.close()
        if not verify_backup(tmp_db):
            raise RuntimeError("فشل التحقق من سلامة النسخة الاحتياطية.")
        zip_path = dest_dir / f"sdf_backup_{stamp}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(tmp_db, arcname="sdf.db")
            if include_attachments:
                att = config.attachments_dir()
                if att.exists():
                    for f in att.rglob("*"):
                        if f.is_file():
                            zf.write(f, arcname=str(Path("attachments") / f.relative_to(att)))
        conn.execute(
            "INSERT INTO backup_history (path, size_bytes, includes_attachments, verified, notes)"
            " VALUES (?,?,?,?,?)",
            (str(zip_path), zip_path.stat().st_size, int(include_attachments), 1, notes))
        conn.commit()
        return zip_path
    finally:
        if tmp_db.exists():
            tmp_db.unlink()


def verify_backup(db_path: Path) -> bool:
    """التحقق من سلامة نسخة: فتح + فحص سريع + وجود الجداول الأساسية."""
    try:
        conn = sqlite3.connect(str(db_path))
        conn.execute("PRAGMA quick_check").fetchone()
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        conn.close()
        return {"training_files", "users", "file_statuses"} <= tables
    except Exception:
        return False


def restore_backup(zip_path: Path, confirm: bool = False) -> Path:
    """
    استعادة نسخة احتياطية. تتطلب confirm=True صراحةً (حماية من الاستبدال غير المقصود).
    تُنشئ نسخة احتياطية تلقائية للوضع الحالي قبل الاستعادة.
    """
    if not confirm:
        raise PermissionError("الاستعادة تتطلب تأكيدًا صريحًا (confirm=True).")
    zip_path = Path(zip_path)
    if not zipfile.is_zipfile(zip_path):
        raise ValueError("ملف النسخة الاحتياطية غير صالح.")
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        if "sdf.db" not in names:
            raise ValueError("الأرشيف لا يحتوي على قاعدة البيانات (sdf.db).")
        tmp = config.backups_dir() / "_restore_check.db"
        with zf.open("sdf.db") as src, open(tmp, "wb") as dst:
            shutil.copyfileobj(src, dst)
    if not verify_backup(tmp):
        tmp.unlink(missing_ok=True)
        raise ValueError("فشل التحقق من سلامة النسخة — أُجهضت الاستعادة.")
    # إغلاق الاتصال الحالي مسؤولية المتصل؛ هنا نستبدل الملفات فقط
    db_target = config.db_path()
    db_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(tmp, db_target)
    tmp.unlink(missing_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        att_members = [n for n in zf.namelist() if n.startswith("attachments/")]
        if att_members:
            att_dir = config.attachments_dir()
            att_dir.mkdir(parents=True, exist_ok=True)
            for m in att_members:
                rel = Path(m).relative_to("attachments")
                if str(rel) in (".", ""):
                    continue
                target = att_dir / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(m) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
    return db_target


def cleanup_old_backups(conn: sqlite3.Connection, keep: int = 10):
    """الاحتفاظ بآخر N نسخ وحذف الأقدم."""
    rows = conn.execute("SELECT id, path FROM backup_history ORDER BY created_at DESC").fetchall()
    for r in rows[keep:]:
        p = Path(r["path"])
        if p.exists():
            p.unlink()
        conn.execute("DELETE FROM backup_history WHERE id=?", (r["id"],))
    conn.commit()
