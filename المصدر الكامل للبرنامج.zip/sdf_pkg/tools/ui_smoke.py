# -*- coding: utf-8 -*-
"""اختبار دخاني للواجهة: تحميل البيانات الحقيقية، فتح كل صفحة، ولقطات شاشة."""
import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

# مجلد بيانات اختبار منعزل
os.environ["SDF_DATA_DIR"] = "/tmp/sdf_ui_test"

from sdf_app import config
from sdf_app.ui.app import create_app
from sdf_app.ui.context import AppContext
from sdf_app.database.seeds import seed_all
from sdf_app.services import import_service as imp
from sdf_app.services.auth_service import authenticate
from sdf_app.ui.main_window import MainWindow
import sdf_app.main as app_main

SHOTS = Path("/tmp/ui_shots")
SHOTS.mkdir(exist_ok=True)

SRC = Path("/home/hatch/workspace/user/files/______________________________________________________0_0qvq.xlsm")


def shot(widget, name):
    pix = widget.grab()
    pix.save(str(SHOTS / f"{name}.png"))
    print("shot:", name)


def main():
    # تهيئة البيانات
    import shutil
    if Path("/tmp/sdf_ui_test").exists():
        shutil.rmtree("/tmp/sdf_ui_test")
    ctx = AppContext()
    mapping = imp.auto_map_columns(imp.preview_sheet(SRC, "ورقة2")["headers"])
    results = imp.analyze_rows(SRC, "ورقة2", mapping, ctx.conn)
    rep = imp.execute_import(ctx.conn, results, source_file=str(SRC), sheet_name="ورقة2")
    print("imported:", rep["imported"])
    ctx.user = authenticate(ctx.conn, "admin", "admin123")
    assert ctx.user, "login failed"

    app = create_app([])
    window = MainWindow(ctx)
    pages = app_main._wire_pages(window, ctx)
    window.show()
    app.processEvents()

    shot(window, "00_main_dashboard")
    window.show_page("files")
    app.processEvents()
    shot(window, "01_files")
    window.show_page("review")
    app.processEvents()
    pages_ctx_review = window.pages["review"]
    pages_ctx_review.open_file(7)  # ملف حقيقي
    app.processEvents()
    shot(window, "02_review")

    # نموذج الملف
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx, file_id=7)
    dlg.show()
    app.processEvents()
    shot(dlg, "03_file_dialog")
    dlg.close()

    window.show_page("reports")
    app.processEvents()
    shot(window, "04_reports")
    window.show_page("settings")
    app.processEvents()
    shot(window, "05_settings")
    print("SMOKE OK")


if __name__ == "__main__":
    main()
