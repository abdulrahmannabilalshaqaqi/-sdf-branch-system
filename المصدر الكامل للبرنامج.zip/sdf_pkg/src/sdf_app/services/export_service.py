# -*- coding: utf-8 -*-
"""
تصدير البيانات إلى Excel حقيقي (.xlsx) قابل للفرز والبحث والتعديل:
عناوين عربية، اتجاه RTL، تنسيقات احترافية، تجميد العناوين، تصفية،
وورقة معلومات التصدير. لا يصدّر كلمات مرور أو بيانات حساسة.
"""
from datetime import datetime
from pathlib import Path
from typing import List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..core.finance import summarize

# (المفتاح، عنوان العمود، النوع: text|int|money|date)
EXPORT_COLUMNS = [
    ("file_number", "رقم الملف", "int"),
    ("branch_file_number", "رقم الملف بالفرع", "text"),
    ("received_date", "تاريخ استلام الملف", "date"),
    ("branch_name", "الفرع", "text"),
    ("program_name", "اسم البرنامج", "text"),
    ("program_field", "مجال البرنامج", "text"),
    ("beneficiary_name", "الجهة المستفيدة", "text"),
    ("implementing_name", "الجهة المنفذة", "text"),
    ("exec_start", "بداية التنفيذ", "date"),
    ("exec_end", "نهاية التنفيذ", "date"),
    ("trainer_name", "اسم المدرب", "text"),
    ("trainer_qualification", "مؤهل المدرب", "text"),
    ("trainer_experience", "خبرة المدرب", "text"),
    ("license_issuer", "جهة إصدار الترخيص", "text"),
    ("contract_date", "تاريخ العقد", "date"),
    ("contract_trainees", "عدد المتدربين في العقد", "int"),
    ("contract_hours", "عدد الساعات حسب العقد", "int"),
    ("contract_cost_per_trainee", "تكلفة الفرد حسب العقد", "money"),
    ("contract_total", "التكلفة الإجمالية حسب العقد (محسوبة)", "money"),
    ("contract_hour_cost", "تكلفة الساعة حسب العقد (محسوبة)", "money"),
    ("nominees_count", "عدد المرشحين", "int"),
    ("nomination_date", "تاريخ الترشيح", "date"),
    ("attendance_trainees", "عدد المتدربين من كشوفات الحضور", "int"),
    ("attendance_exec_date", "تاريخ التنفيذ من كشوفات الحضور", "date"),
    ("certificates_count", "عدد الشهادات", "int"),
    ("approved_trainees", "عدد المتدربين المعتمدين", "int"),
    ("approved_hours", "عدد الساعات المعتمدة", "int"),
    ("approved_cost_per_trainee", "تكلفة المتدرب المعتمدة", "money"),
    ("approved_total", "التكلفة الإجمالية المعتمدة (محسوبة)", "money"),
    ("approved_hour_cost", "تكلفة الساعة المعتمدة (محسوبة)", "money"),
    ("claimed_amount", "التكلفة المطالب بها من الجهة", "money"),
    ("branch_approved_amount", "التكلفة المعتمدة من الفرع", "money"),
    ("funding_amount", "مبلغ التمويل", "money"),
    ("diff_funding_claimed", "الفارق: التمويل − المطالب به", "money"),
    ("diff_claimed_approved", "الفارق: المطالب به − المعتمد", "money"),
    ("supervisor_name", "اسم المشرف", "text"),
    ("supervision_level", "مستوى التنفيذ من الإشراف", "text"),
    ("material_match", "مطابقة محتوى المادة العلمية", "text"),
    ("claim_date", "تاريخ المطالبة", "date"),
    ("status_name", "حالة الملف", "text"),
    ("notes", "ملاحظات", "text"),
]

HEADER_FILL = PatternFill("solid", fgColor="1F3A5F")
HEADER_FONT = Font(name="Segoe UI", bold=True, color="FFFFFF", size=11)
TITLE_FONT = Font(name="Segoe UI", bold=True, color="1F3A5F", size=14)
THIN_BORDER = Border(*(Side(style="thin", color="B0B0B0") for _ in range(4)))
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
RIGHT = Alignment(horizontal="right", vertical="center", wrap_text=True)


def _style_sheet(ws, n_cols: int, title: str):
    ws.sheet_view.rightToLeft = True
    ws.sheet_view.showGridLines = True
    # صف العنوان
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=n_cols)
    c = ws.cell(row=1, column=1, value=title)
    c.font = TITLE_FONT
    c.alignment = CENTER
    ws.row_dimensions[1].height = 28
    # صف الترويسة
    for col, (_, header, _) in enumerate(EXPORT_COLUMNS, start=1):
        cell = ws.cell(row=2, column=col, value=header)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = CENTER
        cell.border = THIN_BORDER
    ws.row_dimensions[2].height = 36
    ws.freeze_panes = "A3"
    ws.auto_filter.ref = f"A2:{get_column_letter(n_cols)}2"


def _apply_cell(cell, kind: str, value):
    cell.border = THIN_BORDER
    if kind == "money":
        cell.number_format = '#,##0.00'
        cell.alignment = CENTER
        cell.value = float(value) if value is not None else None
    elif kind == "int":
        cell.number_format = '0'
        cell.alignment = CENTER
        cell.value = value
    elif kind == "date":
        cell.number_format = 'yyyy-mm-dd'
        cell.alignment = CENTER
        if value:
            try:
                cell.value = datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
            except ValueError:
                cell.value = str(value)
                cell.alignment = RIGHT
        else:
            cell.value = None
    else:  # text — يحفظ كنص (يحمي الأصفار البادئة والأرقام الطويلة)
        cell.number_format = '@'
        cell.alignment = RIGHT
        cell.value = str(value) if value is not None else None


def export_files(rows: List[dict], path: Path, title: str = "كشف الملفات",
                 filters_desc: str = "") -> Path:
    """تصدير قائمة ملفات (قواميس موسعة) إلى xlsx منسق."""
    wb = Workbook()
    ws = wb.active
    ws.title = "البيانات"
    n_cols = len(EXPORT_COLUMNS)
    _style_sheet(ws, n_cols, title)

    for r_idx, rec in enumerate(rows, start=3):
        fin = summarize(rec)
        full = dict(rec)
        full.update(fin)
        for c_idx, (key, _h, kind) in enumerate(EXPORT_COLUMNS, start=1):
            _apply_cell(ws.cell(row=r_idx, column=c_idx), kind, full.get(key))
        ws.row_dimensions[r_idx].height = 20

    # عرض الأعمدة
    widths = {"int": 14, "money": 18, "date": 14, "text": 26}
    for c_idx, (_k, header, kind) in enumerate(EXPORT_COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(c_idx)].width = max(widths[kind], len(header) * 1.4)

    # ورقة معلومات التصدير
    meta = wb.create_sheet("معلومات التصدير")
    meta.sheet_view.rightToLeft = True
    info = [
        ("العنوان", title),
        ("تاريخ ووقت التصدير", datetime.now().strftime("%Y-%m-%d %H:%M")),
        ("عدد السجلات", len(rows)),
        ("معايير التصفية", filters_desc or "—"),
        ("ملاحظة", "الأعمدة المعلمة بـ (محسوبة) أُعيد حسابها من المحرك المالي المركزي."),
    ]
    for i, (k, v) in enumerate(info, start=1):
        meta.cell(row=i, column=1, value=k).font = Font(bold=True)
        meta.cell(row=i, column=2, value=v)
        meta.column_dimensions["A"].width = 24
        meta.column_dimensions["B"].width = 60

    path = Path(path)
    wb.save(path)
    return path


def enrich_row(row: dict) -> dict:
    """دمج الحسابات المالية في صف واحد جاهز للتصدير/العرض."""
    out = dict(row)
    out.update(summarize(row))
    return out
