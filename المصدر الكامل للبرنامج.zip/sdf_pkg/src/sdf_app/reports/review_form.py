# -*- coding: utf-8 -*-
"""
استمارة مراجعة ملف برنامج تدريبي والمصادقة على التمويل — PDF عربي RTL بمقاس A4.

تُبنى من حقول استمارة ورقة1 الأصلية (محفوظة بالكامل) مع تحسين التنظيم،
وتُضاف خانات التوقيع اليدوي والتاريخ والختم ومساحات الملاحظات.
"""
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle

from .pdf_base import (
    Checkbox, FormDocTemplate, ar, make_styles, money_ar, num_ar, wrap_ar,
)

NAVY = colors.HexColor("#1F3A5F")
LIGHT = colors.HexColor("#F2F4F7")
LIGHTER = colors.HexColor("#F8FAFD")
BORDER = colors.HexColor("#9AA3B2")
WHITE = colors.white

REVIEW_OPTIONS = ["مطابق", "غير مطابق", "غير مكتمل", "غير منطبق"]
DECISION_OPTIONS = ["مكتمل", "يعاد للاستكمال", "يحتاج إلى مراجعة إضافية", "غير مستوفٍ للاعتماد"]

W = 182 * mm  # عرض المحتوى
PAD = 14      # هامش داخلي للخلايا عند حساب عرض اللفّ


def _styles():
    return make_styles()


def P(text, style, styles, width=None):
    """فقرة عربية؛ width (بالنقاط) للّف المسبق عند احتمال تعدد الأسطر."""
    s = styles[style]
    t = "—" if text in (None, "") else str(text)
    if width:
        return Paragraph(wrap_ar(t, s.fontName, s.fontSize, width), s)
    return Paragraph(ar(t), s)


def _num(v):
    """عرض الأعداد: صحيح بدون كسور، وعشري برقمين عند الحاجة."""
    if v is None or v == "":
        return "—"
    try:
        f = float(v)
        return str(int(f)) if f == int(f) else num_ar(v)
    except (ValueError, TypeError):
        return str(v)


def R(*cells):
    """ترتيب منطقي (يمين→يسار) إلى ترتيب فعلي للجدول."""
    return list(reversed(cells))


def _tbl(data, col_widths, header_rows=0, zebra=True):
    style_cmds = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.6, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    if zebra:
        style_cmds.append(("ROWBACKGROUNDS", (0, header_rows), (-1, -1), [WHITE, LIGHTER]))
    t = Table(data, colWidths=col_widths, repeatRows=header_rows)
    t.setStyle(TableStyle(style_cmds))
    return t


def _kv_table(pairs, styles, label_width=38 * mm):
    """جدول (القيمة | التسمية) — التسمية يمينًا بخلفية مميزة."""
    value_width = W - label_width
    data = []
    for label, value in pairs:
        # الترتيب المنطقي: التسمية أولًا (تظهر يمينًا)، ثم القيمة
        data.append(R(Paragraph(ar(label), styles["cell_bold"]),
                      P(value, "cell", styles, width=value_width - PAD)))
    t = Table(data, colWidths=[value_width, label_width], repeatRows=0)
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.6, BORDER),
        ("BACKGROUND", (-1, 0), (-1, -1), LIGHT),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return t


def _option_group(options, selected, styles):
    """مجموعة مربعات اختيار أفقية — المحدد يظهر بعلامة، والباقي فارغ للتحديد اليدوي."""
    cells = []
    for opt in options:
        inner = Table(
            [[Checkbox(checked=(opt == selected)), Paragraph(ar(opt), styles["small"])]],
            colWidths=[6 * mm, None],
        )
        inner.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 1),
            ("RIGHTPADDING", (0, 0), (-1, -1), 1),
        ]))
        cells.append(inner)
    t = Table([R(*cells)])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    return t


def _section_title(text, styles):
    s = styles["section"]
    p = Paragraph(wrap_ar(text, s.fontName, s.fontSize, W - 20), s)
    t = Table([[p]], colWidths=[W])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
        ("BOX", (0, 0), (-1, -1), 0.8, NAVY),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def build_review_form(rec: dict, review_items: list, output_path: Path,
                      settings: dict = None, print_date: str = None,
                      draft: bool = False) -> Path:
    """بناء الاستمارة الكاملة. rec: صف موسع (أسماء + ملخص مالي)."""
    settings = settings or {}
    styles = _styles()
    org = settings.get("org_name", "صندوق تنمية المهارات")
    office = settings.get("office_name", "مكتب النائب لشؤون الفروع")
    form_title = settings.get("form_title", "استمارة مراجعة ملف برنامج تدريبي والمصادقة على التمويل")
    currency = settings.get("currency", "ر.ي")
    print_date = print_date or datetime.now().strftime("%Y-%m-%d")
    form_no = f"{rec.get('file_number')}-{datetime.now().year}"

    output_path = Path(output_path)
    doc = FormDocTemplate(str(output_path), file_number=rec.get("file_number"),
                          print_date=print_date)
    story = []

    # -- الترويسة ---------------------------------------------------------
    story.append(Paragraph(ar("الجمهورية اليمنية"), styles["subtitle"]))
    story.append(Paragraph(ar(org), styles["title"]))
    story.append(Paragraph(ar(office), styles["subtitle"]))
    story.append(Spacer(1, 3 * mm))
    story.append(Paragraph(wrap_ar(form_title, styles["title"].fontName, 16, W - 20),
                           styles["title"]))
    if draft:
        story.append(Paragraph(ar("— مسودة مراجعة (بيانات غير مكتملة) —"), styles["small"]))
    story.append(Spacer(1, 3 * mm))

    meta_w = W / 2 - 30 * mm
    meta = [
        R(Paragraph(ar("التاريخ"), styles["cell_bold"]),
          P(rec.get("received_date") or "—", "cell_center", styles, width=meta_w - PAD)),
        R(Paragraph(ar("رقم الملف"), styles["cell_bold"]),
          P(rec.get("file_number"), "cell_center", styles, width=meta_w - PAD)),
        R(Paragraph(ar("رقم الملف بالفرع"), styles["cell_bold"]),
          P(rec.get("branch_file_number") or "—", "cell_center", styles, width=meta_w - PAD)),
        R(Paragraph(ar("رقم الاستمارة"), styles["cell_bold"]),
          P(form_no, "cell_center", styles, width=meta_w - PAD)),
    ]
    story.append(_tbl([[m[0], m[1]] for m in meta], [meta_w, 30 * mm], zebra=False))
    story.append(Spacer(1, 2 * mm))

    # -- أولاً: البيانات العامة --------------------------------------------
    story.append(_section_title("أولاً: البيانات العامة للملف", styles))
    story.append(_kv_table([
        ("الجهة المستفيدة", rec.get("beneficiary_name")),
        ("الفرع", rec.get("branch_name")),
        ("اسم البرنامج", rec.get("program_name")),
        ("الجهة المنفذة", rec.get("implementing_name")),
        ("مجال البرنامج", rec.get("program_field")),
        ("تاريخ التنفيذ", f"من {rec.get('exec_start') or '—'} إلى {rec.get('exec_end') or '—'}"),
        ("رقم العقد / تاريخ العقد",
         f"{rec.get('contract_number') or '—'} / {rec.get('contract_date') or '—'}"),
        ("رقم الملف بالفرع", rec.get("branch_file_number")),
        ("حالة الملف", rec.get("status_name")),
    ], styles))
    story.append(Spacer(1, 2 * mm))

    # -- ثانياً: مطابقة أصول الوثائق ----------------------------------------
    story.append(_section_title("ثانياً: مطابقة أصول الوثائق", styles))

    def _group(title, pairs):
        s = styles["cell_bold"]
        story.append(Paragraph(wrap_ar(title, s.fontName, s.fontSize, W - PAD), s))
        story.append(_kv_table(pairs, styles, label_width=42 * mm))
        story.append(Spacer(1, 2 * mm))

    _group("بيانات العقد", [
        ("تاريخ التوقيع", rec.get("contract_date")),
        ("تاريخ التنفيذ", rec.get("contract_exec_date")),
        ("مدة التنفيذ / ساعة", _num(rec.get("contract_hours"))),
        ("كلفة المتدرب", money_ar(rec.get("contract_cost_per_trainee"), currency)),
        ("عدد المتدربين", _num(rec.get("contract_trainees"))),
        ("التكلفة الإجمالية", money_ar(rec.get("contract_total"), currency)),
    ])
    _group("بيانات الترشيح", [
        ("عدد المرشحين", _num(rec.get("nominees_count"))),
        ("تاريخ الترشيح", rec.get("nomination_date")),
        ("المجال", rec.get("program_field")),
    ])
    _group("كشوفات الحضور", [
        ("تاريخ التنفيذ", rec.get("attendance_exec_date")),
        ("عدد المتدربين", _num(rec.get("attendance_trainees"))),
        ("مدة البرنامج", rec.get("program_duration")),
    ])
    _group("سيرة الخبير المنفذ (المدرب)", [
        ("اسم المدرب", rec.get("trainer_name")),
        ("المؤهل / المجال", rec.get("trainer_qualification")),
        ("الخبرة", rec.get("trainer_experience")),
        ("جهة إصدار الترخيص", rec.get("license_issuer")),
        ("فترة الترخيص", f"من {rec.get('license_start') or '—'} إلى {rec.get('license_end') or '—'}"),
    ])
    _group("بيانات الشهادة", [
        ("اسم البرنامج في الشهادة", rec.get("cert_program_name")),
        ("تاريخ التنفيذ", f"من {rec.get('cert_exec_start') or '—'} إلى {rec.get('cert_exec_end') or '—'}"),
        ("عدد الشهادات المرفقة", _num(rec.get("certificates_count"))),
    ])
    _group("المادة العلمية وتقرير الإشراف والمطالبة", [
        ("مطابقة محتوى المادة العلمية", rec.get("material_match")),
        ("اسم المشرف", rec.get("supervisor_name")),
        ("مستوى التنفيذ", rec.get("supervision_level")),
        ("تاريخ المطالبة", rec.get("claim_date")),
        ("المبلغ المطالب به", money_ar(rec.get("claimed_amount"), currency)),
    ])

    # -- جدول أعداد المتدربين ------------------------------------------------
    story.append(_section_title("جدول مراجعة أعداد المتدربين", styles))
    counts = [
        ("عدد المتدربين حسب العقد", rec.get("contract_trainees")),
        ("عدد المرشحين", rec.get("nominees_count")),
        ("عدد الحاضرين حسب كشف الحضور", rec.get("attendance_trainees")),
        ("عدد الشهادات المرفقة", rec.get("certificates_count")),
        ("العدد المعتمد للمراجعة", rec.get("approved_trainees")),
    ]
    data = [R(Paragraph(ar("البيان"), styles["cell_bold"]),
              Paragraph(ar("العدد"), styles["cell_bold"]))]
    for label, val in counts:
        data.append(R(P(label, "cell", styles, width=W - 40 * mm - PAD),
                      P(_num(val), "cell_center", styles)))
    story.append(_tbl(data, [W - 40 * mm, 40 * mm], header_rows=1))
    story.append(P("ملاحظات الفروقات: " + (rec.get("notes") or "—"), "small", styles, width=W - PAD))
    story.append(Spacer(1, 2 * mm))

    # -- قائمة التحقق من الوثائق ----------------------------------------------
    story.append(_section_title("قائمة التحقق من الوثائق", styles))
    doc_data = [R(Paragraph(ar("الوثيقة"), styles["cell_bold"]),
                  Paragraph(ar("حالة المراجعة"), styles["cell_bold"]),
                  Paragraph(ar("الملاحظات"), styles["cell_bold"]))]
    items = review_items or [{"document_name": n, "result": None, "notes": ""}
                             for n in ["العقد", "كشف الترشيحات", "كشوفات الحضور والانصراف",
                                       "بيانات المدرب ومؤهلاته", "الترخيص (عند اشتراطه)",
                                       "الشهادات", "المادة العلمية", "تقرير الإشراف",
                                       "المطالبة المالية", "مستندات أخرى"]]
    for it in items:
        doc_data.append(R(
            P(it.get("document_name"), "cell", styles, width=45 * mm - PAD),
            _option_group(REVIEW_OPTIONS, it.get("result"), styles),
            P(it.get("notes") or "", "cell", styles, width=55 * mm - PAD),
        ))
    story.append(_tbl(doc_data, [45 * mm, 82 * mm, 55 * mm], header_rows=1))
    story.append(Spacer(1, 2 * mm))

    # -- ثالثاً: خلاصة المراجعة الفنية ------------------------------------------
    story.append(_section_title("ثالثاً: خلاصة المراجعة الفنية", styles))
    story.append(_kv_table([
        ("العدد المعتمد للمتدربين", _num(rec.get("approved_trainees"))),
        ("عدد الساعات الفعلية (المعتمدة)", _num(rec.get("approved_hours"))),
        ("كلفة المتدرب الفعلي (المعتمدة)", money_ar(rec.get("approved_cost_per_trainee"), currency)),
        ("التكلفة الإجمالية المعتمدة", money_ar(rec.get("approved_total"), currency)),
        ("مبلغ التمويل", money_ar(rec.get("funding_amount"), currency)),
    ], styles))
    story.append(Spacer(1, 2 * mm))

    # -- الملخص المالي -----------------------------------------------------------
    story.append(_section_title("الملخص المالي", styles))
    story.append(_kv_table([
        ("المبلغ المطالب به", money_ar(rec.get("claimed_amount"), currency)),
        ("التكلفة المعتمدة (الإجمالية)", money_ar(rec.get("approved_total"), currency)),
        ("العدد المعتمد للمتدربين", _num(rec.get("approved_trainees"))),
        ("عدد الساعات المعتمدة", _num(rec.get("approved_hours"))),
        ("تكلفة الفرد المعتمدة", money_ar(rec.get("approved_cost_per_trainee"), currency)),
        ("مبلغ التمويل", money_ar(rec.get("funding_amount"), currency)),
        ("الفارق: التمويل − المطالب به", money_ar(rec.get("diff_funding_claimed"), currency)),
        ("الفارق: المطالب به − المعتمد", money_ar(rec.get("diff_claimed_approved"), currency)),
        ("ملاحظات المراجع المالي", rec.get("notes")),
    ], styles))
    story.append(P("العملة: الريال اليمني — أُعيد حساب جميع المبالغ من المحرك المالي المركزي.",
                   "small", styles, width=W - PAD))
    story.append(Spacer(1, 2 * mm))

    # -- الملاحظات والقرار ---------------------------------------------------------
    story.append(_section_title("الملاحظات وقرار المراجعة", styles))
    notes_box = Table([[Paragraph(ar(""), styles["normal"])]], colWidths=[W], rowHeights=[32 * mm])
    notes_box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, BORDER)]))
    story.append(notes_box)
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(ar("قرار المراجعة:"), styles["cell_bold"]))
    story.append(_option_group(DECISION_OPTIONS, rec.get("decision"), styles))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(ar("سبب القرار:"), styles["small"]))
    reason_box = Table([[Paragraph(ar(""), styles["normal"])]], colWidths=[W], rowHeights=[18 * mm])
    reason_box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, BORDER)]))
    story.append(reason_box)
    story.append(Spacer(1, 3 * mm))

    # -- التوقيعات -------------------------------------------------------------------
    story.append(_section_title("التوقيعات والاعتمادات", styles))
    story.append(P("التوقيعات التالية يدوية — لا يُعد طباعة الاسم اعتمادًا رسميًا.",
                   "small", styles, width=W - PAD))
    story.append(Spacer(1, 2 * mm))

    def _sig_block(title):
        return [
            Paragraph(wrap_ar(title, styles["cell_bold"].fontName, 9.5, W / 4 - 16),
                      styles["cell_bold"]),
            Spacer(1, 14 * mm),
            Paragraph(ar("الاسم: ........................................"), styles["small"]),
            Paragraph(ar("التوقيع: ......................................"), styles["small"]),
            Paragraph(ar("التاريخ: ........ / ........ / ................"), styles["small"]),
        ]

    sig_titles = ["المراجع الفني", "المراجع المالي",
                  "مدير مكتب النائب لشؤون الفروع", "نائب المدير التنفيذي لشؤون الفروع"]
    sig_row = R(*[_sig_block(t) for t in sig_titles])
    sig_table = Table([sig_row], colWidths=[W / 4] * 4)
    sig_table.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.6, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(sig_table)
    story.append(Spacer(1, 3 * mm))

    # مكان الختم
    stamp = Table([[Paragraph(ar("الختم الرسمي"), styles["cell_bold"])]],
                  colWidths=[55 * mm], rowHeights=[30 * mm])
    stamp.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.8, BORDER),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(Table([[stamp]], colWidths=[W],
                       style=TableStyle([("ALIGN", (0, 0), (-1, -1), "LEFT")])))
    story.append(Spacer(1, 4 * mm))

    # -- المذكرات (كما في الاستمارة الأصلية) -------------------------------------------
    story.append(Paragraph(ar("الأخ / المدير التنفيذي المحترم"), styles["cell_bold"]))
    story.append(P(
        "ترون بعالية المصادقة الفنية لملف البرنامج التدريبي المذكور أعلاه، وعليه / يرجى التوجيه "
        "للنائب للشؤون المالية والإدارية بأستكمال الإجراءات بحسب ما المصادق عليه من قبل المكتب.",
        "memo", styles, width=W - PAD))
    story.append(Paragraph(ar("وشكراً،،،"), styles["memo"]))
    story.append(Spacer(1, 2 * mm))
    memo_sig = R(*[_sig_block(t) for t in sig_titles])
    memo_table = Table([memo_sig], colWidths=[W / 4] * 4)
    memo_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(memo_table)
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(ar("الأخ / النائب للشؤون المالية والإدارية المحترم"), styles["cell_bold"]))
    story.append(P(
        "يتم أستكمال الإجراءات بحسب النظام وبحسب ما تم اعتماده من مكتب النائب لشؤون الفروع.",
        "memo", styles, width=W - PAD))
    story.append(Spacer(1, 2 * mm))
    story.append(Table([R(*[_sig_block("المدير التنفيذي")])], colWidths=[W / 4] * 4,
                       style=TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")])))

    doc.build(story)
    return output_path
