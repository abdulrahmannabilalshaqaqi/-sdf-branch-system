# -*- coding: utf-8 -*-
"""معالج الاستيراد من Excel: ملف ← ورقة ← مطابقة أعمدة ← تحليل ← تنفيذ."""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QFileDialog, QHBoxLayout, QLabel,
                               QListWidget, QMessageBox, QPushButton,
                               QRadioButton, QTableWidget, QTableWidgetItem,
                               QVBoxLayout, QWidget, QWizard, QWizardPage,
                               QButtonGroup, QTextEdit)

from ..services import import_service as imp

FIELD_LABELS = {
    "file_number": "رقم الملف", "received_date": "تاريخ استلام الملف", "branch": "الفرع",
    "branch_file_number": "رقم الملف بالفرع", "program_name": "اسم البرنامج",
    "beneficiary": "الجهة المستفيدة", "exec_start": "بداية التنفيذ", "exec_end": "نهاية التنفيذ",
    "trainer": "اسم المدرب", "docs_status": "استيفاء الوثائق", "program_field": "مجال البرنامج",
    "implementing": "الجهة المنفذة", "contract_date": "تاريخ العقد",
    "contract_trainees": "عدد المتدربين في العقد", "contract_hours": "عدد الساعات حسب العقد",
    "contract_cost_per_trainee": "تكلفة الفرد حسب العقد", "claimed_amount": "التكلفة المطالب بها",
    "branch_approved_amount": "التكلفة المعتمدة من الفرع", "supervisor_name": "اسم المشرف",
    "approved_trainees": "عدد المتدربين المعتمدين", "approved_hours": "عدد الساعات المعتمدة",
    "approved_cost_per_trainee": "تكلفة المتدرب المعتمدة", "funding_amount": "مبلغ التمويل",
    "notes": "ملاحظات", "contract_exec_date": "تاريخ التنفيذ في العقد",
    "nominees_count": "عدد المرشحين", "nomination_date": "تاريخ الترشيح",
    "attendance_exec_date": "تاريخ التنفيذ من كشوفات الحضور",
    "attendance_trainees": "عدد المتدربين من كشوفات الحضور", "program_duration": "مدة البرنامج",
    "supervision_level": "مستوى التنفيذ من الإشراف", "trainer_qualification": "مؤهل المدرب",
    "trainer_experience": "خبرة المدرب", "license_issuer": "جهة إصدار الترخيص",
    "license_start": "بداية مدة الترخيص", "license_end": "نهاية مدة الترخيص",
    "implementing_field": "مجال الجهة المنفذة", "cert_program_name": "اسم البرنامج في الشهادة",
    "cert_exec_start": "بداية التنفيذ في الشهادة", "cert_exec_end": "نهاية التنفيذ في الشهادة",
    "certificates_count": "عدد الشهادات", "material_match": "مطابقة محتوى المادة العلمية",
    "claim_date": "تاريخ المطالبة",
}


class ImportWizard(QWizard):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.setWindowTitle("استيراد من Excel")
        self.setWizardStyle(QWizard.ModernStyle)
        self.resize(860, 620)
        self.file_path = None
        self.sheet_name = None
        self.mapping = {}
        self.results = []

        self.addPage(PageFile(self))
        self.addPage(PageSheet(self))
        self.addPage(PageMapping(self))
        self.addPage(PageAnalyze(self))
        self.addPage(PageExecute(self))


class PageFile(QWizardPage):
    def __init__(self, wiz):
        super().__init__()
        self.wiz = wiz
        self.setTitle("اختيار ملف Excel")
        l = QVBoxLayout(self)
        row = QHBoxLayout()
        self.path_lbl = QLabel("لم يُختر ملف بعد")
        btn = QPushButton("اختيار ملف...")
        btn.clicked.connect(self._choose)
        row.addWidget(self.path_lbl, 1)
        row.addWidget(btn)
        l.addLayout(row)
        l.addWidget(QLabel("الصيغ المدعومة: xlsx و xlsm (و xls إن أمكن). لن يُعدَّل الملف الأصلي أبدًا."))
        l.addStretch(1)

    def _choose(self):
        path, _ = QFileDialog.getOpenFileName(self, "اختر ملف Excel", "",
                                              "Excel (*.xlsx *.xlsm *.xls)")
        if path:
            self.wiz.file_path = Path(path)
            self.path_lbl.setText(path)
            self.completeChanged.emit()

    def isComplete(self):
        return self.wiz.file_path is not None


class PageSheet(QWizardPage):
    def __init__(self, wiz):
        super().__init__()
        self.wiz = wiz
        self.setTitle("اختيار ورقة العمل")
        l = QVBoxLayout(self)
        self.list = QListWidget()
        l.addWidget(self.list)
        l.addStretch(1)

    def initializePage(self):
        self.list.clear()
        try:
            for s in imp.list_sheets(self.wiz.file_path):
                self.list.addItem(s)
            if self.list.count():
                self.list.setCurrentRow(0)
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"تعذر قراءة الملف: {exc}")

    def validatePage(self):
        item = self.wiz and self.list.currentItem()
        if not item:
            return False
        self.wiz.sheet_name = item.text()
        return True


class PageMapping(QWizardPage):
    def __init__(self, wiz):
        super().__init__()
        self.wiz = wiz
        self.setTitle("مطابقة الأعمدة مع حقول قاعدة البيانات")
        self.setSubTitle("عدّل المطابقة التلقائية عند الحاجة.")
        l = QVBoxLayout(self)
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["عمود Excel", "حقل قاعدة البيانات"])
        self.table.verticalHeader().setVisible(False)
        l.addWidget(self.table)

    def initializePage(self):
        wiz = self.wiz
        prev = imp.preview_sheet(wiz.file_path, wiz.sheet_name, n_rows=3)
        self.headers = prev["headers"]
        auto = imp.auto_map_columns(self.headers)
        self.table.setRowCount(len(self.headers))
        self.combos = []
        field_items = [("— تجاهل —", None)] + [(v, k) for k, v in FIELD_LABELS.items()]
        for i, h in enumerate(self.headers):
            self.table.setItem(i, 0, QTableWidgetItem(str(h) if h else f"عمود {i + 1}"))
            cb = QComboBox()
            for label, key in field_items:
                cb.addItem(label, key)
            if i in auto:
                cb.setCurrentIndex(cb.findData(auto[i]))
            self.table.setCellWidget(i, 1, cb)
            self.combos.append(cb)
        self.table.resizeColumnsToContents()

    def validatePage(self):
        mapping = {}
        used = set()
        for i, cb in enumerate(self.combos):
            key = cb.currentData()
            if key:
                if key in used:
                    QMessageBox.warning(self, "تنبيه", f"الحقل «{FIELD_LABELS[key]}» مكرر في المطابقة.")
                    return False
                used.add(key)
                mapping[i] = key
        if "file_number" not in mapping.values():
            QMessageBox.warning(self, "تنبيه", "يجب مطابقة عمود «رقم الملف» — حقل إلزامي.")
            return False
        self.wiz.mapping = mapping
        return True


class PageAnalyze(QWizardPage):
    def __init__(self, wiz):
        super().__init__()
        self.wiz = wiz
        self.setTitle("معاينة البيانات والتحقق")
        l = QVBoxLayout(self)
        self.summary_lbl = QLabel("")
        self.summary_lbl.setWordWrap(True)
        l.addWidget(self.summary_lbl)
        self.issues = QTextEdit()
        self.issues.setReadOnly(True)
        self.issues.setMaximumHeight(260)
        l.addWidget(QLabel("السجلات التي تحتاج مراجعة (عينة):"))
        l.addWidget(self.issues)

    def initializePage(self):
        wiz = self.wiz
        try:
            wiz.results = imp.analyze_rows(wiz.file_path, wiz.sheet_name, wiz.mapping, wiz.ctx.conn)
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل التحليل: {exc}")
            wiz.results = []
            return
        s = imp.summarize_analysis(wiz.results)
        self.summary_lbl.setText(
            f"إجمالي الصفوف: {len(wiz.results)} | سليمة: {s['ok']} (منها بتحذيرات: {s['with_warnings']}) | "
            f"فارغة: {s['empty']} | مكررة داخل الملف: {s['duplicate_file']} | "
            f"موجودة مسبقًا: {s['duplicate_db']} | أخطاء: {s['error']}")
        lines = []
        for r in wiz.results:
            if (r.errors or r.warnings or r.status in ("duplicate_file", "duplicate_db")) and len(lines) < 60:
                desc = "؛ ".join(r.errors + r.warnings) or r.status
                lines.append(f"صف {r.excel_row}: {desc[:160]}")
        self.issues.setPlainText("\n".join(lines) if lines else "لا توجد مشكلات — كل السجلات سليمة.")


class PageExecute(QWizardPage):
    def __init__(self, wiz):
        super().__init__()
        self.wiz = wiz
        self.setTitle("تنفيذ الاستيراد")
        l = QVBoxLayout(self)
        l.addWidget(QLabel("سياسة السجلات المكررة (الموجودة مسبقًا في قاعدة البيانات):"))
        self.policy_group = QButtonGroup(self)
        self.rb_skip = QRadioButton("تخطي السجل المكرر (موصى به)")
        self.rb_update = QRadioButton("تحديث السجل الموجود بالبيانات الجديدة")
        self.rb_manual = QRadioButton("تخطي مع توثيق للمراجعة اليدوية")
        self.rb_skip.setChecked(True)
        for rb in (self.rb_skip, self.rb_update, self.rb_manual):
            self.policy_group.addButton(rb)
            l.addWidget(rb)
        self.btn_run = QPushButton("بدء الاستيراد")
        self.btn_run.setProperty("primary", True)
        self.btn_run.clicked.connect(self._run)
        l.addWidget(self.btn_run)
        self.report = QTextEdit()
        self.report.setReadOnly(True)
        l.addWidget(self.report)
        l.addStretch(1)

    def _run(self):
        wiz = self.wiz
        policy = "skip"
        if self.rb_update.isChecked():
            policy = "update"
        elif self.rb_manual.isChecked():
            policy = "manual"
        uid = wiz.ctx.user["id"] if wiz.ctx.user else None
        try:
            rep = imp.execute_import(wiz.ctx.conn, wiz.results, duplicate_policy=policy,
                                     user_id=uid, source_file=str(wiz.file_path),
                                     sheet_name=wiz.sheet_name)
        except Exception as exc:
            QMessageBox.critical(self, "فشل الاستيراد",
                                 f"فشل الاستيراد وتم التراجع عن كل التغييرات.\n{exc}")
            return
        lines = [f"تم استيراد: {rep['imported']}", f"تم تحديث: {rep['updated']}",
                 f"تم تخطي: {rep['skipped']}", f"أخطاء: {rep['errored']}"]
        if rep["report"]:
            lines.append("— التفاصيل: —")
            lines += rep["report"][:80]
        self.report.setPlainText("\n".join(lines))
        self.btn_run.setEnabled(False)
        QMessageBox.information(self, "اكتمل الاستيراد",
                                f"استُورد {rep['imported']} سجلًا بنجاح.")
