# -*- coding: utf-8 -*-
"""اختبارات التحقق من التواريخ والأرقام — بما فيها الحالات الفوضوية من الملف الأصلي."""
from sdf_app.core.validation import parse_date, parse_int, parse_money, validate_file_record


def test_parse_iso_and_excel_dates():
    assert parse_date("2023-10-08")[0] == "2023-10-08"
    assert parse_date("2023/01/17")[0] == "2023-01-17"


def test_parse_ambiguous_slash_dates():
    # 7/16/2023 → الشهر أولًا (16 لا يصلح شهرًا)
    iso, status, _ = parse_date("7/16/2023")
    assert status == "ok" and iso == "2023-07-16"


def test_parse_arabic_month_name():
    iso, status, _ = parse_date("24ديسمبر2022")
    assert status == "ok" and iso == "2022-12-24"


def test_invalid_dates_flagged_not_silently_dropped():
    for bad in ["2022/25", "30/22/2022", "لايوجدX", "19/8-18/9/2023", "2023/5/31-6"]:
        iso, status, note = parse_date(bad)
        assert iso is None and note, f"لم يُكتشف: {bad}"
    # لايوجد وحدها = فارغ وليست خطأ
    assert parse_date("لايوجد")[1] == "empty"


def test_parse_int_and_money():
    assert parse_int("29")[0] == 29
    assert parse_int("١٤٠٠٠٠")[0] == 140000
    assert parse_int("abc")[1] == "invalid"
    assert parse_money("140,000")[0] == 140000


def test_validate_file_record():
    assert validate_file_record({"file_number": 1}) == []
    errs = validate_file_record({})
    assert any("رقم الملف" in e for e in errs)
    errs = validate_file_record({"file_number": 1, "exec_start": "2023-05-01", "exec_end": "2023-04-01"})
    assert any("بداية التنفيذ" in e for e in errs)
