# -*- coding: utf-8 -*-
"""أساسيات تقارير PDF العربية: الخطوط، تشكيل النص، الأنماط، مربعات الاختيار، التذييل."""
from pathlib import Path

import arabic_reshaper
from bidi.algorithm import get_display
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, Flowable, PageTemplate, Frame

FONT_NAME = "NotoNaskh"
FONT_BOLD = "NotoNaskh-Bold"
FONT_LATIN = "DejaVuSans"
FONT_LATIN_BOLD = "DejaVuSans-Bold"

from .. import config as _config

_resources = _config.resource_path("resources", "fonts")


def register_fonts():
    """تسجيل الخطوط المرفقة مع البرنامج (تعمل دون إنترنت ودون خطوط النظام).

    Noto Naskh للعربية، وDejaVu Sans كاحتياطي للأحرف اللاتينية غير الموجودة
    في خط النسخ (الشرطة -، الشرطة المائلة /، الأقواس، النسبة %، الشرطة الطويلة —).
    """
    for name, filename in ((FONT_NAME, "NotoNaskhArabic-Regular.ttf"),
                           (FONT_BOLD, "NotoNaskhArabic-Bold.ttf"),
                           (FONT_LATIN, "DejaVuSans.ttf"),
                           (FONT_LATIN_BOLD, "DejaVuSans-Bold.ttf")):
        path = _resources / filename
        if path.exists() and name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(name, str(path)))


# أحرف غير موجودة في خط النسخ — تُعرض بخط DejaVu الاحتياطي
_LATIN_RUN_RE = None


def _latin_run_re():
    global _LATIN_RUN_RE
    if _LATIN_RUN_RE is None:
        import re
        _LATIN_RUN_RE = re.compile(r"[\d\-\./\:,\(\)%\u2014\u2026*\u00d7 ]+")
    return _LATIN_RUN_RE


def _wrap_latin_runs(shaped: str) -> str:
    """تغليف المقاطع اللاتينية/الرقمية التي تحوي أحرفًا مفقودة من خط النسخ
    بخط DejaVu الاحتياطي، مع الحفاظ على ترتيب العرض."""

    def repl(m):
        s = m.group(0)
        if any(ch in "-/()%\u2014\u2026*\u00d7" for ch in s):
            return '<font name="DejaVuSans">' + s + "</font>"
        return s

    return _latin_run_re().sub(repl, shaped)


def ar(text, markup: bool = True) -> str:
    """تشكيل النص العربي للعرض الصحيح في PDF (RTL).

    - تُحمى المقاطع الرقمية (تواريخ/مبالغ) بتضمين LTR صريح قبل التشكيل
      لمنع خوارزمية Bidi من إعادة ترتيب أجزائها.
    - الأحرف اللاتينية غير الموجودة في خط النسخ (- / ( ) % \u2014) تُغلَّف
      بخط DejaVu الاحتياطي (markup=True للفقرات فقط).
    - markup=False للنصوص المرسومة مباشرة على الـ canvas (لا تدعم وسومًا).
    """
    if text is None:
        return ""
    text = str(text)
    if not text.strip():
        return ""
    import re
    text = text.replace("%", "\u066a")
    text = re.sub(r"\d[\d\-\./\:,\u0660-\u0669 ]*\d",
                  lambda m: "\u202a" + m.group(0) + "\u202c", text)
    try:
        shaped = get_display(arabic_reshaper.reshape(text))
    except Exception:
        shaped = text
    if markup:
        return _wrap_latin_runs(shaped)
    # بدائل مباشرة للـ canvas (بدون وسوم)
    return (shaped.replace("-", "\u2010").replace("\u2014", "\u2010")
            .replace("(", "[").replace(")", "]").replace("/", "\u2044"))


def num_ar(value) -> str:
    """تنسيق رقم للعرض داخل PDF (أرقام لاتينية بفواصل — أوضح في الجداول المالية)."""
    if value is None:
        return "—"
    try:
        return f"{float(value):,.2f}"
    except (ValueError, TypeError):
        return str(value)


def money_ar(value, currency: str = "ر.ي") -> str:
    if value is None:
        return "—"
    try:
        return f"{float(value):,.2f} {ar(currency)}"
    except (ValueError, TypeError):
        return str(value)


def wrap_ar(text, font_name, font_size, max_width):
    """لفّ النص العربي (بالترتيب المنطقي) إلى أسطر لا تتجاوز العرض الأقصى،
    ثم تشكيل كل سطر على حدة.

    السبب: تمرير النص مشكّلًا دفعة واحدة إلى reportlab يجعل التفاف الأسطر
    يظهر بترتيب معكوس (أول سطر منطقي في الأسفل). اللفّ المسبق هنا يحافظ
    على الترتيب الصحيح للأسطر والكلمات.
    """
    text = "" if text is None else str(text)
    if not text.strip():
        return ar("")
    words = text.split()
    lines, cur = [], ""
    for w in words:
        trial = f"{cur} {w}".strip()
        try:
            width = pdfmetrics.stringWidth(arabic_reshaper.reshape(trial), font_name, font_size)
        except Exception:
            width = 0
        if width <= max_width or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return "<br/>".join(ar(line) for line in lines)


# -- الأنماط ---------------------------------------------------------------
def make_styles():
    register_fonts()
    return {
        "title": ParagraphStyle("title", fontName=FONT_BOLD, fontSize=16, leading=22,
                                alignment=2, spaceAfter=4),
        "subtitle": ParagraphStyle("subtitle", fontName=FONT_BOLD, fontSize=12, leading=16,
                                   alignment=2, spaceAfter=6),
        "section": ParagraphStyle("section", fontName=FONT_BOLD, fontSize=12, leading=16,
                                  alignment=2, spaceBefore=10, spaceAfter=6,
                                  backColor=None, textColor="#1F3A5F"),
        "normal": ParagraphStyle("normal", fontName=FONT_NAME, fontSize=10, leading=15, alignment=2),
        "small": ParagraphStyle("small", fontName=FONT_NAME, fontSize=9, leading=13, alignment=2),
        "cell": ParagraphStyle("cell", fontName=FONT_NAME, fontSize=9.5, leading=13, alignment=2),
        "cell_bold": ParagraphStyle("cell_bold", fontName=FONT_BOLD, fontSize=9.5, leading=13, alignment=2),
        "cell_center": ParagraphStyle("cell_center", fontName=FONT_NAME, fontSize=9.5,
                                      leading=13, alignment=1),
        "memo": ParagraphStyle("memo", fontName=FONT_NAME, fontSize=10, leading=16, alignment=2,
                               spaceBefore=4, spaceAfter=2),
    }


# -- مربع اختيار مرسوم (مستقل عن الخط) --------------------------------------
class Checkbox(Flowable):
    """مربع ☐ فارغ أو ☑ محدد — يُرسم مباشرة في الـ canvas."""
    def __init__(self, checked: bool = False, size: float = 3.2 * mm):
        super().__init__()
        self.checked = checked
        self.size = size
        self.width = size
        self.height = size

    def draw(self):
        c = self.canv
        c.setLineWidth(0.8)
        c.setStrokeColorRGB(0.2, 0.2, 0.2)
        c.rect(0, 0, self.size, self.size, stroke=1, fill=0)
        if self.checked:
            c.setLineWidth(1.4)
            s = self.size
            c.line(s * 0.2, s * 0.45, s * 0.45, s * 0.15)
            c.line(s * 0.45, s * 0.15, s * 0.85, s * 0.75)


# -- قالب الصفحة مع التذييل ---------------------------------------------------
class FormDocTemplate(BaseDocTemplate):
    def __init__(self, filename, file_number=None, print_date=None, **kw):
        super().__init__(filename, pagesize=A4,
                         leftMargin=14 * mm, rightMargin=14 * mm,
                         topMargin=12 * mm, bottomMargin=16 * mm, **kw)
        self.file_number = file_number
        self.print_date = print_date
        frame = Frame(self.leftMargin, self.bottomMargin,
                      self.width, self.height, id="main")
        self.addPageTemplates([PageTemplate(id="form", frames=[frame],
                                             onPage=self._footer)])

    def _footer(self, canvas, doc):
        canvas.saveState()
        canvas.setFont(FONT_NAME, 8)
        canvas.setFillColorRGB(0.4, 0.4, 0.4)
        # تذييل: رقم الملف يمينًا، التاريخ يسارًا، رقم الصفحة وسطًا
        if self.file_number:
            canvas.drawRightString(A4[0] - 14 * mm, 10 * mm,
                                   ar(f"رقم الملف: {self.file_number}", markup=False))
        if self.print_date:
            canvas.drawString(14 * mm, 10 * mm,
                              ar(f"تاريخ الطباعة: {self.print_date}", markup=False))
        canvas.drawCentredString(A4[0] / 2, 10 * mm, ar(f"صفحة {doc.page}", markup=False))
        canvas.restoreState()

    def afterFlowable(self, flowable):
        pass
