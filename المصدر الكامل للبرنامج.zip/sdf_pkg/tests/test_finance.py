# -*- coding: utf-8 -*-
"""اختبارات المحرك المالي — تُطابق معادلات ملف Excel الأصلي."""
from decimal import Decimal

from sdf_app.core.finance import (
    approved_hour_cost,
    approved_total,
    contract_hour_cost,
    contract_total,
    diff_claimed_approved,
    diff_funding_claimed,
    format_money,
    summarize,
    to_decimal,
)


def test_contract_total_matches_excel():
    # صف 2 في الملف الأصلي: N=2, P=70000 → Q=140000
    assert contract_total(2, 70000) == Decimal("140000")


def test_contract_hour_cost_matches_excel():
    # R = 70000/22 = 3181.818181818182 (كما في القيمة المخزنة)
    result = contract_hour_cost(70000, 22)
    assert result is not None
    assert abs(float(result) - 3181.818181818182) < 1e-9


def test_hour_cost_zero_hours_returns_none():
    assert contract_hour_cost(70000, 0) is None
    assert approved_hour_cost(50000, 0) is None
    assert contract_hour_cost(70000, None) is None


def test_approved_total():
    assert approved_total(29, 16390) == Decimal("475310")


def test_diff_funding_claimed_matches_original_formula():
    # AB = AA − S (معادلة الملف الأصلي)
    assert diff_funding_claimed(140000, 100000) == Decimal("40000")


def test_diff_claimed_approved_per_spec():
    # المواصفات: المطالب به − المعتمد
    assert diff_claimed_approved(500000, 475310) == Decimal("24690")


def test_none_inputs_propagate_as_none():
    assert contract_total(None, 70000) is None
    assert contract_total(2, None) is None
    assert diff_funding_claimed(140000, None) is None
    assert summarize({})["contract_total"] is None


def test_arabic_digits_and_commas():
    assert to_decimal("١٤٠٬٠٠٠") == Decimal("140000")
    assert to_decimal("140,000") == Decimal("140000")


def test_format_money():
    text = format_money(Decimal("140000"))
    assert "140,000" in text and "ر.ي" in text
    assert format_money(None) == "—"


def test_summarize_full_record():
    rec = {
        "contract_trainees": 2, "contract_cost_per_trainee": 70000, "contract_hours": 22,
        "approved_trainees": 2, "approved_cost_per_trainee": 70000, "approved_hours": 22,
        "funding_amount": 140000, "claimed_amount": 120000,
    }
    s = summarize(rec)
    assert s["contract_total"] == Decimal("140000")
    assert s["approved_total"] == Decimal("140000")
    assert s["diff_funding_claimed"] == Decimal("20000")
    assert s["diff_claimed_approved"] == Decimal("-20000")
