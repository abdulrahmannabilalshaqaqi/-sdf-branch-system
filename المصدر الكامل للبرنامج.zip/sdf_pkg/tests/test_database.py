# -*- coding: utf-8 -*-
"""اختبارات قاعدة البيانات: المخطط، البذرة، والقيود."""
import sqlite3
import tempfile
from pathlib import Path

import pytest

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services.auth_service import authenticate


@pytest.fixture()
def db():
    tmp = Path(tempfile.mkdtemp()) / "test.db"
    database = Database(tmp)
    conn = database.connect()
    seed_all(conn)
    yield database
    database.close()


def test_schema_and_seed(db):
    conn = db.connect()
    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"training_files", "users", "file_statuses", "review_items",
            "attachments", "audit_log", "import_batches", "settings"} <= tables
    n_statuses = conn.execute("SELECT COUNT(*) c FROM file_statuses").fetchone()["c"]
    assert n_statuses == 11
    n_docs = conn.execute("SELECT COUNT(*) c FROM document_types").fetchone()["c"]
    assert n_docs >= 10


def test_default_admin_login(db):
    conn = db.connect()
    user = authenticate(conn, "admin", "admin123")
    assert user and user["role"] == "admin"
    assert authenticate(conn, "admin", "wrong") is None


def test_file_number_unique(db):
    conn = db.connect()
    conn.execute("INSERT INTO training_files (file_number) VALUES (1)")
    conn.commit()
    with pytest.raises(sqlite3.IntegrityError):
        conn.execute("INSERT INTO training_files (file_number) VALUES (1)")
