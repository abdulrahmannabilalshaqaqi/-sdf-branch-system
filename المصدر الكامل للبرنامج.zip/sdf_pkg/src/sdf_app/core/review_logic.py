# -*- coding: utf-8 -*-
"""
منطق المراجعة الفنية: العدد المعتمد المقترح + مطابقة أسماء المتدربين.

القاعدة الإدارية: العدد المعتمد المقترح = أقل عدد من الأعداد الأربعة
(العقد، الترشيحات، الحضور، الشهادات) — مع مراعاة أن البيانات غير المتوفرة
لا تُعامل كصفر، بل تُستبعد من المقارنة مع توثيق غيابها.
"""
import difflib
import re
from typing import Dict, List, Optional, Tuple

# ----------------------------------------------------------------------
# العدد المعتمد المقترح
# ----------------------------------------------------------------------

COUNT_SOURCES = (
    ("contract", "عدد المتدربين حسب العقد"),
    ("nominees", "عدد المرشحين"),
    ("attendance", "عدد الحاضرين حسب كشف الحضور"),
    ("certificates", "عدد الشهادات المرفقة"),
)


def suggest_approved_count(contract=None, nominees=None, attendance=None, certificates=None) -> dict:
    """إرجاع الاقتراح + الأساس + التحذيرات. لا يفترض الناقص صفرًا أبدًا."""
    values = {
        "contract": _to_int_or_none(contract),
        "nominees": _to_int_or_none(nominees),
        "attendance": _to_int_or_none(attendance),
        "certificates": _to_int_or_none(certificates),
    }
    available = {k: v for k, v in values.items() if v is not None}
    missing = [label for key, label in COUNT_SOURCES if values[key] is None]

    warnings: List[str] = []
    if not available:
        warnings.append("لا تتوفر أي من الأعداد الأربعة — يلزم استكمال البيانات أو توثيق استثناء معتمد.")
        return {"value": None, "used": {}, "missing": missing, "warnings": warnings}

    value = min(available.values())
    winners = [label for key, label in COUNT_SOURCES if values.get(key) == value]
    if missing:
        warnings.append("الأعداد غير المتوفرة (" + "، ".join(missing) + ") استُبعدت من المقارنة ولم تُعامل كصفر.")
    diffs = {}
    for key, label in COUNT_SOURCES:
        if values[key] is not None and values[key] != value:
            diffs[label] = values[key] - value
    return {"value": value, "used": available, "missing": missing, "winners": winners,
            "differences": diffs, "warnings": warnings}


def _to_int_or_none(value) -> Optional[int]:
    if value is None or isinstance(value, bool):
        return None
    try:
        text = str(value).strip()
        if not text:
            return None
        return int(float(text))
    except (ValueError, TypeError):
        return None


# ----------------------------------------------------------------------
# مطابقة الأسماء بين كشف الترشيحات وكشف الحضور
# ----------------------------------------------------------------------

_DIACRITICS = re.compile(r"[\u064B-\u0652\u0670]")
_ALEF_VARIANTS = re.compile(r"[أإآٱ]")
_HAMZA_FORMS = re.compile(r"[ؤئ]")


def normalize_arabic_name(name: str) -> str:
    """توحيد الاسم العربي للمقارنة: إزالة التشكيل، توحيد الألف والهمزات والتاء المربوطة."""
    if not name:
        return ""
    text = str(name).strip()
    text = _DIACRITICS.sub("", text)
    text = _ALEF_VARIANTS.sub("ا", text)
    text = _HAMZA_FORMS.sub("ء", text)
    text = text.replace("ة", "ه").replace("ى", "ي")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def match_names(nomination_names: List[str], attendance_names: List[str],
                similarity_threshold: float = 0.85) -> dict:
    """
    مطابقة الأسماء بين الكشفين.
    يعيد: المتطابقة، المرشحة غير الحاضرة، الحاضرة غير المرشحة،
    والمتشابهة التي تحتاج مراجعة بشرية (لا تُعتمد آليًا).
    """
    nom_norm = [(n, normalize_arabic_name(n)) for n in nomination_names if str(n).strip()]
    att_norm = [(a, normalize_arabic_name(a)) for a in attendance_names if str(a).strip()]

    att_pool = list(att_norm)
    matched: List[Tuple[str, str]] = []
    only_nomination: List[str] = []
    similar: List[Tuple[str, str, float]] = []

    for orig_n, norm_n in nom_norm:
        # 1) تطابق تام بعد التوحيد
        hit = next((i for i, (oa, na) in enumerate(att_pool) if na == norm_n), None)
        if hit is not None:
            matched.append((orig_n, att_pool[hit][0]))
            att_pool.pop(hit)
            continue
        # 2) تشابه يستحق المراجعة البشرية (لا اعتماد آلي)
        best, best_score = None, 0.0
        for oa, na in att_pool:
            score = difflib.SequenceMatcher(None, norm_n, na).ratio()
            if score > best_score:
                best, best_score = (oa, na), score
        if best is not None and best_score >= similarity_threshold:
            similar.append((orig_n, best[0], round(best_score, 2)))
        else:
            only_nomination.append(orig_n)

    # أسماء الحضور المتبقية (غير المرشحة) — نستبعد ما ظهر في similar
    similar_att = {s[1] for s in similar}
    only_attendance = [oa for oa, _ in att_pool if oa not in similar_att]

    # تكرار داخل كل كشف
    dup_nom = _find_duplicates(nomination_names)
    dup_att = _find_duplicates(attendance_names)

    return {
        "matched": matched,
        "only_nomination": only_nomination,
        "only_attendance": only_attendance,
        "similar_needs_review": similar,
        "duplicates_nomination": dup_nom,
        "duplicates_attendance": dup_att,
        "counts": {
            "nomination": len(nomination_names),
            "attendance": len(attendance_names),
            "matched": len(matched),
        },
    }


def _find_duplicates(names: List[str]) -> List[str]:
    seen, dups = {}, []
    for n in names:
        key = normalize_arabic_name(n)
        if not key:
            continue
        if key in seen and key not in dups:
            dups.append(n)
        seen[key] = True
    return dups


# ----------------------------------------------------------------------
# ملخص المراجعة الفنية
# ----------------------------------------------------------------------

REVIEW_RESULTS = ("مطابق", "غير مطابق", "غير مكتمل", "غير منطبق", "لم يراجع")


def review_summary(items: List[dict]) -> dict:
    """ملخص آلي لقائمة التحقق: المكتملة/الناقصة/الملاحظات — غير المنطبق ليس ناقصًا."""
    complete = [i for i in items if i.get("result") == "مطابق"]
    not_applicable = [i for i in items if i.get("result") == "غير منطبق"]
    missing = [i for i in items if i.get("result") in ("غير مطابق", "غير مكتمل")]
    pending = [i for i in items if i.get("result") in ("لم يراجع", None)]
    notes_needed = [i for i in items if i.get("result") in ("غير مطابق", "غير مكتمل") and i.get("notes")]
    return {
        "total": len(items),
        "complete": len(complete),
        "not_applicable": len(not_applicable),
        "missing": len(missing),
        "pending": len(pending),
        "missing_items": missing,
        "notes_needed": notes_needed,
        "is_technically_complete": len(missing) == 0 and len(pending) == 0,
    }
