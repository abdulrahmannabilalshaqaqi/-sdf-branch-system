# -*- coding: utf-8 -*-
"""
استيراد البيانات من Excel: قراءة، معاينة، مطابقة أعمدة، تحقق، كشف تكرار،
واستيراد آمن داخل معاملة قابلة للتراجع مع تقرير نتائج.
لا يعدّل ملف Excel الأصلي أبدًا.
"""
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from openpyxl import load_workbook

from ..core.validation import parse_date, parse_int, parse_money


def _is_xls(path: Path) -> bool:
    return Path(path).suffix.lower() == ".xls"


class _SheetReader:
    """واجهة قراءة موحدة لورقة عمل: openpyxl (xlsx/xlsm) أو xlrd (xls)."""

    def __init__(self, path: Path, sheet_name: str):
        self._path = Path(path)
        self._wb = None
        self._book = None
        if _is_xls(self._path):
            import xlrd
            self._book = xlrd.open_workbook(str(self._path))
            try:
                self._sh = self._book.sheet_by_name(sheet_name)
            except Exception:
                raise ValueError(f"لا توجد ورقة باسم «{sheet_name}» في الملف.")
            self._datemode = self._book.datemode
            self.headers = [self._xval(0, c) for c in range(self._sh.ncols)]
            self.total_rows = max(self._sh.nrows - 1, 0)
        else:
            self._wb = load_workbook(self._path, read_only=True, data_only=True)
            if sheet_name not in self._wb.sheetnames:
                raise ValueError(f"لا توجد ورقة باسم «{sheet_name}» في الملف.")
            self._ws = self._wb[sheet_name]
            self.headers = [c.value for c in next(self._ws.iter_rows(min_row=1, max_row=1))]
            self.total_rows = max((self._ws.max_row or 1) - 1, 0)

    def _xval(self, r: int, c: int):
        import xlrd
        cell = self._sh.cell(r, c)
        if cell.ctype == xlrd.XL_CELL_EMPTY or cell.ctype == xlrd.XL_CELL_BLANK:
            return None
        if cell.ctype == xlrd.XL_CELL_DATE:
            try:
                return xlrd.xldate_as_datetime(cell.value, self._datemode)
            except Exception:
                return None
        if cell.ctype == xlrd.XL_CELL_ERROR:
            return None
        v = cell.value
        if isinstance(v, str) and not v.strip():
            return None
        return v

    def iter_rows(self, start_row: int = 2):
        """صفوف القيم بدءًا من رقم الصف البشري start_row (1-based، بعد العناوين)."""
        if self._book is not None:
            for r in range(start_row - 1, self._sh.nrows):
                yield [self._xval(r, c) for c in range(self._sh.ncols)]
        else:
            for row in self._ws.iter_rows(min_row=start_row, values_only=True):
                yield list(row)

    def close(self):
        if self._wb is not None:
            self._wb.close()

# مطابقة عناوين الأعمدة العربية ← مفاتيح منطقية
EXCEL_TO_FIELD = {
    "رقم الملف": "file_number",
    "تاريخ أستلام الملف": "received_date",
    "تاريخ استلام الملف": "received_date",
    "الفرع": "branch",
    "رقم الملف بالفرع": "branch_file_number",
    "أسم البرنامج": "program_name",
    "اسم البرنامج": "program_name",
    "الجهة المستفيدة": "beneficiary",
    "بداية التنفيذ": "exec_start",
    "نهاية التنفيذ": "exec_end",
    "أسم المدرب": "trainer",
    "اسم المدرب": "trainer",
    "أستيفاء الوثائق": "docs_status",
    "استيفاء الوثائق": "docs_status",
    "مجال البرنامج": "program_field",
    "الجهة المنفذة": "implementing",
    "تاريخ العقد": "contract_date",
    "عدد المتدربين في العقد": "contract_trainees",
    "عدد الساعات حسب العقد": "contract_hours",
    "تكلفة الفرد حسب العقد": "contract_cost_per_trainee",
    "التكلفة المطالب بها من الجهة": "claimed_amount",
    "التكلفة المعتمدة من الفرع": "branch_approved_amount",
    "أسم المشرف": "supervisor_name",
    "اسم المشرف": "supervisor_name",
    "عدد المتدربين المعتمدين": "approved_trainees",
    "عدد الساعات المعتمدة": "approved_hours",
    "تكلفة المتدرب المعتمدة": "approved_cost_per_trainee",
    "مبلغ التمويل": "funding_amount",
    "ملاحظات": "notes",
    "تاريخ التنفيذ في العقد": "contract_exec_date",
    "عدد المرشحين": "nominees_count",
    "تاريخ الترشيح": "nomination_date",
    "تاريخ التنفيذ من كشوفات الحضور": "attendance_exec_date",
    "عدد المتدربين من كشوفات الحضور": "attendance_trainees",
    "مدة البرنامج": "program_duration",
    "مستوى التنفيذ من الاشراف": "supervision_level",
    "مؤهل المدرب": "trainer_qualification",
    "خبرة المدرب": "trainer_experience",
    "جهة أصدار الترخيص": "license_issuer",
    "جهة إصدار الترخيص": "license_issuer",
    "بداية مدة الترخيص": "license_start",
    "نهاية مدة الترخيص": "license_end",
    "مجال الجهة المنفذة": "implementing_field",
    "أسم البرنامج في الشهادة": "cert_program_name",
    "اسم البرنامج في الشهادة": "cert_program_name",
    "بداية تاريخ التنفيذ في الشهادة": "cert_exec_start",
    "نهاية تاريخ التنفيذ في الشهادة": "cert_exec_end",
    "عدد الشهائد": "certificates_count",
    "عدد الشهادات": "certificates_count",
    "مطابقة محتو المادة العلمية": "material_match",
    "مطابقة محتوى المادة العلمية": "material_match",
    "تاريخ المطالبة": "claim_date",
}

# أعمدة الملف الأصلي التي لا تُستورد (محسوبة أو مساعدة)
SKIPPED_ORIGINAL_COLUMNS = {
    "التكلفة الاجمالية حسب العقد", "تكلفة الساعة حسب العقد",
    "تكلفة الساعة المعتمدة", "التكلفة الاجمالية",
    "الفارق بين التكلفة المطالب بها والمعتمدة", "رقم الصف",
}

DATE_FIELDS = {"received_date", "contract_date", "exec_start", "exec_end", "contract_exec_date",
               "nomination_date", "attendance_exec_date", "license_start", "license_end",
               "cert_exec_start", "cert_exec_end", "claim_date"}
INT_FIELDS = {"file_number", "contract_trainees", "approved_trainees", "nominees_count",
              "attendance_trainees", "certificates_count"}
MONEY_FIELDS = {"contract_hours", "contract_cost_per_trainee", "claimed_amount",
                "branch_approved_amount", "approved_hours", "approved_cost_per_trainee",
                "funding_amount"}
LOOKUP_FIELDS = {"branch", "program_field", "beneficiary", "implementing", "trainer"}


@dataclass
class RowAnalysis:
    excel_row: int
    status: str = "ok"  # ok | empty | duplicate_file | duplicate_db | error
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    record: Dict = field(default_factory=dict)      # القيم المطبعة
    raw: Dict = field(default_factory=dict)         # القيم الأصلية


def list_sheets(path: Path) -> List[str]:
    if _is_xls(path):
        import xlrd
        return xlrd.open_workbook(str(path)).sheet_names()
    wb = load_workbook(path, read_only=True, data_only=True)
    names = wb.sheetnames
    wb.close()
    return names


def preview_sheet(path: Path, sheet_name: str, n_rows: int = 10) -> dict:
    """معاينة: العناوين + أول n صفًا + عدد الصفوف الكلي."""
    reader = _SheetReader(path, sheet_name)
    try:
        rows = []
        for i, row in enumerate(reader.iter_rows(start_row=2), start=2):
            if i > n_rows + 1:
                break
            rows.append([_cell_preview(v) for v in row])
        return {"headers": reader.headers, "rows": rows, "total_rows": reader.total_rows}
    finally:
        reader.close()


def _cell_preview(v):
    if v is None:
        return ""
    s = str(v)
    return s[:60] + "…" if len(s) > 60 else s


def auto_map_columns(headers: List[str]) -> Dict[int, str]:
    """مطابقة تلقائية: فهرس العمود ← المفتاح المنطقي (أول تطابق يفوز — لتجاهل أعمدة المساعدة المكررة)."""
    mapping = {}
    used_fields = set()
    for idx, h in enumerate(headers):
        if h is None:
            continue
        key = str(h).strip()
        if key in SKIPPED_ORIGINAL_COLUMNS or not key:
            continue
        if key in EXCEL_TO_FIELD:
            fkey = EXCEL_TO_FIELD[key]
            if fkey in used_fields:
                continue  # عمود مساعد مكرر (مثل AX في الملف الأصلي)
            used_fields.add(fkey)
            mapping[idx] = fkey
    return mapping


def analyze_rows(path: Path, sheet_name: str, mapping: Dict[int, str],
                 conn: sqlite3.Connection, header_row: int = 1) -> List[RowAnalysis]:
    """تحليل كل الصفوف: تحقق + تكرار (داخل الملف وضد قاعدة البيانات)."""
    reader = _SheetReader(path, sheet_name)
    existing_numbers = {r[0] for r in conn.execute("SELECT file_number FROM training_files")}
    seen_in_file = set()
    results: List[RowAnalysis] = []

    for excel_row, row in enumerate(reader.iter_rows(start_row=header_row + 1),
                                    start=header_row + 1):
        values = list(row)
        raw = {}
        for col_idx, fkey in mapping.items():
            if col_idx < len(values):
                raw[fkey] = values[col_idx]
        if all(v is None or str(v).strip() == "" for v in raw.values()):
            results.append(RowAnalysis(excel_row=excel_row, status="empty", raw=raw))
            continue

        ra = RowAnalysis(excel_row=excel_row, raw=dict(raw))
        rec: Dict = {}
        # 1) تحويل الأنواع — القيم غير الصالحة تُترك فارغة مع تحذير موثق (لا تُفقد البيانات)
        for fkey, val in raw.items():
            if fkey in DATE_FIELDS:
                iso, status, note = parse_date(val)
                if status == "invalid":
                    ra.warnings.append(f"{fkey}: {note} — تُرك الحقل فارغًا بانتظار المراجعة اليدوية")
                elif status == "ok":
                    rec[fkey] = iso
            elif fkey in INT_FIELDS:
                num, status = parse_int(val)
                if status == "invalid":
                    ra.warnings.append(f"{fkey}: قيمة عددية غير صالحة ({val}) — تُرك الحقل فارغًا")
                elif status == "ok":
                    rec[fkey] = num
            elif fkey in MONEY_FIELDS:
                num, status = parse_money(val)
                if status == "invalid":
                    ra.warnings.append(f"{fkey}: مبلغ غير صالح ({val}) — تُرك الحقل فارغًا")
                elif status == "ok":
                    rec[fkey] = float(num)
            elif fkey in LOOKUP_FIELDS:
                rec[fkey] = str(val).strip() if val not in (None, "") else None
            else:
                rec[fkey] = str(val).strip() if isinstance(val, str) else val
        # 2) رقم الملف إلزامي
        if rec.get("file_number") is None:
            ra.errors.append("رقم الملف إلزامي ومفقود في هذا الصف.")
        else:
            # 3) التكرار
            if rec["file_number"] in seen_in_file:
                ra.status = "duplicate_file"
                ra.errors.append(f"رقم الملف {rec['file_number']} مكرر داخل ملف Excel نفسه.")
            elif rec["file_number"] in existing_numbers:
                ra.status = "duplicate_db"
                ra.warnings.append(f"رقم الملف {rec['file_number']} موجود مسبقًا في قاعدة البيانات.")
            seen_in_file.add(rec["file_number"])
        if ra.errors and ra.status == "ok":
            ra.status = "error"
        ra.record = rec
        results.append(ra)
    reader.close()
    return results


def summarize_analysis(results: List[RowAnalysis]) -> dict:
    counts = {"ok": 0, "empty": 0, "duplicate_file": 0, "duplicate_db": 0, "error": 0,
              "with_warnings": 0}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1
        if r.warnings:
            counts["with_warnings"] += 1
    return counts


# ----------------------------------------------------------------------
# التنفيذ الفعلي داخل معاملة
# ----------------------------------------------------------------------

def _get_or_create_lookup(conn: sqlite3.Connection, table: str, name: str,
                          extra: dict = None) -> Optional[int]:
    if not name:
        return None
    name = " ".join(str(name).split())
    cur = conn.execute(f"SELECT id FROM {table} WHERE name = ?", (name,))
    row = cur.fetchone()
    if row:
        return row["id"]
    cols = ["name"] + list((extra or {}).keys())
    vals = [name] + list((extra or {}).values())
    cur = conn.execute(
        f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals)
    return cur.lastrowid


def _resolve_lookups(conn: sqlite3.Connection, rec: dict) -> dict:
    out = dict(rec)
    branch = out.pop("branch", None)
    pfield = out.pop("program_field", None)
    beneficiary = out.pop("beneficiary", None)
    implementing = out.pop("implementing", None)
    trainer = out.pop("trainer", None)
    out["branch_id"] = _get_or_create_lookup(conn, "branches", branch)
    out["field_id"] = _get_or_create_lookup(conn, "program_fields", pfield)
    out["beneficiary_id"] = _get_or_create_lookup(conn, "entities", beneficiary, {"kind": "beneficiary"})
    out["implementing_id"] = _get_or_create_lookup(conn, "entities", implementing, {"kind": "implementing"})
    out["trainer_id"] = _get_or_create_lookup(conn, "trainers", trainer)
    return out


def execute_import(conn: sqlite3.Connection, analyses: List[RowAnalysis],
                   duplicate_policy: str = "skip",
                   user_id: Optional[int] = None,
                   source_file: str = "", sheet_name: str = "",
                   status_code: str = "new") -> dict:
    """
    تنفيذ الاستيراد داخل معاملة واحدة (تراجع كامل عند أي فشل).
    duplicate_policy: skip | update | manual(يُعامل كتخطٍّ مع تقرير للمراجعة)
    """
    assert duplicate_policy in ("skip", "update", "manual")
    batch_cur = conn.execute(
        """INSERT INTO import_batches (user_id, source_file, sheet_name, total_rows, status)
           VALUES (?,?,?,?, 'جارٍ')""",
        (user_id, source_file, sheet_name, len(analyses)))
    batch_id = batch_cur.lastrowid

    status_row = conn.execute("SELECT id FROM file_statuses WHERE code = ?", (status_code,)).fetchone()
    default_status_id = status_row["id"] if status_row else None

    imported = updated = skipped = errored = 0
    report_lines = []
    try:
        with conn:  # معاملة
            for ra in analyses:
                if ra.status == "empty":
                    skipped += 1
                    continue
                if ra.status in ("error", "duplicate_file"):
                    errored += 1
                    report_lines.append(f"صف {ra.excel_row}: " + "؛ ".join(ra.errors))
                    continue
                if ra.status == "duplicate_db":
                    if duplicate_policy == "skip":
                        skipped += 1
                        report_lines.append(f"صف {ra.excel_row}: مكرر — تم التخطي (ملف {ra.record.get('file_number')}).")
                        continue
                    if duplicate_policy == "manual":
                        skipped += 1
                        report_lines.append(f"صف {ra.excel_row}: مكرر — يحتاج مراجعة يدوية (ملف {ra.record.get('file_number')}).")
                        continue
                    # update
                    rec = _resolve_lookups(conn, ra.record)
                    rec.pop("file_number", None)
                    sets = ", ".join(f"{k} = ?" for k in rec)
                    conn.execute(f"UPDATE training_files SET {sets}, updated_at = datetime('now') "
                                 f"WHERE file_number = ?", (*rec.values(), ra.record["file_number"]))
                    updated += 1
                    continue
                # ok → إدخال (مع توثيق التحذيرات في التقرير)
                rec = _resolve_lookups(conn, ra.record)
                rec["status_id"] = default_status_id
                rec["legacy_row"] = ra.excel_row
                cols = ", ".join(rec.keys())
                conn.execute(f"INSERT INTO training_files ({cols}) VALUES ({','.join('?' * len(rec))})",
                             tuple(rec.values()))
                imported += 1
                if ra.warnings:
                    report_lines.append(f"صف {ra.excel_row}: استُورد مع تحذيرات — " + "؛ ".join(ra.warnings))
        conn.execute(
            """UPDATE import_batches SET finished_at = datetime('now'), imported_rows = ?,
               updated_rows = ?, skipped_rows = ?, error_rows = ?, status = 'مكتمل',
               report_text = ? WHERE id = ?""",
            (imported, updated, skipped, errored, "\n".join(report_lines), batch_id))
        conn.commit()
    except Exception as exc:  # تراجع تلقائي عبر with، وتوثيق الفشل
        conn.execute("UPDATE import_batches SET finished_at = datetime('now'), status = 'فشل', "
                     "report_text = ? WHERE id = ?", (f"فشل الاستيراد: {exc}", batch_id))
        conn.commit()
        raise
    return {"batch_id": batch_id, "imported": imported, "updated": updated,
            "skipped": skipped, "errored": errored, "report": report_lines}
