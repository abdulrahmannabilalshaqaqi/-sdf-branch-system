#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rebuild SDFBranchSystem-source.zip from ~/workspace/sdf_branch_system."""
import shutil
import zipfile
from pathlib import Path

SRC = Path("/home/hatch/workspace/sdf_branch_system")
OUT = Path("/home/hatch/workspace/SDFBranchSystem-source.zip")
STAGE = Path("/tmp/sdf_pkg_stage")
EXCLUDE_DIRS = {".venv", "__pycache__", ".git", ".pytest_cache", ".mypy_cache"}
EXCLUDE_FILES = {".DS_Store"}

if STAGE.exists():
    shutil.rmtree(STAGE)
pkg = STAGE / "sdf_pkg"
pkg.mkdir(parents=True)

for item in SRC.iterdir():
    if item.name in EXCLUDE_DIRS or item.name in EXCLUDE_FILES:
        continue
    dest = pkg / item.name
    if item.is_dir():
        if item.name == "samples":
            # مجلد العينات: نستثني قاعدة البيانات (بيانات حقيقية — لا تُوزع)
            shutil.copytree(item, dest, ignore=shutil.ignore_patterns(
                "__pycache__", ".pytest_cache", "*.pyc", ".DS_Store", "_sample.db"))
        else:
            shutil.copytree(item, dest, ignore=shutil.ignore_patterns(
                "__pycache__", ".pytest_cache", "*.pyc", ".DS_Store"))
    else:
        shutil.copy2(item, dest)

if OUT.exists():
    OUT.unlink()
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(STAGE.rglob("*")):
        if p.is_file():
            z.write(p, p.relative_to(STAGE))

print("built:", OUT, f"({OUT.stat().st_size // 1024} KB)")
# sanity: fix line present?
with zipfile.ZipFile(OUT) as z:
    src = z.read("sdf_pkg/src/sdf_app/main.py").decode("utf-8")
    assert "if login.exec() != QDialog.Accepted:" in src, "login fix missing!"
    assert "from .ui" not in src, "relative imports remain in main.py!"
    print("sanity checks passed: login fix present, no relative imports in main.py")
shutil.rmtree(STAGE)
