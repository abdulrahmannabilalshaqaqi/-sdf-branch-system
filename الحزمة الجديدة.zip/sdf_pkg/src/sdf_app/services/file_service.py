# -*- coding: utf-8 -*-
"""خدمة الملفات: إنشاء/تعديل/بحث/حالة/إحصاءات لوحة التحكم."""
import sqlite3
from datetime import date, timedelta
from typing import Dict, List, Optional, Tuple

from ..core import finance
from ..core.validation import validate_file_record
from ..core.workflow import STATUS_NAMES, approval_blockers, can_transition

FILE_COLUMNS = [
    "file_number", "branch_file_number", "clearance_number", "received_date", "branch_id",
    "program_id", "program_name",
    "field_id", "beneficiary_id", "implementing_id", "exec_start", "exec_end",
    "group_name", "level", "exec_place",
    "trainer_id", "trainer_qualification", "trainer_experience", "docs_status",
    "contract_date", "contract_number", "contract_trainees", "contract_hours", "contract_cost_per_trainee",
    "cost_currency", "exchange_rate",
    "claimed_amount", "branch_approved_amount", "supervisor_name", "approved_trainees",
    "approved_trainees_override_reason", "suggested_trainees", "approved_hours",
    "approved_cost_per_trainee", "funding_amount", "notes", "contract_exec_date",
    "nominees_count", "nomination_date", "attendance_exec_date", "attendance_exec_match",
    "attendance_trainees", "program_duration", "supervision_level", "supervision_date",
    "license_issuer", "license_start",
    "license_end", "implementing_field", "cert_program_name", "cert_program_match",
    "cert_exec_start", "cert_exec_end", "cert_exec_match", "certificates_count",
    "material_match", "material_file_id", "claim_date",
    "disburse_amount", "ledger_number", "check_number", "check_received_date",
    "recipient_name", "delivered_to_director_date",
    "status_id", "reviewer_id", "legacy_row",
]

JOIN_SQL = """
SELECT f.*,
       b.name AS branch_name, pf.name AS program_field,
       ben.name AS beneficiary_name, imp.name AS implementing_name,
       t.name AS trainer_name, s.code AS status_code, s.name AS status_name,
       u.full_name AS reviewer_name
FROM training_files f
LEFT JOIN branches b ON b.id = f.branch_id
LEFT JOIN program_fields pf ON pf.id = f.field_id
LEFT JOIN entities ben ON ben.id = f.beneficiary_id
LEFT JOIN entities imp ON imp.id = f.implementing_id
LEFT JOIN trainers t ON t.id = f.trainer_id
LEFT JOIN file_statuses s ON s.id = f.status_id
LEFT JOIN users u ON u.id = f.reviewer_id
"""


class FileService:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    # -- إنشاء / تعديل ---------------------------------------------------
    def create(self, data: dict, user_id: Optional[int] = None) -> int:
        errors = validate_file_record(data)
        if errors:
            raise ValueError("؛ ".join(errors))
        if self.conn.execute("SELECT 1 FROM training_files WHERE file_number = ?",
                             (data["file_number"],)).fetchone():
            raise ValueError(f"رقم الملف {data['file_number']} مسجل مسبقًا.")
        clean = {k: data.get(k) for k in FILE_COLUMNS if k in data}
        if not clean.get("status_id"):
            row = self.conn.execute("SELECT id FROM file_statuses WHERE code='new'").fetchone()
            clean["status_id"] = row["id"]
        clean["created_by"] = user_id
        clean["updated_by"] = user_id
        cols = ", ".join(clean.keys())
        cur = self.conn.execute(f"INSERT INTO training_files ({cols}) VALUES ({','.join('?'*len(clean))})",
                                tuple(clean.values()))
        file_id = cur.lastrowid
        self._audit(user_id, "file.create", "training_files", file_id,
                    f"إنشاء ملف رقم {data['file_number']}")
        self.conn.commit()
        return file_id

    def update(self, file_id: int, data: dict, user_id: Optional[int] = None):
        errors = validate_file_record({**self.get(file_id), **data})
        if errors:
            raise ValueError("؛ ".join(errors))
        if "file_number" in data:
            dup = self.conn.execute(
                "SELECT 1 FROM training_files WHERE file_number=? AND id<>?",
                (data["file_number"], file_id)).fetchone()
            if dup:
                raise ValueError(f"رقم الملف {data['file_number']} مسجل لملف آخر.")
        clean = {k: data[k] for k in FILE_COLUMNS if k in data}
        if not clean:
            return
        # رصد التعديلات المالية في سجل التدقيق
        fin_fields = {"claimed_amount", "branch_approved_amount", "approved_trainees",
                      "approved_cost_per_trainee", "approved_hours", "funding_amount"}
        if fin_fields & set(clean):
            self._audit(user_id, "finance.update", "training_files", file_id,
                        "تعديل بيانات مالية: " + "، ".join(sorted(fin_fields & set(clean))))
        clean["updated_by"] = user_id
        sets = ", ".join(f"{k}=?" for k in clean)
        self.conn.execute(f"UPDATE training_files SET {sets}, updated_at=datetime('now') WHERE id=?",
                          (*clean.values(), file_id))
        self._audit(user_id, "file.update", "training_files", file_id, "تعديل بيانات الملف")
        self.conn.commit()

    def get(self, file_id: int) -> Optional[dict]:
        row = self.conn.execute(JOIN_SQL + " WHERE f.id=?", (file_id,)).fetchone()
        if not row:
            return None
        rec = dict(row)
        rec.update(finance.summarize(rec))
        return rec

    def get_by_number(self, file_number: int) -> Optional[dict]:
        row = self.conn.execute(JOIN_SQL + " WHERE f.file_number=?", (file_number,)).fetchone()
        if not row:
            return None
        rec = dict(row)
        rec.update(finance.summarize(rec))
        return rec

    def duplicate_file(self, source_id: int, new_file_number: int,
                       copy_nomination: bool = True, copy_attendance: bool = True,
                       user_id: Optional[int] = None) -> int:
        """نسخ بيانات ملف إلى ملف جديد برقم مختلف."""
        src = self.conn.execute("SELECT * FROM training_files WHERE id=?", (source_id,)).fetchone()
        if not src:
            raise ValueError("الملف المصدر غير موجود.")
        if self.conn.execute("SELECT 1 FROM training_files WHERE file_number=?",
                             (new_file_number,)).fetchone():
            raise ValueError(f"رقم الملف {new_file_number} مسجل مسبقًا.")
        src = dict(src)
        # حقول لا تُنسخ: تُصفّر لبداية دورة جديدة
        skip = {"id", "created_at", "updated_at", "created_by", "updated_by",
                "legacy_row", "disburse_amount", "ledger_number", "check_number",
                "check_received_date", "recipient_name", "delivered_to_director_date"}
        data = {k: src.get(k) for k in FILE_COLUMNS
                if k in src and k not in skip and k != "file_number"}
        data["file_number"] = new_file_number
        row = self.conn.execute("SELECT id FROM file_statuses WHERE code='new'").fetchone()
        data["status_id"] = row["id"]
        cols = ", ".join(data.keys())
        cur = self.conn.execute(
            f"INSERT INTO training_files ({cols}) VALUES ({','.join('?' * len(data))})",
            tuple(data.values()))
        new_id = cur.lastrowid
        if copy_nomination:
            for r in self.conn.execute(
                    "SELECT seq, full_name, beneficiary_id, notes FROM trainees_nomination"
                    " WHERE file_id=? ORDER BY seq", (source_id,)):
                self.conn.execute(
                    "INSERT INTO trainees_nomination (file_id, seq, full_name, beneficiary_id, notes)"
                    " VALUES (?,?,?,?,?)",
                    (new_id, r["seq"], r["full_name"], r["beneficiary_id"], r["notes"]))
        if copy_attendance:
            for r in self.conn.execute(
                    "SELECT seq, full_name, days_attended, in_supervision_report, notes"
                    " FROM trainees_attendance WHERE file_id=? ORDER BY seq", (source_id,)):
                self.conn.execute(
                    "INSERT INTO trainees_attendance (file_id, seq, full_name, days_attended,"
                    " in_supervision_report, notes) VALUES (?,?,?,?,?,?)",
                    (new_id, r["seq"], r["full_name"], r["days_attended"],
                     r["in_supervision_report"], r["notes"]))
        self._audit(user_id, "file.duplicate", "training_files", new_id,
                    f"نسخ الملف {src['file_number']} إلى {new_file_number}")
        self.conn.commit()
        return new_id

    # -- الصرف -------------------------------------------------------------------
    def confirm_delivery_to_director(self, file_ids: List[int], user_id: Optional[int] = None,
                                     notes: str = "") -> dict:
        """تأكيد تسليم الملفات لمكتب المدير التنفيذي: الحالة ← «قيد الصرف» مع توثيق التاريخ."""
        from datetime import date as _date
        today = _date.today().isoformat()
        done, errors = [], []
        for fid in file_ids:
            try:
                rec = self.get(fid)
                if not rec:
                    raise ValueError("الملف غير موجود.")
                if rec["status_code"] != "ready_disburse":
                    raise ValueError(f"حالة الملف «{rec['status_code']}» لا تسمح بالتسليم"
                                     " (يجب أن يكون «جاهزة للصرف»).")
                self.conn.execute(
                    "UPDATE training_files SET delivered_to_director_date=?, updated_at=datetime('now')"
                    " WHERE id=?", (today, fid))
                self.change_status(fid, "disbursing", user_id=user_id,
                                   notes=notes or "تسليم لمكتب المدير التنفيذي لاستكمال الصرف")
                done.append(fid)
            except ValueError as exc:
                errors.append(f"ملف {fid}: {exc}")
        return {"done": done, "errors": errors, "date": today}

    def save_disbursement_data(self, file_id: int, data: dict,
                               user_id: Optional[int] = None) -> str:
        """حفظ بيانات الصرف لملف. عند اكتمال الشيك والقيد ← «منصرفة». يعيد الحالة النهائية."""
        allowed = {"disburse_amount", "ledger_number", "check_number",
                   "check_received_date", "recipient_name"}
        clean = {k: (data.get(k) or None) for k in allowed if k in data}
        if clean:
            sets = ", ".join(f"{k}=?" for k in clean)
            self.conn.execute(f"UPDATE training_files SET {sets}, updated_at=datetime('now') WHERE id=?",
                              (*clean.values(), file_id))
        self._audit(user_id, "disburse.update", "training_files", file_id,
                    "تحديث بيانات الصرف: " + "، ".join(sorted(clean)))
        self.conn.commit()
        rec = self.get(file_id)
        # اكتمال بيانات الشيك والقيد ← منصرفة
        if (rec["status_code"] == "disbursing" and rec.get("ledger_number")
                and rec.get("check_number")):
            self.change_status(file_id, "disbursed", user_id=user_id,
                               notes="استكمال بيانات الشيك والقيد")
            return "disbursed"
        return rec["status_code"]

    def search_disbursed(self, q: str) -> List[dict]:
        """بحث في الملفات المنصرفة/قيد الصرف برقم القيد أو الشيك."""
        like = f"%{q.strip()}%"
        rows = self.conn.execute(
            JOIN_SQL + """ WHERE s.code IN ('disbursing','disbursed')
                           AND (f.ledger_number LIKE ? OR f.check_number LIKE ?
                                OR CAST(f.file_number AS TEXT) LIKE ?)
                           ORDER BY f.updated_at DESC""",
            (like, like, like)).fetchall()
        out = []
        for r in rows:
            rec = dict(r)
            rec.update(finance.summarize(rec))
            out.append(rec)
        return out

    # -- تغيير الحالة ------------------------------------------------------
    def change_status(self, file_id: int, to_code: str, user_id: Optional[int] = None,
                      notes: str = "", force_exception: bool = False) -> dict:
        rec = self.get(file_id)
        if not rec:
            raise ValueError("الملف غير موجود.")
        from_code = rec["status_code"]
        if not can_transition(from_code, to_code):
            raise ValueError(f"الانتقال من «{STATUS_NAMES.get(from_code)}» إلى "
                             f"«{STATUS_NAMES.get(to_code)}» غير مسموح.")
        blockers = []
        if to_code == "approved":
            items = self.review_items(file_id)
            blockers = approval_blockers(rec, items)
            if blockers and not force_exception:
                raise ValueError("لا يمكن الاعتماد: " + "؛ ".join(blockers))
        new_id = self.conn.execute("SELECT id FROM file_statuses WHERE code=?", (to_code,)).fetchone()["id"]
        self.conn.execute("UPDATE training_files SET status_id=?, updated_at=datetime('now') WHERE id=?",
                          (new_id, file_id))
        self.conn.execute(
            """INSERT INTO file_history (file_id, changed_by, from_status_id, to_status_id, notes)
               VALUES (?,?,?,?,?)""",
            (file_id, user_id, rec["status_id"], new_id,
             notes + (" [استثناء موثق]" if blockers and force_exception else "")))
        self._audit(user_id, "status.change", "training_files", file_id,
                    f"{STATUS_NAMES.get(from_code)} ← {STATUS_NAMES.get(to_code)}" + (f": {notes}" if notes else ""))
        self.conn.commit()
        return {"blockers": blockers, "overridden": bool(blockers and force_exception)}

    def review_items(self, file_id: int) -> List[dict]:
        rows = self.conn.execute(
            """SELECT ri.*, dt.name AS document_name, dt.required_default
               FROM review_items ri JOIN document_types dt ON dt.id=ri.document_type_id
               WHERE ri.file_id=? ORDER BY dt.sort_order""", (file_id,)).fetchall()
        return [dict(r) for r in rows]

    def history(self, file_id: int) -> List[dict]:
        rows = self.conn.execute(
            """SELECT h.*, u.full_name AS user_name, s1.name AS from_name, s2.name AS to_name
               FROM file_history h
               LEFT JOIN users u ON u.id=h.changed_by
               LEFT JOIN file_statuses s1 ON s1.id=h.from_status_id
               LEFT JOIN file_statuses s2 ON s2.id=h.to_status_id
               WHERE h.file_id=? ORDER BY h.changed_at DESC""", (file_id,)).fetchall()
        return [dict(r) for r in rows]

    # -- البحث ----------------------------------------------------------------
    def search(self, filters: dict = None, page: int = 1, per_page: int = 50) -> Tuple[List[dict], int]:
        filters = filters or {}
        where, params = ["1=1"], []
        q = (filters.get("q") or "").strip()
        if q:
            where.append("""(CAST(f.file_number AS TEXT) LIKE ? OR f.branch_file_number LIKE ?
                            OR f.program_name LIKE ? OR ben.name LIKE ? OR imp.name LIKE ?
                            OR t.name LIKE ?)""")
            like = f"%{q}%"
            params += [like] * 6
        for key, col in (("branch_id", "f.branch_id"), ("field_id", "f.field_id"),
                         ("status_code", "s.code"), ("beneficiary_id", "f.beneficiary_id"),
                         ("implementing_id", "f.implementing_id")):
            if filters.get(key):
                where.append(f"{col}=?")
                params.append(filters[key])
        if filters.get("date_from"):
            where.append("f.received_date>=?")
            params.append(filters["date_from"])
        if filters.get("date_to"):
            where.append("f.received_date<=?")
            params.append(filters["date_to"])
        if filters.get("has_diff"):
            where.append("(f.claimed_amount IS NOT NULL AND f.funding_amount IS NOT NULL "
                         "AND f.funding_amount != f.claimed_amount)")
        codes = filters.get("status_codes")
        if codes:
            where.append(f"s.code IN ({','.join('?' for _ in codes)})")
            params += list(codes)
        if filters.get("overdue_days"):
            days = int(filters["overdue_days"])
            where.append("f.received_date IS NOT NULL AND f.received_date < date('now', ?)")
            params.append(f"-{days} days")
            where.append("s.code NOT IN ('approved','archived','rejected')")

        order = filters.get("order", "f.received_date DESC, f.file_number DESC")
        total = self.conn.execute(
            f"""SELECT COUNT(*) c FROM training_files f
                LEFT JOIN entities ben ON ben.id=f.beneficiary_id
                LEFT JOIN entities imp ON imp.id=f.implementing_id
                LEFT JOIN trainers t ON t.id=f.trainer_id
                LEFT JOIN file_statuses s ON s.id=f.status_id
                WHERE {' AND '.join(where)}""", params).fetchone()["c"]
        rows = self.conn.execute(
            JOIN_SQL + f" WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ? OFFSET ?",
            (*params, per_page, (page - 1) * per_page)).fetchall()
        result = []
        for r in rows:
            rec = dict(r)
            rec.update(finance.summarize(rec))
            result.append(rec)
        return result, total

    # -- لوحة التحكم ------------------------------------------------------------
    def dashboard_stats(self, deadline_days: int = 30, filters: dict = None) -> dict:
        """إحصاءات لوحة التحكم مع دعم ترشيح ذاتي (فرع/مجال/شهر-تنفيذ)."""
        conn = self.conn
        filters = filters or {}
        fwhere, fparams = ["1=1"], []
        if filters.get("branch_id"):
            fwhere.append("f.branch_id=?")
            fparams.append(filters["branch_id"])
        if filters.get("field_id"):
            fwhere.append("f.field_id=?")
            fparams.append(filters["field_id"])
        if filters.get("ym"):
            fwhere.append("substr(f.exec_start,1,7)=?")
            fparams.append(filters["ym"])
        fw = " AND ".join(fwhere)

        total = conn.execute(f"SELECT COUNT(*) c FROM training_files f WHERE {fw}",
                             fparams).fetchone()["c"]
        by_status = {r["code"]: r["c"] for r in conn.execute(
            f"""SELECT s.code, COUNT(f.id) c FROM file_statuses s
               LEFT JOIN training_files f ON f.status_id=s.id AND {fw}
               GROUP BY s.code""", fparams)}
        cutoff = (date.today() - timedelta(days=deadline_days)).isoformat()
        overdue = conn.execute(
            f"""SELECT COUNT(*) c FROM training_files f JOIN file_statuses s ON s.id=f.status_id
               WHERE s.is_terminal=0 AND s.code NOT IN ('approved','disbursed') AND {fw}
               AND f.received_date IS NOT NULL AND f.received_date < ?""",
            (*fparams, cutoff)).fetchone()["c"]

        sums = {"claimed": 0.0, "funding": 0.0}
        trainees_total = 0
        for r in conn.execute(f"SELECT claimed_amount, approved_trainees, funding_amount"
                              f" FROM training_files f WHERE {fw}", fparams):
            if r["claimed_amount"]:
                sums["claimed"] += float(r["claimed_amount"])
            if r["funding_amount"]:
                sums["funding"] += float(r["funding_amount"])
            if r["approved_trainees"]:
                trainees_total += int(r["approved_trainees"])

        # الرسوم البيانية تبقى شاملة دائمًا (للتنقل بين الفروع/المجالات/الأشهر)
        by_branch = [dict(r) for r in conn.execute(
            """SELECT b.id, b.name, COUNT(f.id) c FROM branches b
               LEFT JOIN training_files f ON f.branch_id=b.id
               GROUP BY b.id, b.name ORDER BY c DESC""")]
        by_field = [dict(r) for r in conn.execute(
            """SELECT pf.id, pf.name, COUNT(f.id) c FROM program_fields pf
               LEFT JOIN training_files f ON f.field_id=pf.id
               GROUP BY pf.id, pf.name ORDER BY c DESC""")]
        by_month = [dict(r) for r in conn.execute(
            """SELECT substr(exec_start,1,4) AS y, substr(exec_start,6,2) AS m,
                      substr(exec_start,1,7) AS ym, COUNT(*) c FROM training_files
               WHERE exec_start IS NOT NULL AND exec_start <> ''
               GROUP BY ym ORDER BY ym DESC LIMIT 12""")]
        return {
            "total": total, "by_status": by_status, "overdue": overdue,
            "sums": sums, "trainees_total": trainees_total,
            "diff_claimed_funding": sums["claimed"] - sums["funding"],
            "by_branch": by_branch, "by_field": by_field, "by_month": by_month,
        }

    # -- تدقيق -------------------------------------------------------------------
    def _audit(self, user_id, action, entity, entity_id, details=""):
        username = None
        if user_id:
            r = self.conn.execute("SELECT username FROM users WHERE id=?", (user_id,)).fetchone()
            username = r["username"] if r else None
        self.conn.execute(
            "INSERT INTO audit_log (user_id, username, action, entity, entity_id, details)"
            " VALUES (?,?,?,?,?,?)", (user_id, username, action, entity, entity_id, details))

    def delete_attachment(self, file_id: int, attachment_id: int,
                          user_id: Optional[int] = None) -> bool:
        """حذف مرفق: السجل + الملف الفعلي + قيد في سجل التدقيق."""
        from .. import config as cfg
        r = self.conn.execute(
            "SELECT original_name, stored_name FROM attachments WHERE id=? AND file_id=?",
            (attachment_id, file_id)).fetchone()
        if not r:
            return False
        try:
            (cfg.attachments_dir() / str(file_id) / r["stored_name"]).unlink(missing_ok=True)
        except OSError:
            pass
        self.conn.execute("DELETE FROM attachments WHERE id=?", (attachment_id,))
        self._audit(user_id, "attachment.delete", "attachments", attachment_id,
                    f"حذف المرفق «{r['original_name']}» من الملف {file_id}")
        self.conn.commit()
        return True
