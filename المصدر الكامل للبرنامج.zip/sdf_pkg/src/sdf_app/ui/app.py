# -*- coding: utf-8 -*-
"""تهيئة تطبيق Qt: اتجاه RTL، الخط العربي، والتنسيق العام."""
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

from .. import config

STYLESHEET = """
QApplication, QWidget { font-family: "Segoe UI", "Tahoma", "Arial"; }
QMainWindow { background: #F4F6FA; }
#sidebar { background: #1F3A5F; }
#sidebar QPushButton {
    color: #DCE4F0; background: transparent; border: none;
    text-align: right; padding: 12px 18px; font-size: 14px;
    border-right: 4px solid transparent;
}
#sidebar QPushButton:hover { background: #2A4A73; }
#sidebar QPushButton:checked { background: #2A4A73; border-right: 4px solid #F2B705; color: #FFFFFF; font-weight: bold; }
#sidebarTitle { color: #FFFFFF; font-size: 15px; font-weight: bold; padding: 16px; }
#pageTitle { font-size: 20px; font-weight: bold; color: #1F3A5F; }
QPushButton[primary="true"] {
    background: #1F3A5F; color: white; border-radius: 6px; padding: 8px 18px; font-size: 13px;
}
QPushButton[primary="true"]:hover { background: #2A4A73; }
QPushButton[primary="true"]:disabled { background: #9AA3B2; }
QPushButton[warn="true"] { background: #C0392B; color: white; border-radius: 6px; padding: 8px 18px; }
QPushButton[ok="true"] { background: #1E7E34; color: white; border-radius: 6px; padding: 8px 18px; }
QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit {
    border: 1px solid #C9D2E0; border-radius: 6px; padding: 7px; font-size: 13px; background: white;
}
QLineEdit:focus, QComboBox:focus, QTextEdit:focus { border: 1.5px solid #1F3A5F; }
QTableWidget { background: white; border: 1px solid #D5DCE8; border-radius: 8px;
    gridline-color: #E8EDF4; font-size: 13px; }
QTableWidget::item:selected { background: #D6E4F7; color: #1F3A5F; }
QHeaderView::section { background: #1F3A5F; color: white; padding: 8px; font-size: 13px; border: none; }
QTabWidget::pane { border: 1px solid #D5DCE8; border-radius: 8px; background: white; }
QTabBar::tab { background: #E8EDF4; padding: 10px 22px; margin: 2px; border-radius: 6px; font-size: 13px; }
QTabBar::tab:selected { background: #1F3A5F; color: white; font-weight: bold; }
QGroupBox { border: 1px solid #D5DCE8; border-radius: 8px; margin-top: 12px; font-size: 14px; font-weight: bold; color: #1F3A5F; background: white; }
QGroupBox::title { subcontrol-origin: margin; right: 12px; padding: 0 6px; }
#statCard { background: white; border: 1px solid #D5DCE8; border-radius: 10px; }
#statValue { font-size: 26px; font-weight: bold; color: #1F3A5F; }
#statTitle { font-size: 13px; color: #5A6B85; }
#statSub { font-size: 11px; color: #8A97AD; }
QStatusBar { background: #1F3A5F; color: white; }
QMessageBox { font-size: 13px; }
"""


def create_app(argv=None) -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication(argv if argv is not None else sys.argv)
    app.setApplicationName(config.APP_NAME_AR)
    app.setOrganizationName("SkillsDevelopmentFund")
    app.setLayoutDirection(Qt.RightToLeft)
    font = QFont("Segoe UI", 10)
    font.setStyleHint(QFont.SansSerif)
    app.setFont(font)
    app.setStyleSheet(STYLESHEET)
    return app
