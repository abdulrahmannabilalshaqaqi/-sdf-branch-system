# -*- coding: utf-8 -*-
"""ودجات مشتركة: بطاقة إحصائية، رسم أعمدة، ومساعدات."""
from PySide6.QtCore import Qt, Signal, QRect
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QVBoxLayout, QWidget


class StatCard(QFrame):
    """بطاقة مؤشر قابلة للنقر — تنقل لملفات المؤشر عند النقر."""
    clicked = Signal(str)

    def __init__(self, key: str, title: str, parent=None):
        super().__init__(parent)
        self._key = key
        self.setObjectName("statCard")
        self.setCursor(Qt.PointingHandCursor)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        self.title_lbl = QLabel(title)
        self.title_lbl.setObjectName("statTitle")
        self.title_lbl.setAlignment(Qt.AlignRight)
        self.value_lbl = QLabel("—")
        self.value_lbl.setObjectName("statValue")
        self.value_lbl.setAlignment(Qt.AlignRight)
        self.sub_lbl = QLabel("")
        self.sub_lbl.setObjectName("statSub")
        self.sub_lbl.setAlignment(Qt.AlignRight)
        layout.addWidget(self.title_lbl)
        layout.addWidget(self.value_lbl)
        layout.addWidget(self.sub_lbl)
        # شريط تمييز جانبي
        self._accent = QColor("#1F3A5F")

    def set_value(self, value: str, sub: str = "", accent: str = None):
        self.value_lbl.setText(value)
        self.sub_lbl.setText(sub)
        if accent:
            self._accent = QColor(accent)
            self.update()

    def mousePressEvent(self, event):
        self.clicked.emit(self._key)
        super().mousePressEvent(event)

    def paintEvent(self, event):
        super().paintEvent(event)
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(self._accent)
        # شريط على اليمين (RTL)
        p.drawRoundedRect(self.width() - 6, 8, 6, self.height() - 16, 3, 3)


class BarChart(QWidget):
    """رسم أعمدة أفقي بسيط بـ QPainter — بدون مكتبات خارجية."""

    def __init__(self, parent=None, bar_color="#1F3A5F", height_per_bar=34):
        super().__init__(parent)
        self._data = []  # [(label, value)]
        self._bar_color = QColor(bar_color)
        self._hpb = height_per_bar
        self.setMinimumHeight(60)

    def set_data(self, data):
        self._data = [(str(l), float(v or 0)) for l, v in data]
        self.setMinimumHeight(max(60, len(self._data) * self._hpb + 10))
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if not self._data:
            p.drawText(self.rect(), Qt.AlignCenter, "لا توجد بيانات")
            return
        max_v = max((v for _, v in self._data), default=1) or 1
        label_w = 130
        val_w = 70
        bar_area = self.width() - label_w - val_w - 20
        y = 8
        fm = p.fontMetrics()
        for label, value in self._data:
            # التسمية يمينًا
            p.setPen(QColor("#1F3A5F"))
            p.drawText(QRect(self.width() - label_w - 8, y, label_w, self._hpb - 8),
                       Qt.AlignRight | Qt.AlignVCenter, label)
            # الشريط (من اليمين)
            bw = int(bar_area * (value / max_v))
            x = self.width() - label_w - 12 - bw
            p.setPen(Qt.NoPen)
            p.setBrush(self._bar_color)
            p.drawRoundedRect(x, y + 4, max(bw, 2), self._hpb - 16, 4, 4)
            # القيمة يسارًا
            p.setPen(QColor("#5A6B85"))
            p.drawText(QRect(4, y, val_w, self._hpb - 8),
                       Qt.AlignLeft | Qt.AlignVCenter, f"{value:,.0f}")
            y += self._hpb
            if y > self.height():
                break
        _ = fm


class QHLine(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.HLine)
        self.setStyleSheet("color: #D5DCE8;")


def labeled_row(label: str, widget: QWidget) -> QHBoxLayout:
    box = QHBoxLayout()
    lbl = QLabel(label)
    lbl.setMinimumWidth(150)
    lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    box.addWidget(widget, 1)
    box.addWidget(lbl, 0)
    return box
