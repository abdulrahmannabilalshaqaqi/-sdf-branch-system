# -*- coding: utf-8 -*-
"""التحقق من صحة الإدخال: التواريخ والأرقام والمبالغ — بتحمل لصيغ Excel الفوضوية."""
import re
from datetime import date, datetime
from decimal import Decimal
from typing import Optional, Tuple

from .finance import to_decimal

_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")

_AR_MONTHS = {
    "يناير": 1, "فبراير": 2, "مارس": 3, "أبريل": 4, "ابريل": 4, "مايو": 5,
    "يونيو": 6, "يوليو": 7, "أغسطس": 8, "اغسطس": 8, "سبتمبر": 9,
    "أكتوبر": 10, "اكتوبر": 10, "نوفمبر": 11, "ديسمبر": 12,
}

_EMPTY_WORDS = {"", "لايوجد", "لا يوجد", "بدون", "-", "n/a", "na", "none", "null"}


def normalize_digits(text: str) -> str:
    return str(text).translate(_AR_DIGITS)


def parse_date(value) -> Tuple[Optional[str], str, str]:
    """
    تحليل تاريخ بصيغ متعددة.
    يعيد: (التاريخ بصيغة ISO أو None، الحالة، ملاحظة)
    الحالة: ok | empty | invalid
    القيم غير القابلة للتحويل (نطاقات، نصوص) تُعاد كـ invalid مع النص الأصلي للمراجعة اليدوية.
    """
    if value is None:
        return None, "empty", ""
    if isinstance(value, datetime):
        return value.date().isoformat(), "ok", ""
    if isinstance(value, date):
        return value.isoformat(), "ok", ""
    text = normalize_digits(str(value)).strip()
    if text.lower() in _EMPTY_WORDS:
        return None, "empty", ""
    # إزالة الوقت إن وُجد
    text = re.split(r"\s+", text)[0]
    # نطاقات مثل 19/8-18/9/2023 → غير صالحة كتاريخ مفرد
    if re.search(r"\d\s*-\s*\d", text) and text.count("/") >= 2:
        return None, "invalid", f"نطاق زمني وليس تاريخًا مفردًا: {value}"
    # أسماء الشهور العربية: 24ديسمبر2022
    m = re.match(r"^(\d{1,2})\s*([^\d\s]+)\s*(\d{2,4})$", text)
    if m:
        day, month_name, year = m.groups()
        month = _AR_MONTHS.get(month_name.strip())
        if month:
            try:
                return date(int(year), month, int(day)).isoformat(), "ok", ""
            except ValueError:
                return None, "invalid", f"تاريخ غير صحيح: {value}"
    formats = ["%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%Y.%m.%d", "%d.%m.%Y"]
    for fmt in formats:
        try:
            return datetime.strptime(text, fmt).date().isoformat(), "ok", ""
        except ValueError:
            continue
    return None, "invalid", f"تعذر تحويل التاريخ: {value}"


def parse_int(value) -> Tuple[Optional[int], str]:
    """يعيد (القيمة، الحالة: ok|empty|invalid)."""
    if value is None or isinstance(value, bool):
        return None, "empty"
    text = normalize_digits(str(value)).strip().replace(",", "").replace(" ", "")
    if text in ("", "-"):
        return None, "empty"
    try:
        return int(float(text)), "ok"
    except ValueError:
        return None, "invalid"


def parse_money(value) -> Tuple[Optional[Decimal], str]:
    d = to_decimal(value)
    if d is None:
        if value is None or str(value).strip() in ("", "-"):
            return None, "empty"
        return None, "invalid"
    return d, "ok"


def validate_file_record(rec: dict) -> list:
    """تحقق أساسي من سجل ملف قبل الحفظ. يعيد قائمة رسائل الخطأ (فارغة = سليم)."""
    errors = []
    if not rec.get("file_number"):
        errors.append("رقم الملف إلزامي.")
    for field, label in (("exec_start", "بداية التنفيذ"), ("exec_end", "نهاية التنفيذ")):
        if rec.get(field):
            iso, status, _ = parse_date(rec[field])
            if status == "invalid":
                errors.append(f"{label}: تاريخ غير صالح.")
    s, e = rec.get("exec_start"), rec.get("exec_end")
    if s and e:
        si, ss, _ = parse_date(s)
        ei, es, _ = parse_date(e)
        if ss == "ok" and es == "ok" and si > ei:
            errors.append("بداية التنفيذ بعد نهاية التنفيذ.")
    for field, label in (("contract_trainees", "عدد المتدربين في العقد"),
                         ("approved_trainees", "العدد المعتمد"),
                         ("nominees_count", "عدد المرشحين"),
                         ("attendance_trainees", "عدد الحاضرين"),
                         ("certificates_count", "عدد الشهادات")):
        v = rec.get(field)
        if v is not None and v != "" and (not isinstance(v, (int, float)) or v < 0):
            errors.append(f"{label}: يجب أن يكون عددًا غير سالب.")
    return errors
