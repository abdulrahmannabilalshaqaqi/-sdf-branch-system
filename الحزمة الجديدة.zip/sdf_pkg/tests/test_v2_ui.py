# -*- coding: utf-8 -*-
"""اختبارات دخان للواجهة (offscreen): بناء كل الصفحات الجديدة والمعدّلة وتحديثها."""
import pytest

from PySide6.QtWidgets import QApplication, QMessageBox

from sdf_app.ui.app import create_app
from sdf_app.ui.context import AppContext


@pytest.fixture(scope="module")
def qapp():
    app = create_app([])
    yield app


@pytest.fixture()
def ctx(tmp_path, qapp, monkeypatch):
    # نوافذ صامتة حتى لا يعلّق الاختبار
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "critical", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "ui.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    yield c
    c.db.close()


def _seed_file(ctx):
    from sdf_app.services.file_service import FileService
    fs = FileService(ctx.conn)
    return fs.create({"file_number": 901, "program_name": "برنامج واجهة",
                      "received_date": "2026-01-05", "exec_start": "2026-02-01",
                      "funding_amount": 75000, "approved_trainees": 12}, user_id=1)


def test_main_window_wires_all_pages(ctx, qapp):
    from sdf_app.main import _wire_pages
    from sdf_app.ui.main_window import MainWindow
    win = MainWindow(ctx)
    _wire_pages(win, ctx)
    for key in ("dashboard", "files", "review", "disburse", "entities",
                "contributions", "reports", "settings"):
        assert key in win.pages, key
    # عناصر القائمة الجانبية الجديدة ظاهرة للمدير
    labels = [b.text() for b in win.nav_group.buttons()]
    assert "الصرف" in labels and "الجهات المستفيدة" in labels and "المساهمات الشهرية" in labels
    win.close()


def test_dashboard_refresh_with_filter(ctx, qapp):
    _seed_file(ctx)
    from sdf_app.ui.dashboard_page import DashboardPage
    d = DashboardPage(ctx, on_navigate=lambda *a: None)
    d.refresh()
    assert "901" not in d.total_card.value_lbl.text()  # الإجمالي رقم فقط
    assert d.total_card.value_lbl.text().strip() == "1"
    # ترشيح بفرع غير موجود ← صفر
    d._apply_filter({"branch_id": 99999}, "فرع وهمي")
    assert d.total_card.value_lbl.text().strip() == "0"
    assert not d.btn_clear_filter.isHidden()
    d.clear_filter()
    assert d.total_card.value_lbl.text().strip() == "1"
    # بطاقة التمويل
    assert "75,000" in d.fin_cards["funding"].value_lbl.text()
    assert d.fin_cards["trainees"].value_lbl.text().strip() == "12"
    d.close()


def test_files_page_search_and_columns(ctx, qapp):
    _seed_file(ctx)
    from sdf_app.ui.files_page import FilesPage
    p = FilesPage(ctx)
    p.refresh()
    assert p.total == 1
    headers = [p.table.horizontalHeaderItem(i).text() for i in range(p.table.columnCount())]
    assert "رقم التسميح" in headers and "رقم الملف في الفرع" in headers
    assert not hasattr(p, "diff_only")  # أُزيل خيار الفروقات
    p.close()


def test_file_dialog_new_and_save(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx)
    # الحقول الإلزامية: الحفظ بدونها يُظهر تحذيرًا ولا يقبل
    dlg.save()
    # لا يزال مفتوحًا (لم يُقبل)
    assert dlg.result() == 0
    # تعبئة الإلزامي
    dlg.widgets["file_number"][0].setValue(902)
    for key in ("branch_id", "program_id", "beneficiary_id"):
        w, _ = dlg.widgets[key]
        assert w.count() >= 0  # القوائم المقيدة موجودة
    dlg.close()


def test_file_dialog_existing_with_tables(ctx, qapp):
    fid = _seed_file(ctx)
    ctx.conn.execute("INSERT INTO trainees_nomination (file_id, seq, full_name, beneficiary_id)"
                     " VALUES (?,?,?,?)", (fid, 1, "مرشح أ", None))
    ctx.conn.commit()
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx, file_id=fid)
    assert dlg.nom_table.rowCount() == 1
    dlg._att_carry_from_nomination()
    assert dlg.att_table.rowCount() == 1
    dlg.close()


def test_disbursement_page_flow(ctx, qapp):
    _seed_file(ctx)
    from sdf_app.ui.disbursement_page import DisbursementPage
    p = DisbursementPage(ctx)
    p.search_box.setText("901")
    p._add_by_search()
    assert p.items and p.table.rowCount() == 1
    p.close()


def test_entities_page_crud(ctx, qapp):
    from sdf_app.ui.entities_page import EntitiesPage
    p = EntitiesPage(ctx)
    p.refresh()
    n0 = p.table.rowCount()
    ctx.conn.execute("INSERT INTO entities (name, kind, tax_number, employee_count)"
                     " VALUES (?,?,?,?)", ("جهة اختبار", "beneficiary", "999", 25))
    ctx.conn.commit()
    p.refresh()
    assert p.table.rowCount() == n0 + 1
    p.close()


def test_contributions_page(ctx, qapp):
    from sdf_app.ui.contributions_page import ContributionsPage
    ctx.conn.execute("INSERT INTO entities (name, kind) VALUES (?,?)", ("جهة مساهمات", "beneficiary"))
    ctx.conn.commit()
    p = ContributionsPage(ctx)
    p.refresh()
    assert p.table.rowCount() == 0  # بلا جهة مختارة
    p.entity_cb.setCurrentIndex(0)
    p.refresh()
    assert p.table.rowCount() == 12
    assert "50%" in p.rates_lbl.text()
    p.close()


def test_settings_pages_build(ctx, qapp):
    from sdf_app.ui.settings_page import SettingsPage
    s = SettingsPage(ctx)
    names = [s.tabs.tabText(i) for i in range(s.tabs.count())]
    assert "المدربون" in names and "الصلاحيات" in names and "البرامج التدريبية" in [
        s.lookup_cb.itemText(i) for i in range(s.lookup_cb.count())]
    s.close()


def test_review_page_build(ctx, qapp):
    fid = _seed_file(ctx)
    from sdf_app.ui.review_page import ReviewPage
    r = ReviewPage(ctx)
    r.open_file(fid)
    assert r.check_table.rowCount() >= 10  # كل البنود ظاهرة
    assert "901" in r.file_title.text()
    r.close()
