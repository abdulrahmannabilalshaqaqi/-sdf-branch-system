# -*- coding: utf-8 -*-
"""سياق التطبيق: قاعدة البيانات، الخدمات، والمستخدم الحالي."""
from ..database.connection import get_database
from ..database.seeds import seed_all
from ..services.file_service import FileService


class AppContext:
    def __init__(self, db_path=None):
        self.db = get_database(db_path)
        self.conn = self.db.connect()
        seed_all(self.conn)
        self.files = FileService(self.conn)
        self.user = None  # قاموس المستخدم بعد تسجيل الدخول

    def settings(self) -> dict:
        return {r["key"]: r["value"]
                for r in self.conn.execute("SELECT key, value FROM settings")}

    def set_setting(self, key: str, value: str):
        self.conn.execute("INSERT INTO settings (key, value) VALUES (?,?) "
                          "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                          (key, value))
        self.conn.commit()
