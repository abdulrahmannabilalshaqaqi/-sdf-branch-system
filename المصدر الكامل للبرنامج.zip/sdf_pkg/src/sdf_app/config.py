# -*- coding: utf-8 -*-
"""الإعدادات العامة ومسارات مجلد البيانات (مستقل عن مجلد البرنامج)."""
import os
import sys
from pathlib import Path

VERSION = "1.0.0"
APP_NAME_AR = "نظام إدارة ومراجعة ملفات البرامج التدريبية"
ORG_NAME_AR = "صندوق تنمية المهارات — مكتب النائب لشؤون الفروع"
CURRENCY_AR = "ر.ي"  # ريال يمني


def is_frozen() -> bool:
    return getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS")


def resource_path(*parts: str) -> Path:
    """مسار ملف مرفق مع البرنامج (خطوط، schema.sql...).

    يعمل في وضع التطوير ووضع PyInstaller المجمد، حيث تُنسخ الموارد
    إلى <_MEIPASS>/sdf_app/... بنفس بنية الحزمة.
    """
    if is_frozen():
        return Path(sys._MEIPASS, "sdf_app", *parts)
    return Path(__file__).resolve().parent.joinpath(*parts)


def data_dir() -> Path:
    """مجلد البيانات المستقل (لا يُمس عند تحديث/إلغاء تثبيت البرنامج)."""
    env = os.environ.get("SDF_DATA_DIR")
    if env:
        return Path(env)
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
        return base / "SDFBranchSystem"
    return Path.home() / ".sdf_branch_system"


def db_path() -> Path:
    return data_dir() / "sdf.db"


def attachments_dir() -> Path:
    return data_dir() / "attachments"


def backups_dir() -> Path:
    return data_dir() / "backups"


def exports_dir() -> Path:
    return data_dir() / "exports"


def ensure_data_dirs() -> Path:
    base = data_dir()
    for p in (base, attachments_dir(), backups_dir(), exports_dir()):
        p.mkdir(parents=True, exist_ok=True)
    return base
