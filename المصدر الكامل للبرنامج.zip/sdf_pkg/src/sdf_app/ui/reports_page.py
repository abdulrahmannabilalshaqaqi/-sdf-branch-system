# -*- coding: utf-8 -*-
"""صفحة التقارير والطباعة."""
from datetime import date
from pathlib import Path

from PySide6.QtCore import QDate
from PySide6.QtWidgets import (QDateEdit, QFileDialog, QGridLayout, QGroupBox,
                               QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QVBoxLayout, QWidget)

from .. import config
from ..reports import excel_reports as er
from ..reports.review_form import build_review_form
from .print_preview import PrintPreviewDialog


class ReportsPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        layout = QVBoxLayout(self)

        # -- استمارة المراجعة ------------------------------------------------------
        g0 = QGroupBox("استمارة مراجعة ملف برنامج تدريبي والمصادقة على التمويل")
        l0 = QHBoxLayout(g0)
        self.form_number = QLineEdit()
        self.form_number.setPlaceholderText("رقم الملف")
        btn_preview = QPushButton("معاينة قبل الطباعة")
        btn_preview.setProperty("primary", True)
        btn_preview.clicked.connect(self._preview_form)
        btn_pdf = QPushButton("حفظ PDF مباشرة")
        btn_pdf.clicked.connect(self._save_form_pdf)
        l0.addWidget(QLabel("رقم الملف:"))
        l0.addWidget(self.form_number)
        l0.addWidget(btn_preview)
        l0.addWidget(btn_pdf)
        l0.addStretch(1)
        layout.addWidget(g0)

        # -- التقارير ---------------------------------------------------------------
        g = QGroupBox("التقارير")
        grid = QGridLayout(g)
        grid.setSpacing(10)

        # فترة للتقارير الزمنية
        self.date_from = QDateEdit(QDate.currentDate().addMonths(-1))
        self.date_from.setCalendarPopup(True)
        self.date_to = QDateEdit(QDate.currentDate())
        self.date_to.setCalendarPopup(True)
        grid.addWidget(QLabel("من:"), 0, 4)
        grid.addWidget(self.date_from, 0, 3)
        grid.addWidget(QLabel("إلى:"), 0, 2)
        grid.addWidget(self.date_to, 0, 1)

        reports = [
            ("الملفات المستلمة خلال فترة", self._r_period),
            ("الملفات المكتملة والناقصة", self._r_complete),
            ("الملفات حسب الفرع", self._r_branch),
            ("البرامج حسب الجهة المستفيدة", self._r_beneficiary),
            ("البرامج حسب مجال التدريب", self._r_field),
            ("المطالبات والمبالغ المعتمدة والفروقات", self._r_financial),
            ("الملفات المتأخرة", self._r_overdue),
        ]
        for i, (title, fn) in enumerate(reports):
            btn = QPushButton(title)
            btn.clicked.connect(lambda _=False, f=fn, t=title: self._run_excel(f, t))
            grid.addWidget(btn, 1 + i // 2, (i % 2) * 2, 1, 2)
        layout.addWidget(g)

        # -- كشف ملف واحد / حركته -------------------------------------------------------
        g2 = QGroupBox("كشوفات ملف واحد")
        l2 = QHBoxLayout(g2)
        self.one_number = QLineEdit()
        self.one_number.setPlaceholderText("رقم الملف")
        btn_detail = QPushButton("كشف تفصيلي Excel")
        btn_detail.clicked.connect(self._r_detail)
        btn_hist = QPushButton("تقرير حركة الملف")
        btn_hist.clicked.connect(self._r_history)
        l2.addWidget(QLabel("رقم الملف:"))
        l2.addWidget(self.one_number)
        l2.addWidget(btn_detail)
        l2.addWidget(btn_hist)
        l2.addStretch(1)
        layout.addWidget(g2)
        layout.addStretch(1)

    # -- استمارة المراجعة --------------------------------------------------------------
    def _get_form_record(self):
        try:
            num = int(self.form_number.text().strip())
        except ValueError:
            QMessageBox.warning(self, "تنبيه", "أدخل رقم ملف صحيحًا.")
            return None
        rec = self.ctx.files.get_by_number(num)
        if not rec:
            QMessageBox.warning(self, "تنبيه", f"لا يوجد ملف بالرقم {num}.")
            return None
        return rec

    def _build_form_pdf(self, rec):
        items = [{"document_name": it["document_name"], "result": it["result"], "notes": it["notes"]}
                 for it in self.ctx.files.review_items(rec["id"])]
        # تنبيه المسودة: بيانات ناقصة أو مراجعة غير مكتملة
        from ..core.review_logic import review_summary
        s = review_summary([{"result": it["result"]} for it in items]) if items else {"is_technically_complete": False}
        draft = not s.get("is_technically_complete", False)
        out = config.exports_dir() / f"استمارة_مراجعة_{rec['file_number']}.pdf"
        build_review_form(rec, items, out, settings=self.ctx.settings(), draft=draft)
        return out, draft

    def _preview_form(self):
        rec = self._get_form_record()
        if not rec:
            return
        try:
            pdf, draft = self._build_form_pdf(rec)
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل إنشاء الاستمارة: {exc}")
            return
        dlg = PrintPreviewDialog(pdf, self)
        if draft:
            dlg.set_warning("تنبيه: بيانات الملف أو مراجعته غير مكتملة — تُطبع كمسودة مراجعة.")
        dlg.exec()

    def _save_form_pdf(self):
        rec = self._get_form_record()
        if not rec:
            return
        dest, _ = QFileDialog.getSaveFileName(self, "حفظ الاستمارة PDF",
                                              f"استمارة_مراجعة_{rec['file_number']}.pdf", "PDF (*.pdf)")
        if not dest:
            return
        try:
            pdf, _ = self._build_form_pdf(rec)
            import shutil
            shutil.copy2(pdf, dest)
            QMessageBox.information(self, "تم", "تم حفظ الاستمارة PDF.")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل إنشاء الاستمارة: {exc}")

    def open_form_for_file(self, file_id: int):
        rec = self.ctx.files.get(file_id)
        if rec:
            self.form_number.setText(str(rec["file_number"]))
            self._preview_form()

    # -- تقارير Excel ----------------------------------------------------------------------
    def _ask_path(self, title, default):
        path, _ = QFileDialog.getSaveFileName(self, title, default, "Excel (*.xlsx)")
        return Path(path) if path else None

    def _run_excel(self, fn, title):
        path = self._ask_path(title, f"{title}.xlsx")
        if not path:
            return
        try:
            fn(path)
            QMessageBox.information(self, "تم", f"تم إنشاء التقرير:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل إنشاء التقرير: {exc}")

    def _r_period(self, path):
        er.report_by_period(self.ctx.conn, path,
                            self.date_from.date().toString("yyyy-MM-dd"),
                            self.date_to.date().toString("yyyy-MM-dd"))

    def _r_complete(self, path):
        er.report_complete_vs_missing(self.ctx.conn, path)

    def _r_branch(self, path):
        er.report_by_branch(self.ctx.conn, path)

    def _r_beneficiary(self, path):
        er.report_by_beneficiary(self.ctx.conn, path)

    def _r_field(self, path):
        er.report_by_field(self.ctx.conn, path)

    def _r_financial(self, path):
        er.report_financial(self.ctx.conn, path)

    def _r_overdue(self, path):
        er.report_overdue(self.ctx.conn, path,
                          int(self.ctx.settings().get("review_deadline_days", 30)))

    def _file_num_or_warn(self):
        try:
            return int(self.one_number.text().strip())
        except ValueError:
            QMessageBox.warning(self, "تنبيه", "أدخل رقم ملف صحيحًا.")
            return None

    def _r_detail(self):
        num = self._file_num_or_warn()
        if not num:
            return
        rec = self.ctx.files.get_by_number(num)
        if not rec:
            QMessageBox.warning(self, "تنبيه", f"لا يوجد ملف بالرقم {num}.")
            return
        path = self._ask_path("كشف تفصيلي", f"كشف_ملف_{num}.xlsx")
        if not path:
            return
        from ..services.export_service import export_files
        export_files([rec], path, title=f"الكشف التفصيلي للملف رقم {num}")
        QMessageBox.information(self, "تم", "تم إنشاء الكشف التفصيلي.")

    def _r_history(self):
        num = self._file_num_or_warn()
        if not num:
            return
        rec = self.ctx.files.get_by_number(num)
        if not rec:
            QMessageBox.warning(self, "تنبيه", f"لا يوجد ملف بالرقم {num}.")
            return
        path = self._ask_path("تقرير حركة الملف", f"حركة_ملف_{num}.xlsx")
        if not path:
            return
        er.report_file_history(self.ctx.conn, path, rec["id"])
        QMessageBox.information(self, "تم", "تم إنشاء تقرير الحركة.")

    def refresh(self):
        pass
