# -*- coding: utf-8 -*-
"""اختبارات سير عمل الملف وشروط الاعتماد."""
from sdf_app.core.workflow import (
    approval_blockers,
    can_transition,
    next_statuses,
)


def test_valid_transitions():
    assert can_transition("new", "received")
    assert can_transition("tech_review", "tech_done")
    assert can_transition("ready_approve", "approved")


def test_invalid_transitions_blocked():
    assert not can_transition("new", "approved")       # قفز غير منطقي
    assert not can_transition("approved", "tech_review")  # رجوع من نهائية
    assert not can_transition("archived", "new")
    assert not can_transition("new", "new")


def test_next_statuses_lists_options():
    nxt = next_statuses("tech_review")
    assert "tech_done" in nxt and "missing_docs" in nxt


def test_approval_blockers_complete_file():
    rec = {"approved_trainees": 10, "approved_cost_per_trainee": 50000,
           "approved_hours": 20, "funding_amount": 500000}
    items = [{"document_name": "العقد", "result": "مطابق", "required_default": 1},
             {"document_name": "الترخيص", "result": "غير منطبق", "required_default": 0}]
    assert approval_blockers(rec, items) == []


def test_approval_blockers_missing_financial():
    rec = {"approved_trainees": 10}
    assert len(approval_blockers(rec, [])) >= 3


def test_approval_blockers_bad_document():
    rec = {"approved_trainees": 10, "approved_cost_per_trainee": 50000,
           "approved_hours": 20, "funding_amount": 500000}
    items = [{"document_name": "الشهادات", "result": "غير مكتمل", "required_default": 1}]
    blockers = approval_blockers(rec, items)
    assert any("الشهادات" in b for b in blockers)
