# -*- coding: utf-8 -*-
"""اختبارات الاستيراد: المعاينة، التحقق، كشف التكرار، والمعاملة الآمنة."""
import sqlite3
import tempfile
from pathlib import Path

import pytest
from openpyxl import Workbook

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services import import_service as imp


@pytest.fixture()
def conn():
    tmp = Path(tempfile.mkdtemp()) / "test.db"
    database = Database(tmp)
    c = database.connect()
    seed_all(c)
    yield c
    database.close()


@pytest.fixture()
def sample_xlsx(tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "البيانات"
    ws.append(["رقم الملف", "تاريخ أستلام الملف", "الفرع", "أسم البرنامج",
               "عدد المتدربين في العقد", "تكلفة الفرد حسب العقد", "تاريخ العقد",
               "التكلفة الاجمالية حسب العقد"])  # عمود محسوب يجب تجاهله
    ws.append([101, "2023-10-08", "الحديدة", "برنامج أ", 10, 50000, "2023-01-05", 500000])
    ws.append([102, "2023-10-09", "تعز", "برنامج ب", 5, 60000, "2022/25", 300000])  # تاريخ فاسد
    ws.append([101, "2023-10-10", "الحديدة", "برنامج مكرر", 3, 10000, "2023-02-01", 30000])  # مكرر داخل الملف
    ws.append([None, None, None, None, None, None, None, None])  # صف فارغ
    ws.append([103, "2023-11-01", "عدن", "برنامج ج", 7, 70000, "2023-03-01", 490000])
    p = tmp_path / "sample.xlsx"
    wb.save(p)
    return p


def test_preview_and_auto_mapping(sample_xlsx):
    assert imp.list_sheets(sample_xlsx) == ["البيانات"]
    prev = imp.preview_sheet(sample_xlsx, "البيانات")
    assert prev["total_rows"] == 5
    mapping = imp.auto_map_columns(prev["headers"])
    assert mapping[0] == "file_number"
    assert mapping[2] == "branch"
    # عمود المعادلة المحسوبة لا يُطابق
    assert 7 not in mapping


def test_analyze_detects_errors_and_duplicates(sample_xlsx, conn):
    prev = imp.preview_sheet(sample_xlsx, "البيانات")
    mapping = imp.auto_map_columns(prev["headers"])
    results = imp.analyze_rows(sample_xlsx, "البيانات", mapping, conn)
    by_row = {r.excel_row: r for r in results}
    assert by_row[2].status == "ok"
    # التاريخ الفاسد: يُستورد الصف مع تحذير موثق بدل فقدانه
    assert by_row[3].status == "ok" and by_row[3].warnings
    assert by_row[3].record.get("contract_date") is None
    assert by_row[4].status == "duplicate_file"
    assert by_row[5].status == "empty"
    assert by_row[6].status == "ok"
    summary = imp.summarize_analysis(results)
    assert summary["ok"] == 3 and summary["with_warnings"] == 1
    assert summary["duplicate_file"] == 1 and summary["empty"] == 1


def test_execute_import_transactional(sample_xlsx, conn, tmp_path):
    prev = imp.preview_sheet(sample_xlsx, "البيانات")
    mapping = imp.auto_map_columns(prev["headers"])
    results = imp.analyze_rows(sample_xlsx, "البيانات", mapping, conn)
    report = imp.execute_import(conn, results, duplicate_policy="skip",
                                source_file=str(sample_xlsx), sheet_name="البيانات")
    assert report["imported"] == 3
    assert report["errored"] == 1  # المكرر داخل الملف فقط
    assert report["skipped"] == 1
    assert any("تحذير" in line for line in report["report"])
    n = conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"]
    assert n == 3
    # التكرار ضد قاعدة البيانات يُكتشف في التحليل الثاني
    results2 = imp.analyze_rows(sample_xlsx, "البيانات", mapping, conn)
    by_row = {r.excel_row: r for r in results2}
    assert by_row[2].status == "duplicate_db"
    report2 = imp.execute_import(conn, results2, duplicate_policy="skip")
    assert report2["imported"] == 0 and report2["skipped"] >= 2
    # دفعة الاستيراد موثقة
    batches = conn.execute("SELECT COUNT(*) c FROM import_batches").fetchone()["c"]
    assert batches == 2


def test_update_policy(conn, tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.append(["رقم الملف", "أسم البرنامج"])
    ws.append([201, "قديم"])
    p = tmp_path / "u1.xlsx"
    wb.save(p)
    mapping = imp.auto_map_columns(["رقم الملف", "أسم البرنامج"])
    res = imp.analyze_rows(p, "Sheet", mapping, conn)
    imp.execute_import(conn, res)
    wb2 = Workbook()
    ws2 = wb2.active
    ws2.append(["رقم الملف", "أسم البرنامج"])
    ws2.append([201, "محدّث"])
    p2 = tmp_path / "u2.xlsx"
    wb2.save(p2)
    res2 = imp.analyze_rows(p2, "Sheet", mapping, conn)
    assert res2[0].status == "duplicate_db"
    rep = imp.execute_import(conn, res2, duplicate_policy="update")
    assert rep["updated"] == 1
    name = conn.execute("SELECT program_name FROM training_files WHERE file_number=201").fetchone()[0]
    assert name == "محدّث"
