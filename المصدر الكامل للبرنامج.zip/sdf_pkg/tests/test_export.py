# -*- coding: utf-8 -*-
"""اختبارات التصدير: ملف xlsx حقيقي منسق RTL بالعربية."""
from openpyxl import load_workbook

from sdf_app.services.export_service import enrich_row, export_files


def _rows():
    return [
        enrich_row({
            "file_number": 633, "branch_file_number": "0042", "received_date": "2023-10-08",
            "branch_name": "الحديدة", "program_name": "النظم النيوماتيكية",
            "program_field": "فني", "beneficiary_name": "شركة السنابل",
            "implementing_name": "معهد التدريب", "contract_trainees": 2,
            "contract_cost_per_trainee": 70000, "contract_hours": 22,
            "approved_trainees": 2, "approved_cost_per_trainee": 70000,
            "approved_hours": 22, "claimed_amount": 120000, "funding_amount": 140000,
            "status_name": "مكتمل فنيًا",
        }),
        enrich_row({
            "file_number": 634, "branch_file_number": "0043", "received_date": "2023-10-09",
            "branch_name": "تعز", "program_name": "إلكترونيات",
            "contract_trainees": 5, "contract_cost_per_trainee": 60000,
            "contract_hours": 20, "status_name": "ملف جديد",
        }),
    ]


def test_export_creates_real_workbook(tmp_path):
    out = tmp_path / "export.xlsx"
    export_files(_rows(), out, title="كشف تجريبي", filters_desc="الفرع=الحديدة")
    wb = load_workbook(out)
    ws = wb["البيانات"]
    assert ws.sheet_view.rightToLeft is True
    assert ws["A1"].value == "كشف تجريبي"
    assert ws["A2"].value == "رقم الملف"  # عنوان عربي
    assert ws.freeze_panes == "A3"
    assert ws.auto_filter.ref is not None
    # القيم
    assert ws.cell(row=3, column=1).value == 633
    assert ws.cell(row=3, column=2).value == "0042"  # نص يحفظ الصفر البادئ
    # عمود محسوب: إجمالي العقد = 2*70000
    headers = [c.value for c in ws[2]]
    idx_total = headers.index("التكلفة الإجمالية حسب العقد (محسوبة)") + 1
    assert ws.cell(row=3, column=idx_total).value == 140000
    # ورقة معلومات التصدير
    meta = wb["معلومات التصدير"]
    assert meta["B2"].value is not None  # تاريخ التصدير
    assert "الحديدة" in str(meta["B4"].value)
    wb.close()
