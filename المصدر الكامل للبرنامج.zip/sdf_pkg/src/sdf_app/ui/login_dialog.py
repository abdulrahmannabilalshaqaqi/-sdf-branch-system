# -*- coding: utf-8 -*-
"""نافذة تسجيل الدخول."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFormLayout, QLabel,
                               QLineEdit, QMessageBox, QVBoxLayout)

from .. import config
from ..services.auth_service import authenticate


class LoginDialog(QDialog):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.setWindowTitle("تسجيل الدخول")
        self.setModal(True)
        self.setMinimumWidth(360)
        layout = QVBoxLayout(self)

        title = QLabel(config.APP_NAME_AR)
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #1F3A5F;")
        layout.addWidget(title)
        sub = QLabel(config.ORG_NAME_AR)
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet("color: #5A6B85;")
        layout.addWidget(sub)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        self.username = QLineEdit()
        self.username.setPlaceholderText("اسم المستخدم")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setPlaceholderText("كلمة المرور")
        form.addRow("اسم المستخدم:", self.username)
        form.addRow("كلمة المرور:", self.password)
        layout.addLayout(form)

        hint = QLabel("الدخول الأول: admin / admin123 (غيّرها فورًا من الإعدادات)")
        hint.setStyleSheet("color: #8A97AD; font-size: 11px;")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("دخول")
        buttons.button(QDialogButtonBox.Ok).setProperty("primary", True)
        buttons.button(QDialogButtonBox.Cancel).setText("إلغاء")
        buttons.accepted.connect(self.try_login)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.password.returnPressed.connect(self.try_login)

    def try_login(self):
        user = authenticate(self.ctx.conn, self.username.text(), self.password.text())
        if user:
            self.ctx.user = user
            self.accept()
        else:
            QMessageBox.warning(self, "تعذر الدخول",
                                "اسم المستخدم أو كلمة المرور غير صحيحة.")
