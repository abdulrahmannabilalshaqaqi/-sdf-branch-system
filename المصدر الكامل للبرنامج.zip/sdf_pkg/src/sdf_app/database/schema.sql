-- =====================================================================
-- مخطط قاعدة بيانات نظام إدارة ومراجعة ملفات البرامج التدريبية
-- SQLite — الإصدار 1
-- =====================================================================

CREATE TABLE IF NOT EXISTS schema_migrations (
    version    INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------------------------------------------------------------------
-- الجداول المرجعية (قوائم)
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS branches (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    name   TEXT NOT NULL UNIQUE,
    active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS program_fields (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    name   TEXT NOT NULL UNIQUE,
    active INTEGER NOT NULL DEFAULT 1
);

-- الجهات (مستفيدة / منفذة) مع دعم الدمج والأسماء البديلة لمنع التكرار
CREATE TABLE IF NOT EXISTS entities (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT NOT NULL,
    kind           TEXT NOT NULL CHECK (kind IN ('beneficiary', 'implementing')),
    active         INTEGER NOT NULL DEFAULT 1,
    merged_into_id INTEGER REFERENCES entities(id),
    notes          TEXT,
    UNIQUE (name, kind)
);

CREATE TABLE IF NOT EXISTS entity_aliases (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_id INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    alias     TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS trainers (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT NOT NULL UNIQUE,
    qualification  TEXT,
    experience     TEXT,
    license_issuer TEXT,
    license_start  TEXT,
    license_end    TEXT,
    notes          TEXT
);

CREATE TABLE IF NOT EXISTS document_types (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT NOT NULL UNIQUE,
    required_default INTEGER NOT NULL DEFAULT 1,
    sort_order       INTEGER NOT NULL DEFAULT 0,
    active           INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS file_statuses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    code        TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    is_terminal INTEGER NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS status_transitions (
    from_status_id INTEGER NOT NULL REFERENCES file_statuses(id),
    to_status_id   INTEGER NOT NULL REFERENCES file_statuses(id),
    PRIMARY KEY (from_status_id, to_status_id)
);

-- ---------------------------------------------------------------------
-- الجدول الرئيسي: ملفات البرامج التدريبية
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS training_files (
    id                              INTEGER PRIMARY KEY AUTOINCREMENT,
    file_number                     INTEGER NOT NULL UNIQUE,      -- A: رقم الملف
    branch_file_number              TEXT,                         -- D
    received_date                   TEXT,                         -- B
    branch_id                       INTEGER REFERENCES branches(id),        -- C
    program_name                    TEXT,                         -- E
    field_id                        INTEGER REFERENCES program_fields(id),  -- K
    beneficiary_id                  INTEGER REFERENCES entities(id),        -- F
    implementing_id                 INTEGER REFERENCES entities(id),        -- L
    exec_start                      TEXT,                         -- G
    exec_end                        TEXT,                         -- H
    trainer_id                      INTEGER REFERENCES trainers(id),        -- I
    trainer_qualification           TEXT,                         -- AK
    trainer_experience              TEXT,                         -- AL
    docs_status                     TEXT,                         -- J (أرشيفية من الملف الأصلي)
    contract_date                   TEXT,                         -- M
    contract_number                 TEXT,                         -- رقم العقد (من استمارة ورقة1)
    contract_trainees               INTEGER,                      -- N
    contract_hours                  REAL,                         -- O
    contract_cost_per_trainee       REAL,                         -- P
    claimed_amount                  REAL,                         -- S
    branch_approved_amount          REAL,                         -- T
    supervisor_name                 TEXT,                         -- U
    approved_trainees               INTEGER,                      -- V
    approved_trainees_override_reason TEXT,                       -- سبب تعديل العدد المقترح
    suggested_trainees              INTEGER,                      -- العدد المقترح آليًا
    approved_hours                  REAL,                         -- W
    approved_cost_per_trainee       REAL,                         -- Y
    funding_amount                  REAL,                         -- AA
    notes                           TEXT,                         -- AC
    contract_exec_date              TEXT,                         -- AD
    nominees_count                  INTEGER,                      -- AE
    nomination_date                 TEXT,                         -- AF
    attendance_exec_date            TEXT,                         -- AG
    attendance_trainees             INTEGER,                      -- AH
    program_duration                TEXT,                         -- AI
    supervision_level               TEXT,                         -- AJ
    license_issuer                  TEXT,                         -- AM
    license_start                   TEXT,                         -- AN
    license_end                     TEXT,                         -- AO
    implementing_field              TEXT,                         -- AP
    cert_program_name               TEXT,                         -- AQ
    cert_exec_start                 TEXT,                         -- AR
    cert_exec_end                   TEXT,                         -- AS
    certificates_count              INTEGER,                      -- AT
    material_match                  TEXT,                         -- AU
    claim_date                      TEXT,                         -- AV
    status_id                       INTEGER REFERENCES file_statuses(id),
    reviewer_id                     INTEGER REFERENCES users(id),
    legacy_row                      INTEGER,                      -- رقم الصف في ملف Excel الأصلي
    created_at                      TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at                      TEXT NOT NULL DEFAULT (datetime('now')),
    created_by                      INTEGER REFERENCES users(id),
    updated_by                      INTEGER REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_files_number   ON training_files(file_number);
CREATE INDEX IF NOT EXISTS idx_files_branch   ON training_files(branch_id);
CREATE INDEX IF NOT EXISTS idx_files_status   ON training_files(status_id);
CREATE INDEX IF NOT EXISTS idx_files_received ON training_files(received_date);
CREATE INDEX IF NOT EXISTS idx_files_benef    ON training_files(beneficiary_id);
CREATE INDEX IF NOT EXISTS idx_files_impl     ON training_files(implementing_id);

-- ---------------------------------------------------------------------
-- المراجعة الفنية: قائمة التحقق من الوثائق
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS review_items (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id          INTEGER NOT NULL REFERENCES training_files(id) ON DELETE CASCADE,
    document_type_id INTEGER NOT NULL REFERENCES document_types(id),
    result           TEXT NOT NULL DEFAULT 'لم يراجع'
                     CHECK (result IN ('مطابق','غير مطابق','غير مكتمل','غير منطبق','لم يراجع')),
    notes            TEXT,
    reviewed_by      INTEGER REFERENCES users(id),
    reviewed_at      TEXT,
    UNIQUE (file_id, document_type_id)
);
CREATE INDEX IF NOT EXISTS idx_review_file ON review_items(file_id);

-- ---------------------------------------------------------------------
-- سجل حركة الملف (تغيير الحالات)
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS file_history (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id        INTEGER NOT NULL REFERENCES training_files(id) ON DELETE CASCADE,
    changed_at     TEXT NOT NULL DEFAULT (datetime('now')),
    changed_by     INTEGER REFERENCES users(id),
    from_status_id INTEGER REFERENCES file_statuses(id),
    to_status_id   INTEGER REFERENCES file_statuses(id),
    notes          TEXT
);
CREATE INDEX IF NOT EXISTS idx_history_file ON file_history(file_id);

-- ---------------------------------------------------------------------
-- المرفقات (تُخزن الملفات في مجلد البيانات، وبياناتها هنا)
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS attachments (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id          INTEGER NOT NULL REFERENCES training_files(id) ON DELETE CASCADE,
    document_type_id INTEGER REFERENCES document_types(id),
    original_name    TEXT NOT NULL,
    stored_name      TEXT NOT NULL,
    size_bytes       INTEGER NOT NULL DEFAULT 0,
    mime_type        TEXT,
    added_by         INTEGER REFERENCES users(id),
    added_at         TEXT NOT NULL DEFAULT (datetime('now')),
    notes            TEXT
);
CREATE INDEX IF NOT EXISTS idx_attach_file ON attachments(file_id);

-- ---------------------------------------------------------------------
-- كشوف الأسماء للمطابقة (الترشيحات / الحضور)
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS trainees_nomination (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id   INTEGER NOT NULL REFERENCES training_files(id) ON DELETE CASCADE,
    seq       INTEGER NOT NULL,
    full_name TEXT NOT NULL,
    notes     TEXT,
    UNIQUE (file_id, seq)
);

CREATE TABLE IF NOT EXISTS trainees_attendance (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id              INTEGER NOT NULL REFERENCES training_files(id) ON DELETE CASCADE,
    seq                  INTEGER NOT NULL,
    full_name            TEXT NOT NULL,
    matched_nomination_id INTEGER REFERENCES trainees_nomination(id),
    match_method         TEXT CHECK (match_method IN ('تلقائي','يدوي', NULL)),
    notes                TEXT,
    UNIQUE (file_id, seq)
);
CREATE INDEX IF NOT EXISTS idx_nom_file ON trainees_nomination(file_id);
CREATE INDEX IF NOT EXISTS idx_att_file ON trainees_attendance(file_id);

-- ---------------------------------------------------------------------
-- المستخدمون والصلاحيات
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    full_name     TEXT NOT NULL,
    password_hash TEXT NOT NULL,   -- PBKDF2-SHA256 (ملح:تجزئة)
    role          TEXT NOT NULL CHECK (role IN ('admin','data_entry','tech_reviewer','finance_reviewer','viewer')),
    active        INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    last_login    TEXT
);

-- ---------------------------------------------------------------------
-- سجل التدقيق
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at TEXT NOT NULL DEFAULT (datetime('now')),
    user_id    INTEGER REFERENCES users(id),
    username   TEXT,
    action     TEXT NOT NULL,      -- مثال: file.create / file.update / finance.update / status.change / import / backup.restore / user.role_change
    entity     TEXT,
    entity_id  INTEGER,
    details    TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity, entity_id);

-- ---------------------------------------------------------------------
-- دفعات الاستيراد وتقاريرها
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS import_batches (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at     TEXT NOT NULL DEFAULT (datetime('now')),
    finished_at    TEXT,
    user_id        INTEGER REFERENCES users(id),
    source_file    TEXT,
    sheet_name     TEXT,
    total_rows     INTEGER NOT NULL DEFAULT 0,
    imported_rows  INTEGER NOT NULL DEFAULT 0,
    updated_rows   INTEGER NOT NULL DEFAULT 0,
    skipped_rows   INTEGER NOT NULL DEFAULT 0,
    error_rows     INTEGER NOT NULL DEFAULT 0,
    status         TEXT NOT NULL DEFAULT 'جارٍ',
    report_text    TEXT
);

-- ---------------------------------------------------------------------
-- الإعدادات
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS settings (
    key         TEXT PRIMARY KEY,
    value       TEXT,
    description TEXT
);

-- ---------------------------------------------------------------------
-- سجل النسخ الاحتياطي
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS backup_history (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at           TEXT NOT NULL DEFAULT (datetime('now')),
    path                 TEXT NOT NULL,
    size_bytes           INTEGER NOT NULL DEFAULT 0,
    includes_attachments INTEGER NOT NULL DEFAULT 0,
    verified             INTEGER NOT NULL DEFAULT 0,
    notes                TEXT
);
