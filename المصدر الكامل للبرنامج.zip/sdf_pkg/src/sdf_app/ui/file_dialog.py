# -*- coding: utf-8 -*-
"""نموذج الملف التدريبي: تبويبات البيانات + المرفقات + الحالة والسجل."""
from datetime import date

from PySide6.QtCore import Qt, QDate
from PySide6.QtWidgets import (QComboBox, QDateEdit, QDialog, QDialogButtonBox,
                               QDoubleSpinBox, QFileDialog, QFormLayout,
                               QGroupBox, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QMessageBox, QPushButton, QSpinBox,
                               QTabWidget, QTextEdit, QVBoxLayout, QWidget,
                               QScrollArea)

from ..core import finance
from ..core.review_logic import suggest_approved_count
from ..core.workflow import STATUS_NAMES, can_transition, next_statuses
from ..services.auth_service import has_permission


def _money_spin():
    s = QDoubleSpinBox()
    s.setRange(0, 999999999)
    s.setDecimals(2)
    s.setGroupSeparatorShown(True)
    return s


class FileDialog(QDialog):
    def __init__(self, ctx, file_id=None, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.file_id = file_id
        self.record = ctx.files.get(file_id) if file_id else {}
        self.setWindowTitle("ملف جديد" if not file_id else f"ملف رقم {self.record.get('file_number')}")
        self.resize(900, 700)
        self.widgets = {}

        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)

        self.tabs.addTab(self._tab_general(), "البيانات العامة")
        self.tabs.addTab(self._tab_contract(), "بيانات العقد")
        self.tabs.addTab(self._tab_nomination(), "بيانات الترشيح")
        self.tabs.addTab(self._tab_attendance(), "الحضور والتنفيذ")
        self.tabs.addTab(self._tab_trainer(), "المدرب والجهة المنفذة")
        self.tabs.addTab(self._tab_certs(), "الشهادات والمادة العلمية")
        self.tabs.addTab(self._tab_finance(), "البيانات المالية")
        if file_id:
            self.tabs.addTab(self._tab_attachments(), "المرفقات")
            self.tabs.addTab(self._tab_status(), "الحالة والسجل")

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("حفظ")
        buttons.button(QDialogButtonBox.Save).setProperty("primary", True)
        buttons.button(QDialogButtonBox.Cancel).setText("إلغاء")
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        if file_id:
            self._load_record()

    # -- أدوات بناء الحقول ------------------------------------------------------
    def _field(self, key, label, kind="text", **kw):
        if kind == "text":
            w = QLineEdit()
        elif kind == "int":
            w = QSpinBox()
            w.setRange(0, 1000000)
        elif kind == "money":
            w = _money_spin()
        elif kind == "date":
            w = QDateEdit()
            w.setCalendarPopup(True)
            w.setDisplayFormat("yyyy-MM-dd")
            w.setMinimumDate(QDate(2000, 1, 1))
            w.setSpecialValueText("—")
            w.setDate(QDate(2000, 1, 1))
        elif kind == "combo":
            w = QComboBox()
            w.setEditable(True)
        elif kind == "notes":
            w = QTextEdit()
            w.setMaximumHeight(90)
        else:
            w = QLineEdit()
        self.widgets[key] = (w, kind)
        row = QHBoxLayout()
        lbl = QLabel(label)
        lbl.setMinimumWidth(170)
        row.addWidget(w, 1)
        row.addWidget(lbl, 0)
        return row

    def _lookup_combo(self, key, label, table, kind=None):
        row = self._field(key, label, kind="combo")
        w, _ = self.widgets[key]
        w.clear()
        if kind:
            rows = self.ctx.conn.execute(
                f"SELECT id, name FROM {table} WHERE kind=? AND active=1 ORDER BY name", (kind,))
        else:
            rows = self.ctx.conn.execute(f"SELECT id, name FROM {table} ORDER BY name")
        for r in rows:
            w.addItem(r["name"], r["id"])
        w.setCurrentIndex(-1)
        return row

    def _group(self, title, rows):
        g = QGroupBox(title)
        l = QVBoxLayout(g)
        for r in rows:
            l.addLayout(r)
        return g

    def _scroll(self, widget):
        s = QScrollArea()
        s.setWidgetResizable(True)
        s.setWidget(widget)
        s.setFrameShape(QScrollArea.NoFrame)
        return s

    # -- التبويبات ------------------------------------------------------------------
    def _tab_general(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات الملف", [
            self._field("file_number", "رقم الملف *", kind="int"),
            self._field("branch_file_number", "رقم الملف لدى الفرع"),
            self._field("received_date", "تاريخ استلام الملف", kind="date"),
            self._lookup_combo("branch_id", "الفرع", "branches"),
            self._field("program_name", "اسم البرنامج التدريبي"),
            self._lookup_combo("field_id", "مجال البرنامج", "program_fields"),
            self._lookup_combo("beneficiary_id", "الجهة المستفيدة", "entities", kind="beneficiary"),
            self._lookup_combo("implementing_id", "الجهة المنفذة", "entities", kind="implementing"),
            self._field("exec_start", "تاريخ بداية التنفيذ", kind="date"),
            self._field("exec_end", "تاريخ نهاية التنفيذ", kind="date"),
        ]))
        l.addStretch(1)
        return self._scroll(w)

    def _tab_contract(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات العقد", [
            self._field("contract_number", "رقم العقد"),
            self._field("contract_date", "تاريخ العقد", kind="date"),
            self._field("contract_trainees", "عدد المتدربين حسب العقد", kind="int"),
            self._field("contract_hours", "عدد الساعات حسب العقد", kind="money"),
            self._field("contract_cost_per_trainee", "تكلفة الفرد حسب العقد", kind="money"),
            self._field("contract_exec_date", "تاريخ التنفيذ المحدد في العقد", kind="date"),
        ]))
        self.contract_total_lbl = QLabel("—")
        self.contract_hour_lbl = QLabel("—")
        l.addWidget(self._group("محسوبة تلقائيًا", [
            self._info_row("التكلفة الإجمالية حسب العقد:", self.contract_total_lbl),
            self._info_row("تكلفة الساعة حسب العقد:", self.contract_hour_lbl),
        ]))
        for key in ("contract_trainees", "contract_hours", "contract_cost_per_trainee"):
            self.widgets[key][0].valueChanged.connect(self._recalc_contract)
        l.addStretch(1)
        return self._scroll(w)

    def _info_row(self, label, widget):
        row = QHBoxLayout()
        lbl = QLabel(label)
        lbl.setMinimumWidth(220)
        lbl.setStyleSheet("font-weight: bold; color: #1F3A5F;")
        row.addWidget(widget, 1)
        row.addWidget(lbl, 0)
        return row

    def _recalc_contract(self):
        n = self.widgets["contract_trainees"][0].value()
        c = self.widgets["contract_cost_per_trainee"][0].value()
        h = self.widgets["contract_hours"][0].value()
        self.contract_total_lbl.setText(finance.format_money(finance.contract_total(n, c) or 0))
        hc = finance.contract_hour_cost(c, h)
        self.contract_hour_lbl.setText(finance.format_money(hc) if hc else "— (الساعات صفر أو فارغة)")

    def _tab_nomination(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات الترشيح", [
            self._field("nominees_count", "عدد المرشحين", kind="int"),
            self._field("nomination_date", "تاريخ الترشيح", kind="date"),
        ]))
        l.addWidget(QLabel("إرفاق كشف المرشحين من تبويب المرفقات، والمطابقة من شاشة المراجعة الفنية."))
        l.addStretch(1)
        return self._scroll(w)

    def _tab_attendance(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات الحضور والتنفيذ", [
            self._field("attendance_exec_date", "تاريخ التنفيذ حسب كشوفات الحضور", kind="date"),
            self._field("attendance_trainees", "عدد المتدربين حسب كشف الحضور", kind="int"),
            self._field("program_duration", "مدة البرنامج"),
        ]))
        l.addWidget(self._group("تقرير الإشراف", [
            self._field("supervisor_name", "اسم المشرف"),
            self._field("supervision_level", "مستوى التنفيذ وفق تقرير الإشراف"),
        ]))
        l.addStretch(1)
        return self._scroll(w)

    def _tab_trainer(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات المدرب", [
            self._lookup_combo("trainer_id", "اسم المدرب", "trainers"),
            self._field("trainer_qualification", "المؤهل والتخصص"),
            self._field("trainer_experience", "الخبرة"),
        ]))
        l.addWidget(self._group("بيانات الترخيص", [
            self._field("license_issuer", "جهة إصدار الترخيص"),
            self._field("license_start", "بداية الترخيص", kind="date"),
            self._field("license_end", "نهاية الترخيص", kind="date"),
        ]))
        l.addWidget(self._group("الجهة المنفذة", [
            self._field("implementing_field", "مجال الجهة المنفذة"),
        ]))
        l.addStretch(1)
        return self._scroll(w)

    def _tab_certs(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات الشهادات والمادة العلمية", [
            self._field("cert_program_name", "اسم البرنامج في الشهادة"),
            self._field("cert_exec_start", "بداية التنفيذ في الشهادة", kind="date"),
            self._field("cert_exec_end", "نهاية التنفيذ في الشهادة", kind="date"),
            self._field("certificates_count", "عدد الشهادات المرفقة", kind="int"),
            self._field("material_match", "مدى مطابقة المادة العلمية"),
        ]))
        l.addStretch(1)
        return self._scroll(w)

    def _tab_finance(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("البيانات المالية", [
            self._field("claimed_amount", "المبلغ المطالب به من الجهة المنفذة", kind="money"),
            self._field("branch_approved_amount", "التكلفة المعتمدة من الفرع", kind="money"),
            self._field("approved_trainees", "العدد المعتمد للمتدربين", kind="int"),
            self._field("approved_hours", "عدد الساعات المعتمدة", kind="money"),
            self._field("approved_cost_per_trainee", "تكلفة المتدرب المعتمدة", kind="money"),
            self._field("funding_amount", "مبلغ التمويل", kind="money"),
            self._field("claim_date", "تاريخ المطالبة", kind="date"),
            self._field("notes", "ملاحظات المراجع", kind="notes"),
        ]))
        # اقتراح العدد المعتمد
        sug_row = QHBoxLayout()
        self.suggest_lbl = QLabel("—")
        btn_sug = QPushButton("اقتراح العدد المعتمد")
        btn_sug.clicked.connect(self._suggest_count)
        sug_row.addWidget(self.suggest_lbl, 1)
        sug_row.addWidget(btn_sug, 0)
        l.addLayout(sug_row)

        self.approved_total_lbl = QLabel("—")
        self.approved_hour_lbl = QLabel("—")
        self.diff1_lbl = QLabel("—")
        self.diff2_lbl = QLabel("—")
        l.addWidget(self._group("محسوبة تلقائيًا", [
            self._info_row("التكلفة الإجمالية المعتمدة:", self.approved_total_lbl),
            self._info_row("تكلفة الساعة المعتمدة:", self.approved_hour_lbl),
            self._info_row("الفارق: التمويل − المطالب به:", self.diff1_lbl),
            self._info_row("الفارق: المطالب به − المعتمد:", self.diff2_lbl),
        ]))
        for key in ("approved_trainees", "approved_hours", "approved_cost_per_trainee",
                    "claimed_amount", "funding_amount"):
            self.widgets[key][0].valueChanged.connect(self._recalc_finance)
        l.addStretch(1)
        return self._scroll(w)

    def _suggest_count(self):
        r = suggest_approved_count(
            contract=self.widgets["contract_trainees"][0].value(),
            nominees=self.widgets["nominees_count"][0].value(),
            attendance=self.widgets["attendance_trainees"][0].value(),
            certificates=self.widgets["certificates_count"][0].value(),
        )
        if r["value"] is None:
            self.suggest_lbl.setText("لا تتوفر بيانات كافية للاقتراح.")
            return
        msg = f"العدد المقترح: {r['value']} (أقل الأعداد المتوفرة)"
        if r["warnings"]:
            msg += "\n" + "\n".join(r["warnings"])
        self.suggest_lbl.setText(msg)
        if QMessageBox.question(self, "اعتماد الاقتراح",
                                msg + "\n\nهل تريد اعتماد هذا العدد؟") == QMessageBox.Yes:
            self.widgets["approved_trainees"][0].setValue(r["value"])

    def _recalc_finance(self):
        n = self.widgets["approved_trainees"][0].value()
        c = self.widgets["approved_cost_per_trainee"][0].value()
        h = self.widgets["approved_hours"][0].value()
        claimed = self.widgets["claimed_amount"][0].value()
        funding = self.widgets["funding_amount"][0].value()
        at = finance.approved_total(n, c)
        self.approved_total_lbl.setText(finance.format_money(at or 0))
        ah = finance.approved_hour_cost(c, h)
        self.approved_hour_lbl.setText(finance.format_money(ah) if ah else "—")
        d1 = finance.diff_funding_claimed(funding, claimed)
        d2 = finance.diff_claimed_approved(claimed, at)
        self.diff1_lbl.setText(finance.format_money(d1) if d1 is not None else "—")
        self.diff2_lbl.setText(finance.format_money(d2) if d2 is not None else "—")

    def _tab_attachments(self):
        w = QWidget()
        l = QVBoxLayout(w)
        self.attach_list = QListWidget()
        l.addWidget(self.attach_list, 1)
        row = QHBoxLayout()
        btn_add = QPushButton("إرفاق ملف")
        btn_add.clicked.connect(self._attach_add)
        btn_open = QPushButton("فتح")
        btn_open.clicked.connect(self._attach_open)
        btn_del = QPushButton("حذف")
        btn_del.clicked.connect(self._attach_del)
        row.addWidget(btn_add)
        row.addWidget(btn_open)
        row.addWidget(btn_del)
        row.addStretch(1)
        l.addLayout(row)
        self._refresh_attachments()
        return w

    def _refresh_attachments(self):
        self.attach_list.clear()
        for r in self.ctx.conn.execute(
                "SELECT id, original_name, added_at FROM attachments WHERE file_id=? ORDER BY added_at",
                (self.file_id,)):
            self.attach_list.addItem(f"{r['original_name']}  ({r['added_at'][:10]})")
            self.attach_list.item(self.attach_list.count() - 1).setData(Qt.UserRole, r["id"])

    def _attach_add(self):
        from .. import config as cfg
        path, _ = QFileDialog.getOpenFileName(self, "اختر المرفق")
        if not path:
            return
        import shutil
        from pathlib import Path
        dest_dir = cfg.attachments_dir() / str(self.file_id)
        dest_dir.mkdir(parents=True, exist_ok=True)
        src = Path(path)
        stored = f"{self.file_id}_{src.name}"
        shutil.copy2(src, dest_dir / stored)
        self.ctx.conn.execute(
            "INSERT INTO attachments (file_id, original_name, stored_name, size_bytes, added_by)"
            " VALUES (?,?,?,?,?)",
            (self.file_id, src.name, stored, src.stat().st_size,
             self.ctx.user["id"] if self.ctx.user else None))
        self.ctx.conn.commit()
        self._refresh_attachments()

    def _attach_open(self):
        from .. import config as cfg
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        item = self.attach_list.currentItem()
        if not item:
            return
        name = item.text().split("  (")[0]
        r = self.ctx.conn.execute(
            "SELECT stored_name FROM attachments WHERE file_id=? AND original_name=?",
            (self.file_id, name)).fetchone()
        if r:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(cfg.attachments_dir() / str(self.file_id) / r["stored_name"])))

    def _attach_del(self):
        item = self.attach_list.currentItem()
        if not item:
            return
        if QMessageBox.question(self, "تأكيد", "حذف هذا المرفق نهائيًا؟") != QMessageBox.Yes:
            return
        att_id = item.data(Qt.UserRole)
        if self.ctx.files.delete_attachment(
                self.file_id, att_id,
                user_id=self.ctx.user["id"] if self.ctx.user else None):
            self._refresh_attachments()
        else:
            QMessageBox.warning(self, "تنبيه", "تعذر حذف المرفق.")

    def _tab_status(self):
        w = QWidget()
        l = QVBoxLayout(w)
        # تغيير الحالة
        g = QGroupBox("تغيير حالة الملف")
        gl = QVBoxLayout(g)
        row = QHBoxLayout()
        self.status_cb = QComboBox()
        current = self.record.get("status_code")
        for code in next_statuses(current) if current else []:
            self.status_cb.addItem(STATUS_NAMES.get(code, code), code)
        self.status_notes = QLineEdit()
        self.status_notes.setPlaceholderText("ملاحظات تغيير الحالة")
        btn = QPushButton("تطبيق")
        btn.setProperty("primary", True)
        btn.clicked.connect(self._change_status)
        row.addWidget(btn)
        row.addWidget(self.status_notes, 1)
        row.addWidget(self.status_cb)
        row.addWidget(QLabel("الحالة الجديدة:"))
        gl.addLayout(row)
        l.addWidget(g)
        # السجل
        g2 = QGroupBox("سجل حركة الملف")
        l2 = QVBoxLayout(g2)
        self.history_list = QListWidget()
        for h in self.ctx.files.history(self.file_id):
            l2_text = f"{h['changed_at'][:16]} — {h['from_name'] or '—'} ← {h['to_name'] or '—'}"
            if h["user_name"]:
                l2_text += f" ({h['user_name']})"
            if h["notes"]:
                l2_text += f" — {h['notes']}"
            self.history_list.addItem(l2_text)
        l2.addWidget(self.history_list)
        l.addWidget(g2, 1)
        return w

    def _change_status(self):
        code = self.status_cb.currentData()
        if not code:
            return
        try:
            self.ctx.files.change_status(self.file_id, code,
                                         user_id=self.ctx.user["id"] if self.ctx.user else None,
                                         notes=self.status_notes.text())
            QMessageBox.information(self, "تم", "تم تغيير الحالة.")
            self.record = self.ctx.files.get(self.file_id)
            self._load_record()
        except ValueError as exc:
            QMessageBox.warning(self, "تعذر التغيير", str(exc))

    # -- تحميل / حفظ -------------------------------------------------------------------
    def _load_record(self):
        r = self.record
        for key, (w, kind) in self.widgets.items():
            val = r.get(key)
            try:
                if kind == "text":
                    w.setText(str(val) if val not in (None,) else "")
                elif kind == "notes":
                    w.setPlainText(str(val) if val else "")
                elif kind == "int":
                    w.setValue(int(val or 0))
                elif kind == "money":
                    w.setValue(float(val or 0))
                elif kind == "date":
                    if val:
                        d = QDate.fromString(str(val)[:10], "yyyy-MM-dd")
                        if d.isValid():
                            w.setDate(d)
                elif kind == "combo":
                    if val:
                        idx = w.findData(val)
                        if idx >= 0:
                            w.setCurrentIndex(idx)
                        else:
                            # قيمة مرجعية محذوفة — عرض الاسم المحفوظ
                            name_key = key.replace("_id", "_name")
                            w.setCurrentText(str(r.get(name_key) or ""))
            except Exception:
                pass
        self._recalc_contract()
        self._recalc_finance()

    def _collect(self):
        data = {}
        for key, (w, kind) in self.widgets.items():
            if kind == "text":
                data[key] = w.text().strip() or None
            elif kind == "notes":
                data[key] = w.toPlainText().strip() or None
            elif kind == "int":
                data[key] = w.value()
            elif kind == "money":
                v = w.value()
                data[key] = v if v != 0 else None
            elif kind == "date":
                # القيمة الدنيا (2000-01-01) تعني "بدون تاريخ" — لا تُحفظ
                data[key] = w.date().toString("yyyy-MM-dd") if w.date() > w.minimumDate() else None
            elif kind == "combo":
                data[key] = w.currentText().strip() or None
        return data

    def _resolve_combo(self, key, table, extra=None):
        """تحويل نص القائمة إلى id مع الإنشاء عند الحاجة."""
        w, _ = self.widgets[key]
        text = w.currentText().strip()
        if not text:
            return None
        row = self.ctx.conn.execute(f"SELECT id FROM {table} WHERE name=?", (text,)).fetchone()
        if row:
            return row["id"]
        cols = ["name"] + list((extra or {}).keys())
        vals = [text] + list((extra or {}).values())
        cur = self.ctx.conn.execute(
            f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals)
        self.ctx.conn.commit()
        return cur.lastrowid

    def save(self):
        data = self._collect()
        # حل القوائم المرجعية
        data["branch_id"] = self._resolve_combo("branch_id", "branches")
        data["field_id"] = self._resolve_combo("field_id", "program_fields")
        data["beneficiary_id"] = self._resolve_combo("beneficiary_id", "entities", {"kind": "beneficiary"})
        data["implementing_id"] = self._resolve_combo("implementing_id", "entities", {"kind": "implementing"})
        data["trainer_id"] = self._resolve_combo("trainer_id", "trainers")
        uid = self.ctx.user["id"] if self.ctx.user else None
        try:
            if self.file_id:
                if not has_permission(self.ctx.user, "file.update"):
                    QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية التعديل.")
                    return
                self.ctx.files.update(self.file_id, data, user_id=uid)
            else:
                if not has_permission(self.ctx.user, "file.create"):
                    QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية الإضافة.")
                    return
                self.ctx.files.create(data, user_id=uid)
            self.accept()
        except ValueError as exc:
            QMessageBox.warning(self, "خطأ في البيانات", str(exc))
