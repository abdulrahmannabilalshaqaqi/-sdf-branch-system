# -*- coding: utf-8 -*-
"""توليد عينات التسليم: استمارة PDF + ملف Excel مصدّر — من بيانات الملف الأصلي."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all, DOCUMENT_TYPES
from sdf_app.services import import_service as imp
from sdf_app.services.export_service import export_files, enrich_row
from sdf_app.services.file_service import FileService
from sdf_app.reports.review_form import build_review_form

SRC = Path("/home/hatch/workspace/user/files/______________________________________________________0_0qvq.xlsm")
OUT = Path(__file__).resolve().parent.parent / "samples"
OUT.mkdir(exist_ok=True)


def main():
    db_path = OUT / "_sample.db"
    if db_path.exists():
        db_path.unlink()
    database = Database(db_path)
    conn = database.connect()
    seed_all(conn)

    # استيراد الملف الأصلي
    mapping = imp.auto_map_columns(imp.preview_sheet(SRC, "ورقة2")["headers"])
    results = imp.analyze_rows(SRC, "ورقة2", mapping, conn)
    imp.execute_import(conn, results, source_file=str(SRC), sheet_name="ورقة2")

    fs = FileService(conn)

    # ملف مكتمل البيانات للاستمارة (رقم 7: فيه تعديل على العدد المعتمد)
    rec = fs.get_by_number(7)
    assert rec, "لم يُعثر على الملف 7"

    # قائمة تحقق تجريبية
    doc_ids = {r["name"]: r["id"] for r in conn.execute("SELECT id, name FROM document_types")}
    sample_results = {
        "العقد": ("مطابق", ""), "كشف الترشيحات": ("مطابق", ""),
        "كشوفات الحضور والانصراف": ("مطابق", ""),
        "بيانات المدرب ومؤهلاته": ("غير مكتمل", "الشهادة الجامعية غير مرفقة"),
        "الترخيص (عند اشتراطه)": ("غير منطبق", ""),
        "الشهادات": ("مطابق", ""), "المادة العلمية": ("مطابق", ""),
        "تقرير الإشراف": ("مطابق", ""), "المطالبة المالية": ("مطابق", ""),
        "مستندات أخرى": ("لم يراجع", ""),
    }
    review_items = []
    for name, (res, notes) in sample_results.items():
        review_items.append({"document_name": name, "result": res, "notes": notes})

    settings = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM settings")}
    pdf_path = OUT / "استمارة_مراجعة_ملف_7.pdf"
    build_review_form(rec, review_items, pdf_path, settings=settings)
    print("PDF:", pdf_path, pdf_path.stat().st_size, "bytes")

    # ملف Excel مصدّر (أول 50 سجلًا)
    rows, total = fs.search({}, page=1, per_page=50)
    xlsx_path = OUT / "كشف_الملفات_مصدّر.xlsx"
    export_files(rows, xlsx_path, title="كشف الملفات — عينة تصدير",
                 filters_desc="أول 50 سجلًا من قاعدة البيانات المستوردة")
    print("XLSX:", xlsx_path, xlsx_path.stat().st_size, "bytes | إجمالي:", total)
    database.close()


if __name__ == "__main__":
    main()
